package smarthome;

import java.awt.Color;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableColumn;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import com.google.gson.Gson;

import ai.olami.cloudService.APIConfiguration;
import ai.olami.cloudService.APIResponse;
import ai.olami.cloudService.CookieSet;
import ai.olami.cloudService.SpeechRecognizer;
import ai.olami.cloudService.SpeechResult;
import ai.olami.cloudService.TextRecognizer;
import ai.olami.nli.DescObject;
import ai.olami.nli.NLIResult;
import ai.olami.nli.Semantic;
import ai.olami.util.GsonFactory;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import smarthome.definition.AppStatus;
import smarthome.definition.AppStatusCode;
import smarthome.definition.HomeAutoProtocol;
import smarthome.util.Microphone;

public class NLIProcess implements Runnable  {
	
	    // * Replace your APP KEY with this variable.
	   
		private static String appKey = "*****your APP Key******";
		
		// * Replace your APP SECRET with this variable.
		private static String appSecret = "****your APP Secret*****";
		//indicate simplified input
		private static int localizeOption = APIConfiguration.LOCALIZE_OPTION_SIMPLIFIED_CHINESE;
		// * Replace the audio type you want to analyze with this variable.
		
		//private static int audioType = SpeechRecognizer.AUDIO_TYPE_PCM_WAVE;
	    private static int audioType = SpeechRecognizer.AUDIO_TYPE_PCM_RAW;
	    
	    //for store apps
	    private HashMap<String, Object> appmap = new HashMap<String, Object>();
	    
	    //for output text answer
	    private JTextArea answer_Text=null;
	    //for voice identify text
	    private JTextField voice_text=null;
	    //for color light display
	    private JTextField color_text=null;
	    //for output command answer
	    private JTable 	cmd_table = null;
	    
	    private JTextField tempe_text = null;
		private JTextField mode_text = null;
		private JTextField wind_text = null;
	    
	    boolean needstop =false;
	    //0表示文字输入，1表示语音输入
	    private int inputtype=0;
	    private String inputtext="";
	    
	    //控制输出的字体颜色
	    private boolean isred=false;
	    
		//configure your key and localize option
		private APIConfiguration config = new APIConfiguration(appKey, appSecret, localizeOption);
		
		//configure text recognizer
		TextRecognizer recoginzer = new TextRecognizer(config);	
		// * Step 2: Create the text recognizer.
		SpeechRecognizer speechrecoginzer = new SpeechRecognizer(config);
		Microphone mic = new Microphone();
		
		
        NLIProcess(){
    	// * Optional steps: Setup some other configurations.
    	recoginzer.setEndUserIdentifier("Someone");
    	recoginzer.setTimeout(10000);
    	
    	// * Optional steps: Setup some other configurations.
    	speechrecoginzer.setEndUserIdentifier("Someone");
    	speechrecoginzer.setTimeout(10000);
    	speechrecoginzer.setAudioType(audioType);
    	
        mic.initialize();
	
      }
public void setInputtype(int value){
	inputtype=value;
}
public void setInputText(String value){
	inputtext=value;
}
public void SetAnswerConfigCom(windowVariable  windowdata){
	answer_Text=windowdata.getAnswerText();
	cmd_table=windowdata.getCmdTable();
	this.isred=windowdata.getisRed();
	this.voice_text=windowdata.getVoicetext();
	color_text=windowdata.getcolortext();
	tempe_text = windowdata.getTempertext();
	mode_text = windowdata.getModetext();
	wind_text=windowdata.getWindtext();
	
}
public String getSemanticByText(String inputText){
	String Answer="";
	
	APIResponse nliResponse;
	try {
		nliResponse = recoginzer.requestNLI(inputText);
		if (nliResponse.ok() && nliResponse.hasData()) {
			// * Get NLI results.
			NLIResult[] nliResults = nliResponse.getData().getNLIResults();
			
			ProcessNLIResults(nliResults);
			
		} else {
			// Error
			System.out.println("* Error! Code : " + nliResponse.getErrorCode());
			System.out.println(nliResponse.getErrorMessage());
		}	
	} catch (NoSuchAlgorithmException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return Answer;
}
public void StopRecording( ){
		needstop=true;
		System.out.println("停止录音");
}

/**Voice Recognition at the same time recording 
 * 
 * */
public String getSemanticBySpeech() throws IOException{

	
	String Answer="";

	// * Prepare to send audio by a new task identifier.
	speechrecoginzer.releaseAppendedAudio();
	
	CookieSet cookie = new CookieSet();	
	System.out.println(" by CookieSet[" + cookie.getUniqueID() + "]");
	

   
    int total_count = 0;
	int temsize=3200; //如果需要把音频压缩为speex格式，那么每次输入的数据长度必须是640的倍数
    byte[] databytes=new byte[temsize];
    byte[] speexbytes=new byte[temsize];
    try {
    //begin Recording 
    mic.startRecording(); 
    System.out.println("开始录音");  
    
    int readcount = mic.getData(databytes, 0,temsize);
    
   
    
    //最多录3秒数据，因为采样频率是16000点每秒，每个点占两个字节。
    // readcount<=0表示录音结束
 	int num=0;
 	int srcint=0;
    while(readcount > 0 ) 
    {   		
    	if(total_count >= 48000*2||needstop)
    		break;

    	num++;
    	System.out.println("数据"+(num+1));
    	total_count += readcount;
    	System.out.println("单数"+readcount);
    		 
    	speechrecoginzer.appendAudioFramesData(databytes);
   
    	readcount = mic.getData(databytes, 0, temsize);
    }

    mic.stopRecording();
    needstop=false;
    
    System.out.println("结束录音");  
    
    // * Start sending audio.
    APIResponse response;
	
		response = speechrecoginzer.flushToUploadAudio(cookie, true);
		// Check request status.
		if (response.ok()) {
			// Now we can try to get recognition result.
			System.out.println("\n[Get Speech Result] =====================");
			while (true) {
				try {
					Thread.sleep(500);
				 
				// * Get result by the task identifier you used for audio upload.
				    System.out.println("\nRequest CookieSet[" + cookie.getUniqueID() + "] speech result...");
				
					response = speechrecoginzer.requestRecognitionWithAll(cookie);
				} catch (IllegalArgumentException | NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("\nOriginal Response : " + response.toString());
				System.out.println("\n---------- dump ----------\n");
				//System.out.println(jsonDump.toJson(response));
				System.out.println("\n--------------------------\n");
				// Check request status.
				if (response.ok() && response.hasData()) {
					// * Check to see if the recognition has been completed.
					SpeechResult sttResult = response.getData().getSpeechResult();
					if (sttResult.complete()) {
						// * Get speech-to-text result
						if(sttResult.getResult()!=null&&!sttResult.getResult().isEmpty()){
							this.voice_text.setText(sttResult.getResult());
						     System.out.println("* STT Result : " + sttResult.getResult());
						}
						// Because we used requestRecognitionWithAll()
						// So we should be able to get more results.
						// --- Like the Word Segmentation.
						if (response.getData().hasWordSegmentation()) {
							String[] ws = response.getData().getWordSegmentation();
							for (int i = 0; i < ws.length; i++) {
								System.out.println("* Word[" + i + "] " + ws[i]);
							}	
						}
						// --- Or the NLI results.
						if (response.getData().hasNLIResults()) {
							NLIResult[] nliResults = response.getData().getNLIResults();
							ProcessNLIResults(nliResults);
							
						}
						// * Done.
						Answer="录音结束";
						break;
					} else {
						// The recognition is still in progress.
						// But we can still get immediate recognition results.
						System.out.print("* STT Result [Not yet completed] ");
						System.out.println(" --> " + sttResult.getResult());
					}
				}
			}
		} else {
			// Error
			System.out.println("* Error! Code : " + response.getErrorCode());
			System.out.println(response.getErrorMessage());
		}
	} catch (NoSuchAlgorithmException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}catch(IllegalArgumentException e){
		answer_Text.setText("请检查麦克风是否可以正常使用");
	}
    catch(Exception e){
		e.printStackTrace();
	}
    

//    answer_Text.setText(Answer);
//	answer_Text.updateUI();
	
	System.out.println("\n===========================================\n");
    
	return Answer;
}

private smartHomeApp GetProcessApp(String appname){
	smartHomeApp app=null;
	if(appmap.containsKey(appname))
		app=(smartHomeApp) appmap.get(appname);
	else{
		//一个对话中只能存在一个同名APP
		app=new smartHomeApp();
		appmap.put(appname, app);
	}
	return app;
}
private void clearCmdTable(){
	String cmd_default="";
	for(int i=1;i<11;i++){
		
		cmd_table.setValueAt(cmd_default, i, 1);
		cmd_table.setValueAt(cmd_default, i, 2);
	}
	
}
private void ProcessNLIResults(NLIResult[] nliResults) {
	// TODO Auto-generated method stub
	String  answer="对不起，你说的话我还不能理解";
	boolean isnormal=false;
	for(int i=0;i<nliResults.length;i++){
		NLIResult tempNlI=nliResults[i];
		//tempNlI.
		//voice_text
		if(tempNlI.getType()!=null&&tempNlI.getType().equals(nliDefinitions.smarthome_app)){
			
			if(tempNlI.getSemantics()!=null&&tempNlI.getSemantics().length>0){
				Semantic[] tmpSemantics = tempNlI.getSemantics();
				for(int j=0;j<tmpSemantics.length;j++){
					Semantic tmpSemantic=tmpSemantics[j];
					if(tmpSemantic.getAppModule().equals(nliDefinitions.smarthome_app)){
						
						smartHomeApp handleApp = this.GetProcessApp(nliDefinitions.smarthome_app);
						handleApp.SetNLISemantic(tmpSemantic);
						handleApp.SetStatus(new AppStatus(AppStatusCode.TOPIC_START,  nliDefinitions.smarthome_app));
                        if(handleApp.AllSlotValidation()!= handleApp.GetSlotCount())  {
                        	continue;
                        }
                        OutputMap output = handleApp.GetResult();
                         
                        if(!isred){
                        answer_Text.setForeground(new Color(205, 92, 92));
                        cmd_table.setForeground(new Color(205, 92, 92));
                        isred=true;
                        }else{
                        answer_Text.setForeground(new Color(0, 0, 0));
                        cmd_table.setForeground(new Color(0, 0, 0));
                        isred=false;
                        }
                       
                        answer_Text.setText(output.getOutputSentence());
                        JSONObject cmdobject=output.getOutputAppCmd();
                        
                        if(!output.getOutputSentence().isEmpty())
                        	isnormal=true;
                        if(cmdobject==null){
                        	System.out.println("cmdobject is null");
                        	clearCmdTable();                      	
                        }
                        else {
                        	String cmd_default="";
	                        JSONArray devlist = cmdobject.getJSONArray("devlist");
	                        if(devlist.size()>0){
	                        	JSONObject devcmd=devlist.getJSONObject(0);
	                            
	                        	if(devcmd.getString("dev_id")!=null)
	                        		cmd_table.setValueAt(devcmd.getString("dev_id"), 1, 1);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 1, 1);
	                        	if(devcmd.getString("name")!=null)
	                        		cmd_table.setValueAt(devcmd.getString("name"), 2, 2);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 1, 1);
	                        	
	                        	if(devcmd.getString("dev_type")!=null)
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(devcmd.getInt("dev_type")&0xFFFF), 2, 1);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 2, 1);
	                        	
	                        	if(devcmd.getString("cluster_id")!=null)
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(devcmd.getInt("cluster_id")&0xFFFF), 3, 1);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 3, 1);
	                        	
	                        	if(devcmd.getString("cluster_name")!=null)
	                        		cmd_table.setValueAt(devcmd.getString("cluster_name"), 3, 2);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 3, 2);
	                        	
	                        	
	                        	if(devcmd.getString("action_id")!=null)
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(devcmd.getInt("action_id")&0xFF), 4, 1);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 4, 1);
	                        	
	                        	if(devcmd.getString("action_name")!=null)
	                        		cmd_table.setValueAt(devcmd.getString("action_name"), 4, 2);
	                        	else 
	                        		cmd_table.setValueAt(cmd_default, 4, 2);
	                        	
	                        	//空调温度显示
	                        	if(devcmd.getInt("dev_type")==HomeAutoProtocol.Devtype_Aircondition){
                    				if(devcmd.containsKey("cur_temp"))
                    				   tempe_text.setText(devcmd.getString("cur_temp"));
                    				else if(devcmd.containsKey("cur_mode"))
                     				   mode_text.setText(devcmd.getString("cur_mode"));
                    				else if(devcmd.containsKey("cur_wind"))
                      				   wind_text.setText(devcmd.getString("cur_wind"));
                    			}
	                        	
	                        	boolean issetcolor=false;
	                        	int r=0,g=0,b=0;//黑色
	                        	if(devcmd.getInt("dev_type")==HomeAutoProtocol.Devtype_Illuminations&&devcmd.containsKey("action_name")){
	                        	     if(devcmd.getString("action_name").equals("关闭")){
	                        	    	 issetcolor=true;
	                        	     }else if(devcmd.getString("action_name").equals("打开")){
	                        	    	 r=255;
	                        	    	 g=255;
	                        	    	 b=255;
	                        	    	 issetcolor=true;
	                        	     }
	                        	}
	                        	
	                        	//参数1
	                        	if(devcmd.containsKey("param1")){
	                        		JSONObject param1=devcmd.getJSONObject("param1");
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(param1.getInt("data_type_id")&0xFFFF), 6, 1);
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(param1.getInt("data_value")), 7, 1);
	                        		if(param1.containsKey("data_type_name"))
	                        			cmd_table.setValueAt(param1.getString("data_type_name"), 6, 2);	
	                        		if(devcmd.containsKey("dev_type")){
	                        			if(devcmd.getInt("dev_type")==HomeAutoProtocol.Devtype_Illuminations){ //如果是彩灯
	                        			  //////
	                        				r=(param1.getInt("data_value")&0xFF00)>>8;
	                        				g=(param1.getInt("data_value")&0x00FF);
	                        				issetcolor=true;
	                        			}
	                        		}
	                        	}else{
	                        		cmd_table.setValueAt(cmd_default, 6, 1);
	                        		cmd_table.setValueAt(cmd_default, 7, 1);
	                        		cmd_table.setValueAt(cmd_default, 6, 2);
	                        	}
	                        	//参数2
	                        	if(devcmd.containsKey("param2")){
	                        		JSONObject param2=devcmd.getJSONObject("param2");
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(param2.getInt("data_type_id")), 9, 1);
	                        		cmd_table.setValueAt("0x"+Integer.toHexString(param2.getInt("data_value")), 10, 1);
	                        		if(param2.containsKey("data_type_name"))
	                        			cmd_table.setValueAt(param2.getString("data_type_name"), 9, 2);	
	                        		if(devcmd.containsKey("dev_type")){
	                        			if(devcmd.getInt("dev_type")==HomeAutoProtocol.Devtype_Illuminations){ //如果是彩灯

	                        				b=(param2.getInt("data_value")&0xFF00)>>8;
	                        				
	                        			}
	                        		}
	                        	}else{
	                        		cmd_table.setValueAt(cmd_default, 9, 1);
	                        		cmd_table.setValueAt(cmd_default, 10, 1);
	                        		cmd_table.setValueAt(cmd_default, 9, 2);
	                        	}
	                        	if(issetcolor)
	                        		color_text.setBackground(new Color(r, g, b));
	                        }
                        }
                        isnormal=true;
						break;
					}
				}
				
			}
			
		}else{
			DescObject desobj = tempNlI.getDescObject();
			if(desobj.getReplyAnswer()!=null){
				answer=desobj.getReplyAnswer();
				answer_Text.setText(answer);
				isnormal=true;
			}
			
		}
	}
	if(isnormal==false){
		clearCmdTable();
		answer_Text.setText(answer);
	}
}
@Override
public void run() {
	// TODO Auto-generated method stub
	try {
		if(inputtype==1)
			getSemanticBySpeech();
		else 
			getSemanticByText(inputtext);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
