package smarthome;

import java.util.Iterator;



import net.sf.json.JSONObject;
import net.sf.json.JSONArray;


public class OutputMap {
	public final static String PRESENT_TTS = "1";
    public final static String PRESENT_DISPLAY = "2";
    public final static String PRESENT_TTS_AND_DISPLAY = "3";
    
    
    private final static String KEY_PRESENT = "Present";
    private final static String KEY_CONTENT = "Content";
    private final static String KEY_TAG = "tag";
    private final static String KEY_SENTENCE = "Sentence";
    
    private final static String KEY_APP = "App";
    private final static String KEY_APPNAME = "App Name";
    
    private JSONArray output = new JSONArray();

	JSONObject cmd=null;
	String answer="";
	String input="";
	public void setJSONoutput(JSONObject value){
		cmd=value;
	}
	public JSONObject getJSONOutput(){
		return cmd;
	}
	public void setAnswer(String value){
		answer=value;
	}
	public void setInput(String value){
		 input=value;
	}
	public String getAnswer(){
		return answer;
	}
	public String getInput(){
		return input;
	}
	public String getOutputSentence(){
		String answer="";
       for(int i=0;i<output.size();i++){
    	   JSONObject tmp=output.getJSONObject(i);
    	   if(tmp.containsKey(KEY_SENTENCE)){
    		   JSONObject answers=tmp.getJSONObject(KEY_SENTENCE);
    		   answer=answers.getString(KEY_CONTENT);
    			break;	   
    	   }
    		   
       }
		return answer;
	}
	public JSONObject getOutputAppCmd(){
		JSONObject cmd=null;
		for(int i=0;i<output.size();i++){
	    	   JSONObject tmp=output.getJSONObject(i);
	    	   if(tmp.containsKey(KEY_APP)){
	    		   cmd=tmp.getJSONObject(KEY_APP);	    		 
	    			break;	   
	    	   }
	    		   
	       }
		return  cmd;
	}
	public void AddAppCommand(String appName, JSONObject parameters){
	    JSONObject map2 = new JSONObject();
		map2.put(KEY_APPNAME, appName);
		
		if(parameters != null)
			map2.putAll(parameters);
		
		JSONObject map = null;
		
		Iterator<JSONObject> iter = output.iterator();
		while(iter.hasNext()){
		    JSONObject item = iter.next();
			
			if(item.get(KEY_APP) != null)
			{
				map = item;
				iter.remove();
				break;
			}
		}
		
		if (map == null){
			map = new JSONObject();		
		}
		
		map.accumulate(KEY_APP, map2);
		output.add(map);
	}
	public void AddSentence(String present, String sentence, String tag) {
	   
	    
	    JSONObject map2 = new JSONObject();
        map2.put(KEY_PRESENT, present);
        map2.put(KEY_CONTENT, sentence);
        if(tag != null)
            map2.put(KEY_TAG, tag);
        
        JSONObject map = new JSONObject();
        map.put(KEY_SENTENCE, map2);
        output.add(map);
       
    }
}
