package smarthome;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




import ai.olami.nli.Semantic;
import ai.olami.nli.slot.NumDetail;
import ai.olami.nli.slot.Slot;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import smarthome.definition.*;
import smarthome.util.number.Number;
public class smartHomeApp {
	//nliresult from olami apis interface
	private Semantic nliSemantic=null;
	private HashMap<String, AppSlotEntry> slots = new HashMap<String, AppSlotEntry>();
	private AppStatus status;
    private static final String APP_NAME = "homeautomation";
    private final static double allowdiffer = (double) 1 / 255;
    private final String light_deviceID = "TESTDEVID1";
    
    private List<String> gMods = new ArrayList<String>();
    
     //demo data:for devices
    private static ClientHomeAutomation homeAutoInfo=new ClientHomeAutomation();
    
    
    // key为颜色的名称
    // corlour data in mongodb
    private static Map<String, colourStatus> colorData = new ConcurrentHashMap<String, colourStatus>();

    // private static Map<String, colourStatus> tempData = new
    // ConcurrentHashMap<String, colourStatus>();

    // 色系 默认每种色系三个颜色，分三个等级,index越小，等级越小
    private static List<String> warmList = new ArrayList<String>();
    private static List<String> brightList = new ArrayList<String>();
    private static List<String> cuteList = new ArrayList<String>();
    private static List<String> coolList = new ArrayList<String>();
    private static List<String> sportList = new ArrayList<String>();
    private static List<String> graceList = new ArrayList<String>();
    private static List<String> calmList = new ArrayList<String>();

    // 氛围
    private static List<String> romanticList = new ArrayList<String>();
    private static List<String> softList = new ArrayList<String>();
    private static List<String> mysteryList = new ArrayList<String>();

    // private OutputMap output;
    private cmd_info commandInfo=new cmd_info();
    
    private Map<String, HomeAutodeviceObjectNew> beforeSensorValues = new HashMap<String, HomeAutodeviceObjectNew>();
    // 用来需要选择的设备列表
    List<String> SelectdeviceList = new ArrayList<String>();
  
    private static List<cmd_control_info> DeviceSupportAttrControlList = new ArrayList<cmd_control_info>();
    AppSlotEntry sensorvalue=null;
    private static final int temperaturefloat=2;
    private static final int airfloat=20;
    private static final int humidityfloat=5;
    private int switch2_type = HomeAutoProtocol.Devtype_Humidifier;
    private JSONObject AppCmd = new JSONObject();
    private JSONArray DevArray = new JSONArray();

    
    private List<String> controlDevIDList = new ArrayList<String>();
    private List<String> NormalcontrolDevIDList = new ArrayList<String>();
    
    private static final boolean isforShowroom = true;
    public smartHomeApp(){
    	
    	 commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
         commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
         commandInfo.setCmdTypeFlag(cmdTypeFlag.cmdtype_default);
         commandInfo.setLastPrimaryCmd(cmd_typePrimary.cmd_default);
         commandInfo.setLastSecondCmd(cmd_typeSecond.cmd_default);
         commandInfo.setLastCmdTypeFlad(cmdTypeFlag.cmdtype_default);
    }
    static {
       
       
    	LoadTempData();
        LoadColorModeInfo();

        InitData();
        InitDeviceData();
    }
    private static void InitData() {
        // TODO Auto-generated method stub
        cmd_control_info attrCont=new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_setwindpower);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_weaklevel);
        DeviceSupportAttrControlList.add(attrCont);

        attrCont = new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_setwindpower);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_mediumlevel);
        DeviceSupportAttrControlList.add(attrCont);

        attrCont = new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_setwindpower);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_stronglevel);
        DeviceSupportAttrControlList.add(attrCont);

        attrCont = new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_settiming);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_cancel);
        DeviceSupportAttrControlList.add(attrCont);

        attrCont = new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_setairquality);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_setup);
        DeviceSupportAttrControlList.add(attrCont);

        attrCont = new cmd_control_info();
        attrCont.setPrimaryCmd(cmd_typePrimary.cmd_setairquality);
        attrCont.setSecondCmd(cmd_typeSecond.cmd_setdown);
        DeviceSupportAttrControlList.add(attrCont);
    }
    private static void InitDeviceData() {
		// TODO Auto-generated method stub
    	  String data = "{\"data_type\":\"simu_stt\",\"data\":{}}";
    	  JSONObject js_top=JSONObject.fromObject(data);
    	  String testHomeauto1 = "{\"devices_changed_v2\":[{\"id\":\"1A054903004B12000A00\",\"type_id\":0x0306,\"position\":\"客厅\",\"description1\":\"二氧化碳1\",\"attributes\":[{\"cluster_id\":0x0404,\"attribute_id\":0,\"attribute_value\":60000,\"attribute_status\":5}]},{\"id\":\"2A054903004B12000A00\",\"type_id\":0x0306,\"position\":\"客厅\",\"description1\":\"\",\"attributes\":[{\"cluster_id\":0x0404,\"attribute_id\":0,\"attribute_value\":40000,\"attribute_status\":5}]},{\"id\":\"1A054903004B12000500\",\"type_id\":0x0302,\"position\":\"客厅\",\"description1\":\"温度1\",\"attributes\":[{\"cluster_id\":0x0402,\"attribute_id\":0,\"attribute_value\":3000,\"attribute_status\": 5}]},{\"id\":\"1A054903004B12000200\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":6000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000300\",\"type_id\":0x0106,\"position\":\"客厅\",\"description1\":\"光强\",\"attributes\":[{\"cluster_id\":0x0400,\"attribute_id\":0,\"attribute_value\":151,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000400\",\"type_id\":0x0309,\"position\":\"客厅\",\"description1\":\"空气\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":12500,\"attribute_status\": 1}]},{\"id\":\"19192407004b12000D00\",\"type_id\":0x0503,\"position\":\"客厅\",\"description1\":\"电视\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5}]},{\"id\":\"19192407004b12000100\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"开关1\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\":5}]},{\"id\":\"f4286b07004b12000100\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"开关2\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000B00\",\"type_id\":0x0501,\"position\":\"客厅\",\"description1\":\"加湿器\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5},{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\":5}]},{\"id\":\"1A054903004B12000F00\",\"type_id\":0x0300,\"position\":\"客厅\",\"description1\":\"空调\"},{\"id\":\"1A054903004B12001000\",\"type_id\":0x0300,\"position\":\"客厅\",\"description1\":\"空调\",\"attributes\":[{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":2,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":1,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":2,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0201,\"attribute_id\":0,\"attribute_value\":25,\"attribute_status\": 0x30}]},{\"id\":\"1A054903004B12000800\",\"type_id\":0x0500,\"position\":\"客厅\",\"description11\":\"净化器1\",\"attributes\":[{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":1,\"attribute_value\":0,\"attribute_status\": 0x30}]},{\"id\":\"1A054903004B12000900\",\"type_id\":0x0302,\"position\":\"客厅\",\"description1\":\"温度2\",\"attributes\":[{\"cluster_id\":0x0402,\"attribute_id\":0,\"attribute_value\":2600,\"attribute_status\": 5}]},{\"id\":\"1A054903004B12000700\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度2\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":3000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12001100\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度3\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":8000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12001300\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"灯2\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5}]},{\"id\":\"1A054903004B12001300\",\"type_id\":0x0202,\"position\":\"客厅\",\"description\":\"窗帘1\",\"attributes\":[{\"cluster_id\":0x0102,\"attribute_id\":0x0008,\"attribute_value\":30,\"attribute_status\":0x20},{\"cluster_id\":0x0102,\"attribute_id\":0x0014,\"attribute_value\":0x0101,\"attribute_status\":0x21}]},{\"id\":\"1A054903004B12001400\",\"type_id\":0x0102,\"position\":\"客厅\",\"description1\":\"彩灯\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5},{\"cluster_id\":0x000a,\"attribute_id\":0x0003,\"attribute_value\":0xFF00FF,\"attribute_status\":5}]}],\"device_removed\":[\"9FF74803004B120003\",\"9FF74803004B120004\"]}";
    	   js_top.getJSONObject("data").put("home_automation",
                 JSONObject.fromObject(testHomeauto1));
    	JSONObject js_data = js_top.getJSONObject("data"); 
    	JSONObject js_homeAuto_info=js_data.getJSONObject("home_automation");
        if(!js_homeAuto_info.isEmpty()){
            homeAutoInfo.ParseClientAppInfoNew(js_homeAuto_info);
        }
	}
	private static void LoadColorModeInfo() {
        // 暖色系
        warmList.add("深橙");
        warmList.add("橙红");
        warmList.add("猩红");
        // 明亮色系
        brightList.add("孔雀蓝");
        brightList.add("春绿");
        brightList.add("洋红");
        // 可爱
        // 兰花紫即是暗紫
        cuteList.add("兰花紫");
        cuteList.add("樱桃红");
        cuteList.add("金菊黄");
        // 冷色系
        coolList.add("午夜蓝");
        coolList.add("绿");
        coolList.add("暗紫罗兰");
        // 运动
        sportList.add("深天蓝");
        sportList.add("橙");
        sportList.add("红");
        // 优雅
        graceList.add("火砖");
        graceList.add("森林绿");
        graceList.add("靛青");
        // 冷静
        calmList.add("巧克力");
        calmList.add("海洋绿");
        calmList.add("暗兰花紫");

        // 氛围的色彩
        // 浪漫
        romanticList.add("棕");
        romanticList.add("蓝紫罗兰");
        romanticList.add("镉红");
        // 柔和
        softList.add("杏");
        softList.add("小麦");
        softList.add("亮蓝灰");

        // 神秘
        mysteryList.add("紫");
        mysteryList.add("闪光绿");
        mysteryList.add("海军蓝");

    }
    private static void LoadTempData() {
        // TODO Auto-generated method stub
        colourStatus color = new colourStatus();
        color.SetName("白");
        color.SetAlias("纯白");
        color.SetRGBvalue(0xFFFFFF);
        color.SetHvalue(190.0);
        color.SetSvalue(0.42);
        color.SetBvalue(0.8);
        colorData.put("白", color);

        color = new colourStatus();
        color.SetName("红");
        color.SetAlias("纯红，大红，正红");
        color.SetRGBvalue(0xFF0000);
        color.SetHvalue(0.0);
        color.SetSvalue(0.8);
        color.SetBvalue(0.75);
        colorData.put("红", color);

        color = new colourStatus();
        color.SetName("橙");
        color.SetAlias("纯橙");
        color.SetRGBvalue(0xFFA500);
        color.SetHvalue(24.0);
        color.SetSvalue(0.96);
        color.SetBvalue(0.76);
        colorData.put("橙", color);

        color = new colourStatus();
        color.SetName("黄");
        color.SetAlias("纯黄");
        color.SetRGBvalue(0xFFFF00);
        color.SetHvalue(54.0);
        color.SetSvalue(1.0);
        color.SetBvalue(0.76);
        colorData.put("黄", color);

        color = new colourStatus();
        color.SetName("绿");
        color.SetAlias("纯绿");
        color.SetRGBvalue(0x00FF00);

        color.SetHvalue(96);
        color.SetSvalue(0.96);
        color.SetBvalue(0.64);
        colorData.put("绿", color);

        color = new colourStatus();
        color.SetName("青");
        color.SetAlias("纯青，浅绿");
        color.SetRGBvalue(0x00FFFF);
        color.SetHvalue(180.0);
        color.SetSvalue(0.8);
        color.SetBvalue(0.8);
        colorData.put("青", color);

        color = new colourStatus();
        color.SetName("蓝");
        color.SetAlias("纯蓝");
        color.SetRGBvalue(0x0000FF);
        color.SetHvalue(205);
        color.SetSvalue(0.8);
        color.SetBvalue(0.28);
        colorData.put("蓝", color);

        color = new colourStatus();
        color.SetName("紫");
        color.SetAlias("纯紫");
        color.SetRGBvalue(0x800080);
        color.SetHvalue(271);
        color.SetSvalue(0.8);
        color.SetBvalue(0.32);
        colorData.put("紫", color);

        color = new colourStatus();
        color.SetName("浅蓬灰");
        color.SetRGBvalue(0xe5c2db);
        color.SetHvalue(316);
        color.SetSvalue(0.15);
        color.SetBvalue(0.9);
        colorData.put("浅蓬灰", color);

        color = new colourStatus();
        color.SetName("锦葵");
        color.SetRGBvalue(0xdb6aa4);
        color.SetHvalue(329);
        color.SetSvalue(0.52);
        color.SetBvalue(0.86);
        colorData.put("锦葵", color);

        color = new colourStatus();
        color.SetName("米黄");
        color.SetRGBvalue(0xfffbc9);
        color.SetHvalue(56);
        color.SetSvalue(0.21);
        color.SetBvalue(0.1);
        colorData.put("米黄", color);

        color = new colourStatus();
        color.SetName("灰紫");
        color.SetRGBvalue(0x9d899d);
        color.SetHvalue(302);
        color.SetSvalue(0.13);
        color.SetBvalue(0.62);
        colorData.put("灰紫", color);

        color = new colourStatus();
        color.SetName("淡紫");
        color.SetRGBvalue(0x7c509d);
        color.SetHvalue(274);
        color.SetSvalue(0.49);
        color.SetBvalue(0.62);
        colorData.put("淡紫", color);

        color = new colourStatus();
        color.SetName("宝蓝");
        color.SetRGBvalue(0x7c509d);
        color.SetHvalue(223);
        color.SetSvalue(1);
        color.SetBvalue(0.65);
        colorData.put("宝蓝", color);
        
        color = new colourStatus();
        color.SetName("深橙");
        color.SetRGBvalue(0xFF8C00);
        color.SetHvalue(33);
        color.SetSvalue(1);
        color.SetBvalue(1);
        colorData.put("深橙", color);
        
        color = new colourStatus();
        color.SetName("橙红");
        color.SetRGBvalue(0xFF4500);
        color.SetHvalue(16);
        color.SetSvalue(1);
        color.SetBvalue(1);
        colorData.put("橙红", color);
        
        color = new colourStatus();
        color.SetName("猩红");
        color.SetRGBvalue(0xDC143C);
        color.SetHvalue(348);
        color.SetSvalue(0.9);
        color.SetBvalue(0.86);
        colorData.put("猩红", color);
        
        color = new colourStatus();
        color.SetName("孔雀蓝");
        color.SetRGBvalue(0x33A1C9);
        color.SetHvalue(196);
        color.SetSvalue(0.75);
        color.SetBvalue(0.79);
        colorData.put("孔雀蓝", color);
        
        color = new colourStatus();
        color.SetName("春绿");
        color.SetRGBvalue(0x00FF7F);
        color.SetHvalue(150);
        color.SetSvalue(1);
        color.SetBvalue(1);
        colorData.put("春绿", color);
        
        color = new colourStatus();
        color.SetName("洋红");
        color.SetRGBvalue(0xFF00FF);
        color.SetHvalue(300);
        color.SetSvalue(1);
        color.SetBvalue(1);
        colorData.put("洋红", color);
        
        color = new colourStatus();
        color.SetName("兰花紫");
        color.SetRGBvalue(0xFF00FF);
        color.SetHvalue(302);
        color.SetSvalue(0.49);
        color.SetBvalue(0.85);
        colorData.put("兰花紫", color);
        
        color = new colourStatus();
        color.SetName("樱桃红");
        color.SetRGBvalue(0xFF00FF);
        color.SetHvalue(347);
        color.SetSvalue(0.7);
        color.SetBvalue(0.78);
        colorData.put("樱桃红", color);
        
        color = new colourStatus();
        color.SetName("金菊黄");
        color.SetRGBvalue(0xDAA520);
        color.SetHvalue(43);
        color.SetSvalue(0.85);
        color.SetBvalue(0.85);
        colorData.put("金菊黄", color);
        
        color = new colourStatus();
        color.SetName("午夜蓝");
        color.SetRGBvalue(0x191970);
        color.SetHvalue(240);
        color.SetSvalue(0.78);
        color.SetBvalue(0.44);
        colorData.put("午夜蓝", color);
        
        color = new colourStatus();
        color.SetName("暗紫罗兰");
        color.SetRGBvalue(0x9400D3);
        color.SetHvalue(282);
        color.SetSvalue(1);
        color.SetBvalue(0.83);
        colorData.put("暗紫罗兰", color);
        
        color = new colourStatus();
        color.SetName("深天蓝");
        color.SetRGBvalue(0x00BFFF);
        color.SetHvalue(195);
        color.SetSvalue(1);
        color.SetBvalue(0.83);
        colorData.put("深天蓝", color);
        
        color = new colourStatus();
        color.SetName("火砖");
        color.SetRGBvalue(0xB22222);
        color.SetHvalue(0);
        color.SetSvalue(0.81);
        color.SetBvalue(0.7);
        colorData.put("火砖", color);
        
        color = new colourStatus();
        color.SetName("森林绿");
        color.SetRGBvalue(0x228B22);
        color.SetHvalue(120);
        color.SetSvalue(0.75);
        color.SetBvalue(0.54);
        colorData.put("森林绿", color);
        
        color = new colourStatus();
        color.SetName("靛青");
        color.SetRGBvalue(0x4B0082);
        color.SetHvalue(275);
        color.SetSvalue(0.75);
        color.SetBvalue(0.51);
        colorData.put("靛青", color);
        
        color = new colourStatus();
        color.SetName("巧克力");
        color.SetRGBvalue(0x4B0082);
        color.SetHvalue(25);
        color.SetSvalue(0.86);
        color.SetBvalue(0.82);
        colorData.put("巧克力", color);
        
        color = new colourStatus();
        color.SetName("海洋绿");
        color.SetRGBvalue(0x4B0082);
        color.SetHvalue(146);
        color.SetSvalue(0.67);
        color.SetBvalue(0.54);
        colorData.put("海洋绿", color);
        
        color = new colourStatus();
        color.SetName("暗兰花紫");
        color.SetRGBvalue(0x9932CC);
        color.SetHvalue(280);
        color.SetSvalue(0.75);
        color.SetBvalue(0.8);
        colorData.put("暗兰花紫", color);
        
        color = new colourStatus();
        color.SetName("棕");
        color.SetRGBvalue(0xA52A2A);
        color.SetHvalue(0);
        color.SetSvalue(0.74);
        color.SetBvalue(0.65);
        colorData.put("棕", color);
        
        color = new colourStatus();
        color.SetName("蓝紫罗兰");
        color.SetRGBvalue(0xA52A2A);
        color.SetHvalue(271);
        color.SetSvalue(0.81);
        color.SetBvalue(0.88);
        colorData.put("蓝紫罗兰", color);
        
        color = new colourStatus();
        color.SetName("镉红");
        color.SetRGBvalue(0xE3170D);
        color.SetHvalue(2.8);
        color.SetSvalue(0.94);
        color.SetBvalue(0.89);
        colorData.put("镉红", color);
        
        color = new colourStatus();
        color.SetName("杏");
        color.SetRGBvalue(0xE3170D);
        color.SetHvalue(26);
        color.SetSvalue(0.51);
        color.SetBvalue(0.98);
        colorData.put("杏", color);
        
        color = new colourStatus();
        color.SetName("小麦");
        color.SetRGBvalue(0xE3170D);
        color.SetHvalue(39);
        color.SetSvalue(0.27);
        color.SetBvalue(0.96);
        colorData.put("小麦", color);
        
        color = new colourStatus();
        color.SetName("亮蓝灰");
        color.SetRGBvalue(0x778899);
        color.SetHvalue(210);
        color.SetSvalue(0.22);
        color.SetBvalue(0.6);
        colorData.put("亮蓝灰", color);
        
        color = new colourStatus();
        color.SetName("闪光绿");
        color.SetRGBvalue(0x00FF00);
        color.SetHvalue(120);
        color.SetSvalue(1);
        color.SetBvalue(1);
        colorData.put("闪光绿", color);
        
        color = new colourStatus();
        color.SetName("海军蓝");
        color.SetRGBvalue(0x000080);
        color.SetHvalue(240);
        color.SetSvalue(1);
        color.SetBvalue(0.5);
        colorData.put("海军蓝", color);

    }
	public void SetNLISemantic(Semantic semantic){
		nliSemantic=semantic;
		Slot[] reslutslots = nliSemantic.getSlots();
		
        for(int i=0;i<reslutslots.length;i++){
        	
		  AppSlotEntry tmpslot = new AppSlotEntry(reslutslots[i]);
		  System.out.println(tmpslot.getName());
		  slots.put(tmpslot.getName(), tmpslot);
		}
		
		gMods= Arrays.asList(nliSemantic.getGlobalModifiers());

		
	}
	
	public final AppSlotEntry GetSlotByName(String slotName){
		return slots.get(slotName);		
	}
	private boolean isHomeAutoDevicetype() {
        boolean ret = false;
        if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Illuminations
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Light
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Dehumidifier
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircleaner
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircondition
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WindowCovering
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Camera
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Television
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Projector
                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Projectorbackdrop)
            ret = true;

        return ret;
    }
	/**
     * demo 暂时不考虑环境，只涉及一个房间
     * 
     * @param slotName
     * @return
     */
    private boolean ParseDevicePositon(String slotName) {
        // TODO Auto-generated method stub
        commandInfo.setPositionName(slotName);
        return true;
    }
    private boolean isValidNumber() {
        // TODO Auto-generated method stub
        boolean isnumber = false;
        AppSlotEntry sensorvalueSlot = GetSlotByName("sensorvalue");
        
        if(sensorvalueSlot.hasNumDetail())
        		isnumber = true;
        
        return isnumber;
    }

    private boolean isValidColour(String value) {
        boolean ret = false;
        if (value == null || value.isEmpty())
            return ret;

        colourStatus adjustcolor = commandInfo.getAdjustcolor();

        Iterator<Entry<String, colourStatus>> entries = colorData.entrySet().iterator();

        while (entries.hasNext()) {

            Entry<String, colourStatus> entry = entries.next();

            colourStatus tempcolor = entry.getValue();
            if (tempcolor.HasName(value) || tempcolor.HasAlias(value)) {
                adjustcolor.SetName(tempcolor.GetName());
                adjustcolor.SetAlias(tempcolor.GetAliasname());
                adjustcolor.SetRGBvalue(tempcolor.GetRGBvalue());
                adjustcolor.SetHvalue(tempcolor.GetHvalue());
                adjustcolor.SetSvalue(tempcolor.GetSvalue());
                adjustcolor.SetBvalue(tempcolor.GetBvalue());
                ret = true;
                break;

            }
        }

        return ret;

    }
	 /**
     * 目前仅支持通用设备说法，比如：灯，空调，加湿器，以后还要检查是否和客户端设置的设备名相同， 其他的情况暂时不处理。
     * 
     * @param slotname
     * @param slotValue
     * @return
     */
    private boolean ParseDeviceInfo(String slotname,String slotValue ){
              
        boolean success=true;
        
        // 操作某个设备
        // 每个grammar都必须提供slot "control_obj"
        if (slotname.equals("control_obj")) {

           if(!ParseDeviceType(slotValue)){
               success=false;
            } else {
                // 对于"stop"modifier,如果上次对话中不是窗帘，则return false
                if (HasModifier("stop", "control_obj") || HasModifier("continue", "control_obj")) {
                    if (!isHomeAutoDevicetype())
                        return false;
                }
                commandInfo.setSlotname(slotValue);
           }
            // 记录slot的名称
            commandInfo.setSlotname(slotValue);
        }
        else if(slotname.equalsIgnoreCase("position_name")){
            if(!ParseDevicePositon(slotValue))
                success=false;
        } else if (slotname.equalsIgnoreCase("slot_timing")) {

        } else if (slotname.equalsIgnoreCase("color")) {// 验证彩灯的颜色
            if (!isValidColour(slotValue))
                success = false;
        } else if (slotname.equalsIgnoreCase("sensorvalue")) {
            if (slotValue.matches("^[0-9]+点")
                    || slotValue.matches("^[一二三四五六七八九十零壹贰参肆伍陆柒拐捌玖拾佰仟万]+点"))
                success = false;
            else if (!isValidNumber())
                success = false;
        }
        
        return success;

    }
	public boolean SlotValidate(String slotName, String slotValue) {
        // TODO Auto-generated method stub
  
        if (ParseDeviceInfo(slotName, slotValue)) {
            commandInfo.setEntryGrammarFlag(false);
            commandInfo.setCurrentDevType(false);
            return true;
        }

        return false;
    }
	protected final void SetStatus(AppStatus status){
		this.status = status;
	}	
	public final AppStatus Status() {		
		return status;
	}
	public final boolean HasModifier(String modifier){
		return HasModifier(modifier, null);		
	}
	public  List<String> GetModifier(String slotName){
        if(slotName == null){            
                return gMods;
        }
        else{
            AppSlotEntry slot = GetSlotByName(slotName);
            if(slot != null)
                    return slot.mods;
            else
                return null;
        }       
    }
	/**
	 * detect if has a modifier for a slot
	 * @param modifier
	 * @param slotName
	 * @return
	 */
	public final boolean HasModifier(String modifier, String slotName){
		if(slotName == null){
			return gMods.contains(modifier);
		}
		else{
			AppSlotEntry slot = GetSlotByName(slotName);
			if(slot != null)
			    return slot.mods.contains(modifier);
			else
			    return false;
		}		
	}
	
	private boolean validateExactMacting(StringBuffer temp) {
        // TODO Auto-generated method stub
        boolean ret = false;

        // 1.String是否完全匹配
        HomeAutodeviceObjectNew definedDevice = DedinedByUser(temp);
        if (definedDevice != null) {
            // 用户自定义设备名称
            commandInfo.setDeviceName(definedDevice.description);
            commandInfo.setDeviceType(definedDevice.device_type);
            commandInfo.setCurrentDevType(true);
            commandInfo.setDeviceID(definedDevice.device_ID);
            return true;
        }

        return ret;
    }
	 /**
     * 除了温度等传感器设备以外，检测命名有没有完全匹配。 如果没有完全匹配，则查看是否包含
     * 
     * @param temp
     * @return
     */
    private HomeAutodeviceObjectNew DedinedByUser(StringBuffer object) {

        // TODO Auto-generated method stub
        // 如果是询问室内的环境，slot value优先作为属性名称
        if ((object.equals("温度") || object.equals("湿度") || object.equals("AQI")
                || object.equals("光强")) && HasModifier("query", "control_obj"))
            return null;

        String tempname = object.toString();
        Map<String, HomeAutodeviceObjectNew> DeviceList = homeAutoInfo.GetExitingDevicesNew();
        Set<Entry<String, HomeAutodeviceObjectNew>> keys = DeviceList.entrySet();
        Iterator<Entry<String, HomeAutodeviceObjectNew>> entries = keys.iterator();
        while (entries.hasNext()) {
            Entry<String, HomeAutodeviceObjectNew> entry = entries.next();
            HomeAutodeviceObjectNew device = entry.getValue();
            if (device.description == null || device.description.isEmpty())
                continue;
            if (device.description.equals(tempname)) {
                // 如果是空调设备，则必须是控制空调的设备
                if (device.device_type == HomeAutoProtocol.Devtype_Aircondition) {
                    String id = device.device_ID;
                    if (id.substring(id.length() - 4, id.length()).equalsIgnoreCase("0F00")) {
                        return device;
                    }
                } else
                    return device;
            }
            else if (tempname.contains(device.description)) {
                tempname = tempname.replaceAll(device.description, "");
                object.delete(0, object.length());
                object.append(tempname);
                if (device.device_type == HomeAutoProtocol.Devtype_Aircondition) {
                    String id = device.device_ID;
                    if (id.substring(id.length() - 4, id.length()).equalsIgnoreCase("0F00")) {
                        return device;
                    }
                } else
                    return device;
            }
        }

        return null;
    }

    /**
     * 检查是否包含通用名称，若包含获取并记录信息
     * 
     * @param temp
     * @return
     */
    private boolean validateGeneralMacting(StringBuffer temp) {

        // TODO Auto-generated method stub
        boolean ret = false;
        if (temp.length() != 0) {
            Map<Integer, String> generaldevicemap = HomeAutoProtocol.getGeneralDeviceName();

            for (Entry<Integer, String> entry : generaldevicemap.entrySet()) {
                // 获取设备对应的正则表达式,并添加包含词正则表达式的匹配
                String regex = entry.getValue();
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(temp);
                if (matcher.find()) {
                    // if (temp.toString().matches(regex)) {

                    Integer key = entry.getKey();
                    // 如果非more语料中提供了设备类型，则不需要保存上次对话中楼层和区域信息
                    if (!commandInfo.isMoreGrammar()) {

                        commandInfo.ResetLocationInfo();
                        // Reset上次对话的名称
                        commandInfo.ResetDeviceName();
                    }

                    commandInfo.setDeviceType(key);
                    commandInfo.setCurrentDevType(true);
                    // commandInfo.setDevProtocol(HomeAutoProtocol.protocal_viaimbedded);
                    commandInfo.setsplitName(
                            temp.subSequence(matcher.start(), matcher.end()).toString());
                    commandInfo.setDeviceName(commandInfo.getsplitName());
                    // 2016/6/13,暂定打开灯，关闭灯的通用处理为打开所有的灯，关闭所有的灯。
                    // if (key.equals(HomeAutoProtocol.Devtype_Light))
                    // super.AddModifier("all", "control_obj");
                    // 将输入中的区域去掉
                    String tempvalue = temp.toString()
                            .replaceAll(temp.substring(matcher.start(), matcher.end()), "");
                    temp.delete(0, temp.length());
                    temp.append(tempvalue);
                    return true;

                }
            }
        }
       
        return ret;
    }

    private boolean validateLocationMacting(StringBuffer temp) {

        // 获取位置信息
        if (temp.length() != 0) {

            Map<String, String> locationmap = HomeAutoProtocol.getLocationName();
            for (Entry<String, String> entry : locationmap.entrySet()) {
                // 从输入中找出匹配的对象，并记录

                // Pattern pattern = Pattern.compile(".*(" + entry.getValue() +
                // ").*");
                Pattern pattern = Pattern.compile(entry.getValue());
                Matcher matcher = pattern.matcher(temp);
                if (matcher.find()) {
                    String key = entry.getKey();
                    commandInfo.setPositionNum(key);
                    commandInfo.setPositionName(temp.substring(matcher.start(), matcher.end()));
                    String tempvalue = temp.toString()
                            .replaceAll(temp.substring(matcher.start(), matcher.end()), "");
                    temp.delete(0, temp.length());
                    temp.append(tempvalue);
                    break;
                }
            }
        }
        // 获取楼层信息

        if (temp.length() != 0) {
            // 将中文数字转换为阿拉伯数字
            // String tempString =
            // Number.StrWithChsNumber2StrWithDigital(temp.toString());
        
            String tempString = Number.StrWithChsInteger2StrWithDigital(temp.toString());
            Pattern pattern = Pattern.compile("[1-9][0-9]*(楼|层|楼层)");
            Matcher matcher = pattern.matcher(tempString);
            if (matcher.find()) {
                // 将匹配的字符仅留下数字
                String matchString = tempString.substring(matcher.start(), matcher.end())
                        .replaceAll("楼|层|楼层", "");
                int zeronum = 4 - matchString.length();
                String floortype = "F";
                for (int i = 0; i < zeronum; i++)
                    floortype += "0";
                floortype += matchString;
                commandInfo.setFloorNum(floortype);
                commandInfo.setFloorName(temp.substring(matcher.start(), matcher.end()));
                String tempvalue = temp.toString()
                        .replaceAll(temp.substring(matcher.start(), matcher.end()), "");
                temp.delete(0, temp.length());
                temp.append(tempvalue);

            }

        }
        return true;
    }
    

    private HomeAutodeviceObjectNew DedinedByUser(String controlObj) {

        // TODO Auto-generated method stub
        // 如果是询问室内的环境，slot value优先作为属性名称
        if ((controlObj.equals("温度") || controlObj.equals("湿度")
                || controlObj.equalsIgnoreCase("AQI") || controlObj.equals("光强"))
                && HasModifier("query", "control_obj"))
            return null;

        Map<String, HomeAutodeviceObjectNew> DeviceList = homeAutoInfo.GetExitingDevicesNew();
        Set<Entry<String, HomeAutodeviceObjectNew>> keys = DeviceList.entrySet();
        Iterator<Entry<String, HomeAutodeviceObjectNew>> entries = keys.iterator();
        while (entries.hasNext()) {
            Entry<String, HomeAutodeviceObjectNew> entry = entries.next();
            HomeAutodeviceObjectNew device = entry.getValue();
            if (device.description == null || device.description.isEmpty())
                continue;
            if (device.description.equals(controlObj))
                 return device;
            // if (controlObj.equals("净化器一"))
            // controlObj = "净化器1";
            // else if (controlObj.equals("净化器二") || controlObj.equals("净化器两"))
            // controlObj = "净化器2";
//            float f = Levenshtein.getSimilarityRatio(controlObj, device.description);
//            if (f > 0.8) {
//                return device;
//            }
        }
        return null;
    }
    private void HandleShowroomDevicesSpecially() {
        if (!commandInfo.getDeviceID().isEmpty())
            return;
        HomeAutodeviceObjectNew definedDevice = null;
        if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Camera) {
            // 院子里的摄像头

            if (commandInfo.getPositionNum().equals(HomeAutoProtocol.DevLocationType_yard)) {
                definedDevice = DedinedByUser("室外摄像头");
            } else
                definedDevice = DedinedByUser("室内摄像头");
            if (definedDevice != null) {
                if (!HasModifier("all", "control_obj"))
                    commandInfo.setDeviceID(definedDevice.device_ID);
            }

        }
        else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WallLight) {
            definedDevice = DedinedByUser("壁灯");
            if (definedDevice != null) {
                commandInfo.setDeviceID(definedDevice.device_ID);
                commandInfo.setDeviceType(HomeAutoProtocol.Devtype_Light);
            }
        } else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_CeilingLight) {
            definedDevice = DedinedByUser("主灯");
            if (definedDevice != null) {
                commandInfo.setDeviceID(definedDevice.device_ID);
                commandInfo.setDeviceType(HomeAutoProtocol.Devtype_Light);
            }
        } else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Light) { // 通用灯
            // if (!HasModifier("all", "control_obj")) {
            // definedDevice = DedinedByUser("主灯");
            // if (definedDevice != null) {
            // commandInfo.setDeviceID(definedDevice.device_ID);
            // }
            // }
        }

    }
	 /**
     * 功能：通过验证初步获取设备的名称，位置，楼层，ID或者command信息 验证算法： 1. controlObj=="未知设备"，验证通过 2.
     * 是否是用户自定义的名称-->是，记录相关信息，楼层默认为一楼，区域默认为客厅。 3.
     * 是否是通用设备名称-->是，记录相关信息，楼层默认为一楼，区域默认为客厅。 4.
     * 是否包含用户自定义名称--是-》记录，并检查是否包含楼层，区域信息，获取并记录 5.
     * 是否包含通用设备名称--->是，记录，并检查是否包含楼层，区域信息，获取并记录 6. 不符合以上要求的设备不支持。
     * 
     * @param controlObj
     * @return
     */
    private boolean ParseDeviceType(String controlObj) {
        
        // TODO Auto-generated method stub
        // 是HomeAutomation的语法，但是语法中没有指明slot,以后最好改成使用global modifier

        if (controlObj.equals("未知设备")) {
            // 当查询传感器状态时，reset devicetype
            if (HasModifier("query", "control_obj"))
                commandInfo.setDeviceType(HomeAutoProtocol.Devtype_Unknow);
            return true;
        } else if (controlObj.isEmpty() && commandInfo.isMoreGrammar()) {
            return true;
        }
      
        /**
         * 设备名称匹配原则： 1.检测名称的string是否完全匹配 2.检测是否是公共名称
         * 3.拼音是否完全匹配，如果拼音匹配有多个，则取文字匹配度高的。
         * 
         */
        boolean ismatch = false;
        StringBuffer temp = new StringBuffer(controlObj);

        // 获取完全匹配的设备信息
        ismatch = validateExactMacting(temp);
        if (!ismatch)
            ismatch = validateGeneralMacting(temp);
        // 获取区域名称，楼层名称
        validateLocationMacting(temp);
        // showroom 设备特殊处理
        HandleShowroomDevicesSpecially();
        
        // 如果设备名称，楼层，区域，类型有一个不为空，则表示验证通过
        if (!commandInfo.getDeviceName().isEmpty() || !commandInfo.getPositionName().isEmpty()
                || !commandInfo.getFloorName().isEmpty() || commandInfo.getDeviceType() != 0) {
            // 如果用户的输入中没有提供设备类型，并且是entry grammar的查询
            // 比如二楼的温度是多少
            if (!commandInfo.isCurrentDevType() && commandInfo.isEntryGrammar()
                    && HasModifier("query", "control_obj")) {
                if (HasModifier("attrtemperature", "control_obj")
                        || HasModifier("attrhumidity", "control_obj")
                        || HasModifier("attrairquality", "control_obj")
                        || HasModifier("attrco2", "control_obj")
                        || HasModifier("arrtlightintensity", "control_obj")) {
                    commandInfo.ResetDeviceName();
                    commandInfo.setDeviceType(0);
                }

            }
            // 保存语义中的楼层和区域信息
            commandInfo.setOriginalFloorName(commandInfo.getFloorName());
            commandInfo.setOriginalFloorNum(commandInfo.getFloorNum());
            commandInfo.setOriginalPositionNum(commandInfo.getPositionName());
            commandInfo.setOriginalPositionName(commandInfo.getPositionNum());
            return true;
        }
        // ]]][[147741nfo.get        // commandInfo.setsplitName(controlObj);
        // return true;
        // }

        return false;
    }

	
	public int AllSlotValidation() {
        // TODO Auto-generated method stub
        int validCount = 0;
        
        Collection<AppSlotEntry> slotList= slots.values();
        if (!slotList.isEmpty()) {
            Iterator<AppSlotEntry> it = slotList.iterator();
            while (it.hasNext()) {
            	AppSlotEntry slotEntry = it.next();
                if (!slotEntry.isbValidated())
                {
                    if(SlotValidate(slotEntry.getName(), slotEntry.getValue()))
                    {
                        validCount++;
                        slotEntry.setbValid(true);
                    } else
                        slotEntry.setbValid(false);
                    slotEntry.setbValidated(true);
                }
                else if (slotEntry.isbValid())
                    validCount++;
            }           
        }
        return validCount;
    }
	/**
     * 如果有多个可控制的设备，则请用户选择一个。即只要设备类型符合用户需求，则将其配置的设备名称列出来给用户选择
     * 
     * @return
     */
    private boolean NeedSelectControlDevice(OutputMap out) {
        SelectdeviceList.clear();

        // 1.存在用户自定义的设备,唯一,即设备名称已知
        if ((commandInfo.getDeviceName() != null && !commandInfo.getDeviceName().isEmpty())
                || (commandInfo.getsplitName() != null && !commandInfo.getsplitName().isEmpty())) {
            if (commandInfo.getDeviceID() != null && !commandInfo.getDeviceID().isEmpty()) {
                SelectdeviceList.add(commandInfo.getDeviceID());
                return false;
            }
        }
        // 仅用于查询存在多少设备，调试用
        Map<String, HomeAutodeviceObjectNew> deviceList = homeAutoInfo
                .GetExitingDevicesNew();
        Iterator<Entry<String, HomeAutodeviceObjectNew>> entries = deviceList.entrySet()
                .iterator();

        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_deviceamount) {
            String answer = "目前共有" + deviceList.size() + "个设备.\r\n";
            String answer1 = "设备如下：\r\n";
            while (entries.hasNext()) {
                Entry<String, HomeAutodeviceObjectNew> device = entries.next();
                String key = device.getKey();
                answer += key + "\r\n";
            }
            out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer1, APP_NAME);
            return true;
        }
        // 2.指明设备类型
        if (commandInfo.getDeviceType() != 0) {
            // 对于通用设备名称，是否存在多个设备
            while (entries.hasNext()) {
                Entry<String, HomeAutodeviceObjectNew> device = entries.next();
                String key = device.getKey();
                HomeAutodeviceObjectNew deviceOb = device.getValue();

                switch (commandInfo.getDeviceType()) {
                case Devtype_TemperatrueControl:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircondition) {
                        SelectdeviceList.add(key);
                    }
                    break;
                case Devtype_HumidityControl:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Humidifier) {
                        SelectdeviceList.add(key);
                    }
                    break;
                case Devtype_AirqualityControl:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircleaner)
                        SelectdeviceList.add(key);
                    break;
                case Devtype_LightIntensityControl:
                    // 灯插在开关上
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Light)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_Aircleaner:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircleaner)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_Humidifier:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Humidifier)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_Aircondition:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircondition)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_WindowCovering:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_WindowCovering)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_Illuminations:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Illuminations)
                        SelectdeviceList.add(key);
                    break;
                case HomeAutoProtocol.Devtype_Light:
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Light)
                        SelectdeviceList.add(key);
                    break;
                default:
                    if (deviceOb.device_type == commandInfo.getDeviceType())
                        SelectdeviceList.add(key);
                    break;
                    }

                }
            // 如果没有指明要调节的功能
            if (!SelectdeviceList.isEmpty()) {

                if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_default
                        && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
                    String answer = "";
                    switch (commandInfo.getDeviceType()) {
                    case HomeAutoProtocol.Devtype_Aircleaner:
                        answer = "净化器有风力，定时功能，您可以说：帮我将净化器的风力调成中档";
                        break;
                    case HomeAutoProtocol.Devtype_Light:
                    case HomeAutoProtocol.Devtype_Humidifier:
                    case HomeAutoProtocol.Devtype_Dehumidifier:
                        answer = "您可以打开或者关闭该设备";
                        break;
                    }
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    //Status().SetCode(AppStatusCode.TOPIC_END);
                    return true;
                } else {
                    if (!SelectdeviceList.isEmpty() && SelectdeviceList.size() > 1) {
                        // 如果有多个传感器，查询时根据算法计算出最终结果，不需要用户选择
                        if ((commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_HumiditySensor
                                || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_AQISensor
                                || commandInfo
                                        .getDeviceType() == HomeAutoProtocol.Devtype_TemperatureSensor
                                || commandInfo
                                        .getDeviceType() == HomeAutoProtocol.Devtype_LightIntenSensor
                                || commandInfo
                                        .getDeviceType() == HomeAutoProtocol.Devtype_Co2Sensor)
                                && commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {

                            return false;

                        } else {
                            // 1.只有一级指令（目前仅支持无二级指令的设备的选择，比如灯）,即某些设备的命令只有一级指令，没有控制属性
                            if (isDeviceOnlysupportPrimaryCmd(commandInfo.getDeviceType())) {
                                // 如果仅有一个设备,则记录该设备的相关信息
                                    if (SelectdeviceList.size() == 1) {
                                        HomeAutodeviceObjectNew deviceObj = deviceList
                                                .get(SelectdeviceList.get(0));
                                    if ((commandInfo.getDeviceName() == null || commandInfo
                                            .getDeviceName().isEmpty())
                                                && deviceObj.description != null
                                                && !deviceObj.description.isEmpty())
                                        commandInfo.setDeviceName(deviceObj.description);
                                        if (deviceObj.position != null
                                                && !deviceObj.position.isEmpty())
                                        commandInfo.setPositionName(deviceObj.position);
                                    commandInfo.setDeviceID(deviceObj.device_ID);
                                    commandInfo.setDeviceType(deviceObj.device_type);

                                    } else if (SelectdeviceList.size() >= 2) {
                                    if (commandInfo.getCmdTypeFlag() == cmdTypeFlag.cmdtype_all)
                                        return false;
                                    if (isforShowroom) {
                                        // showroom中多个设备时默认打开第一个设备
                                        switch (commandInfo.getDeviceType()) {
                                        case HomeAutoProtocol.Devtype_Light:
                                            // 如果是关灯，若主灯关闭，壁灯打开，则选壁灯.若所有灯都关闭，提示灯是关闭的。否则选主灯
                                            // 如果是开灯，若主灯打开，壁灯关闭，则选壁灯。所有灯都是打开的，提示灯是打开的。否则选主灯
                                            HomeAutodeviceObjectNew mainlight = DedinedByUser("主灯");
                                            HomeAutodeviceObjectNew walllight = DedinedByUser("壁灯");
                                            SelectdeviceList.clear();
                                            int mainlightstatus = mainlight.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
                                            int walllightstatus =walllight.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
                                            if(commandInfo.getLastPrimaryCmd()==cmd_typePrimary.cmd_open){                                           
                                                if(mainlightstatus==1&&walllightstatus==0)
                                                    SelectdeviceList.add(walllight.device_ID);
                                                else if(mainlightstatus==1&&walllightstatus==1){
                                                    
                                                    out.AddSentence(
                                                            OutputMap.PRESENT_TTS_AND_DISPLAY,
                                                            "灯都打开了。",
                                                            APP_NAME);
                                                    //super.Status().Clear();
                                                    //Status().SetCode(AppStatusCode.TOPIC_END);
                                                    return true;
                                                }else{
                                                    SelectdeviceList.add(mainlight.device_ID);
                                                }
                                                
                                            } else if (commandInfo
                                                    .getLastPrimaryCmd() == cmd_typePrimary.cmd_close) {
                                                if (mainlightstatus == 0 && walllightstatus == 1)
                                                    SelectdeviceList.add(walllight.device_ID);
                                                else if (mainlightstatus == 0
                                                        && walllightstatus == 0) {

                                                    out.AddSentence(
                                                            OutputMap.PRESENT_TTS_AND_DISPLAY,
                                                            "灯是关着的。", APP_NAME);
//                                                    super.Status().Clear();
//                                                    Status().SetCode(AppStatusCode.TOPIC_END);
                                                    return true;
                                                } else {
                                                    SelectdeviceList.add(mainlight.device_ID);
                                                }
                                            }
                                                

                                            return false;
                                        default:
                                            HomeAutodeviceObjectNew deviceObj = deviceList
                                                .get(SelectdeviceList.get(0));
                                            if ((commandInfo.getDeviceName() == null
                                                    || commandInfo.getDeviceName().isEmpty())
                                                    && deviceObj.description != null
                                                    && !deviceObj.description.isEmpty())
                                                commandInfo.setDeviceName(deviceObj.description);
                                            if (deviceObj.position != null
                                                    && !deviceObj.position.isEmpty())
                                                commandInfo.setPositionName(deviceObj.position);
                                            commandInfo.setDeviceID(deviceObj.device_ID);
                                            commandInfo.setDeviceType(deviceObj.device_type);
                                            return false;

                                        }

                                    } else {
                                    	
                                    }
                                    }

                                // 2. 设备的一级命令支持属性控制,比如：调整净化器的风力
                            } else if (isDeviceSupportSecondCmd(commandInfo.getDeviceType())) {

                                // 如果是空调，则挑选可以控制的id
                                if (commandInfo
                                        .getDeviceType() == HomeAutoProtocol.Devtype_Aircondition) {
                                    HomeAutodeviceObjectNew aircontroldev = GetAirConditionControlDevice();
                                    if (aircontroldev != null && aircontroldev.device_ID != null) {
                                        SelectdeviceList.clear();
                                        SelectdeviceList.add(aircontroldev.device_ID);
                                        return false;
                                    }
                                }

                                // 控制风力，定时功能
                                if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setwindpower
                                        || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_settiming
                                        || (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setairquality && (commandInfo
                                                .getsecondCmd() == cmd_typeSecond.cmd_setup || commandInfo
                                                .getsecondCmd() == cmd_typeSecond.cmd_setdown))) {

                                    // 仅有一个设备
                                    if (SelectdeviceList.size() == 1) {
                                        HomeAutodeviceObjectNew deviceObj = deviceList
                                                .get(SelectdeviceList.get(0));
                                        if (deviceObj.description != null
                                                && !deviceObj.description.isEmpty())
                                            commandInfo.setDeviceName(deviceObj.description);
                                        if (deviceObj.position != null
                                                && !deviceObj.position.isEmpty())
                                            commandInfo.setPositionName(deviceObj.position);
                                        commandInfo.setDeviceID(deviceObj.device_ID);
                                        commandInfo.setDeviceType(deviceObj.device_type);
                                    } else if (SelectdeviceList.size() >= 2) {
                                    	
                                    }

                                } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_default
                                        && (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_weaklevel
                                                || commandInfo.getsecondCmd() == cmd_typeSecond.cmd_mediumlevel
                                                || commandInfo.getsecondCmd() == cmd_typeSecond.cmd_stronglevel
                                                || commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown || commandInfo
                                                .getsecondCmd() == cmd_typeSecond.cmd_setup)) {
                                    // 提供了设备类型和要操作的属性，比如把净化器调成低档

                                    // 如果仅有一个设备,则记录该设备的相关信息
                                    if (SelectdeviceList.size() == 1) {
                                        HomeAutodeviceObjectNew deviceObj = deviceList
                                                .get(SelectdeviceList.get(0));
                                        if ((commandInfo.getDeviceName() == null || commandInfo
                                                .getDeviceName().isEmpty())
                                                && deviceObj.description != null
                                                && !deviceObj.description.isEmpty())
                                            commandInfo.setDeviceName(deviceObj.description);
                                        if (deviceObj.position != null
                                                && !deviceObj.position.isEmpty())
                                            commandInfo.setPositionName(deviceObj.position);
                                        commandInfo.setDeviceID(deviceObj.device_ID);
                                        commandInfo.setDeviceType(deviceObj.device_type);

                                    } else if (SelectdeviceList.size() >= 2) {
                                    	
                                    }


                                }
                                
                            } else {
                            	
                            }
                            return true;
                        }
                    }
                    
                }
            }

        }else{
            // 仅有一级指令和二级指令的情况

            deviceList =homeAutoInfo .GetExitingDevicesNew();
            //Iterator<Entry<String, HomeAutodeviceObjectNew>> entries = deviceList.entrySet().iterator();
            // 如果是间接唤醒功能中的关闭所有可操作的设备
            // 举例：我出去了
            if (commandInfo.getCmdTypeFlag() == cmdTypeFlag.cmdtype_all
                    && commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close) {
                Iterator<Entry<String, HomeAutodeviceObjectNew>> iterList = deviceList.entrySet()
                        .iterator();
                while (iterList.hasNext()) {

                    Entry<String, HomeAutodeviceObjectNew> entry = iterList.next();
                    HomeAutodeviceObjectNew device = entry.getValue();
                    switch (device.device_type) {
                    case HomeAutoProtocol.Devtype_Light:
                    case HomeAutoProtocol.Devtype_WindowCovering:
                    case HomeAutoProtocol.Devtype_Aircondition:
                    case HomeAutoProtocol.Devtype_Humidifier:
                    case HomeAutoProtocol.Devtype_Aircleaner:
                    case HomeAutoProtocol.Devtype_Illuminations:
                    case HomeAutoProtocol.Devtype_Camera:
                    SelectdeviceList.add(entry.getKey());
                        break;
                    }
                }
                return false;
            }

            // 举例：帮我把风力调为高档
            if (isDeviceSupportAttributeControl()) {

                while (entries.hasNext()) {
                    Entry<String, HomeAutodeviceObjectNew> device = entries.next();
                    String key = device.getKey();
                    HomeAutodeviceObjectNew deviceOb = device.getValue();
                    // 检查是否有净化器
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircleaner)
                        SelectdeviceList.add(key);
                }
                if (SelectdeviceList.size() >= 2) {
                	
                } else if (SelectdeviceList.size() == 1) {

                    HomeAutodeviceObjectNew deviceobj = deviceList.get(SelectdeviceList.get(0));
                    commandInfo.setDeviceName(deviceobj.description);
                    commandInfo.setDeviceType(deviceobj.device_type);
                    commandInfo.setDeviceID(deviceobj.device_ID);
                    commandInfo.setPositionName(deviceobj.position);
                }

            }
            // 用户仅提供了一级指令，并且设备支持这种用法
            // 比如 “设置定时关闭功能”，"给净化器定时"
            if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_settiming || commandInfo
                    .getprimaryCmd() == cmd_typePrimary.cmd_setwindpower)
                    && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
                // 获取符合要求的设备
                while (entries.hasNext()) {
                    Entry<String, HomeAutodeviceObjectNew> device = entries.next();
                    String key = device.getKey();
                    HomeAutodeviceObjectNew deviceOb = device.getValue();
                    // 目前仅净化器支持这个功能
                    if (deviceOb.device_type == HomeAutoProtocol.Devtype_Aircleaner)
                            SelectdeviceList.add(key);
                }
                if (!SelectdeviceList.isEmpty()) {
                    if (SelectdeviceList.size() == 1) {
                        HomeAutodeviceObjectNew deviceObj = deviceList.get(SelectdeviceList.get(0));
                        if (deviceObj.description != null && !deviceObj.description.isEmpty())
                            commandInfo.setDeviceName(deviceObj.description);
                        if (deviceObj.position != null && !deviceObj.position.isEmpty())
                            commandInfo.setPositionName(deviceObj.position);
                        commandInfo.setDeviceID(deviceObj.device_ID);
                        commandInfo.setDeviceType(deviceObj.device_type);
                    } else {
                    	
                    }
                }

            }

        }

        return false;
    }

    private boolean isDeviceSupportAttributeControl() {
        // TODO Auto-generated method stub
        boolean ret = false;
        for (int i = 0; i < DeviceSupportAttrControlList.size(); i++) {
            cmd_control_info attrcon = DeviceSupportAttrControlList.get(i);
            if (attrcon.getPrimaryCmd() == commandInfo.getprimaryCmd()
                    && attrcon.getSecondCmd() == commandInfo.getsecondCmd()) {
                ret = true;
                break;
            }
        }
        return ret;
    }

    /**
     * 如果一级命令没有可以操作的属性，即符合要求
     * 
     * @param device_type
     * @return
     */
    private boolean isDeviceOnlysupportPrimaryCmd(int device_type) {
        // TODO Auto-generated method stub
        boolean ret = false;

        List<cmd_typePrimary> primaryCmdList = new ArrayList<cmd_typePrimary>();
        primaryCmdList.add(cmd_typePrimary.cmd_open);
        primaryCmdList.add(cmd_typePrimary.cmd_close);
        if (primaryCmdList.contains(commandInfo.getprimaryCmd())
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default)
            ret = true;

        return ret;
    }

    private boolean isDeviceSupportSecondCmd(int device_type) {
        boolean ret = false;
        List<Integer> devtypeList = new ArrayList<Integer>();
        devtypeList.add(HomeAutoProtocol.Devtype_Aircleaner);
        devtypeList.add(Devtype_AirqualityControl);
        devtypeList.add(HomeAutoProtocol.Devtype_WindowCovering);
        devtypeList.add(HomeAutoProtocol.Devtype_Humidifier);
        devtypeList.add(HomeAutoProtocol.Devtype_Aircondition);
        if (devtypeList.contains(device_type))
            ret = true;
        return ret;
    }
    private String GetAirLevelString(int statusvalue) {
        // TODO Auto-generated method stub
        String value = "良";

        if (statusvalue >= 0 && statusvalue <= 50) // 优
            value = "优等";
        else if (statusvalue <= 100 && statusvalue >= 51)// 良
            value = "良好";
        else if (statusvalue >= 101 && statusvalue <= 150)// 轻度污染
            value = "轻度污染";
        else if (statusvalue >= 151 && statusvalue <= 200)// 中度污染
            value = "中度污染";
        else if (statusvalue >= 201 && statusvalue <= 300)// 重度污染
            value = "重度污染";
        else if (statusvalue >= 301)// 严重污染
            value = "严重污染";
        return value;
    }
    
    private String getAirLevelString(int level) {
        // TODO Auto-generated method stub
        String value = "";
        switch (level) {
        case 1:
            value = "优等";
            break;
        case 2:
            value = "良好";
            break;
        case 3:
            value = "轻度污染";
            break;
        case 4:
            value = "中度污染";
            break;
        case 5:
            value = "重度污染";
            break;
        case 6:
            value = "严重污染";
            break;
        }
        return value;
    }
    private boolean HaveOperableDevice(OutputMap out) {
        // TODO Auto-generated method stub
        // 没有设备的情况
        // 空调目前由两个模块控制，因此都在线才可以控制空调
        if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircondition) {
            HomeAutodeviceObjectNew aircontroldev = GetAirConditionControlDevice();
            HomeAutodeviceObjectNew airstatusDev = this.GetAirConditionStatusDevice();
            if (aircontroldev == null || airstatusDev == null) {
                SelectdeviceList.clear();
            } else if (aircontroldev.device_ID != null) { // 挑选可以控制的id
                SelectdeviceList.clear();
                SelectdeviceList.add(aircontroldev.device_ID);

            }
        }
        if (SelectdeviceList.isEmpty()) {

            if (HasModifier("setwindpower", "control_obj")) {
                if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircondition
                        || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircleaner) {
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，您还没有设置空调或者净化器",
                            APP_NAME);
                } else
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，您还没有可以调节风力的设备哦",
                            APP_NAME);
            } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setairquality) {
                // 检查是否有传感器设备
                HomeAutodeviceObjectNew[] devicelist =homeAutoInfo.GetDeviceObjByDevType(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25, Attribute_id0);
                if (devicelist.length == 0)
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "抱歉，查不到室内的空气质量，无法给您建议哦。",
                            APP_NAME);
                else if (devicelist.length >= 1) {
                    int level = GetSensorLevel(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25,
                            Attribute_id0);
                    if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
                        if (level == 1 || level == 2) {
                            String levelstr = getAirLevelString(level);
                            String answer = "现在的空气质量是"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25,
                                            Attribute_id0) + "ug/m3," + levelstr + ".";
                            String voice = "现在的空气质量是"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                            cluster_PM25, Attribute_id0)
                                    + "微克每立方米," + levelstr
                                    + ".";
                            out.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
                            out.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);
                        }else{
                            out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "抱歉，您还没有设置空气净化器",
                                    APP_NAME);
                        }
                    } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
                        String levelstr = getAirLevelString(level);
                        String answer = "现在的空气质量是"
                                + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25,
                                        Attribute_id0) + "ug/m3," + levelstr + ".";
                        String voice = "现在的空气质量是"
                                + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25,
                                        Attribute_id0)
                                + "微克每立方米," + levelstr + ".";
                        out.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
                        out.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);
                   }
                }

            } else if (HasModifier("setwinddirection", "control_obj")) {
                if (commandInfo.getDeviceType() != HomeAutoProtocol.Devtype_Aircondition) {
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的设备不支持风向调节功能",
                                APP_NAME);
                } else
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，您还没有设置空调", APP_NAME);
            } else if (HasModifier("settemperature", "control_obj")) {
                if (commandInfo.getDeviceType() != HomeAutoProtocol.Devtype_Aircondition) {
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的设备不支持温度调节功能",
                                APP_NAME);
                } else
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，您还没有设置空调", APP_NAME);

            } else if (HasModifier("setmod", "control_obj")) {
                if (commandInfo.getDeviceType() != HomeAutoProtocol.Devtype_Aircondition) {
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的设备不支持模式调节功能",
                                APP_NAME);
                } else
                    out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，您还没有设置空调。", APP_NAME);

            } else {

            String Answer = "";
                switch (commandInfo.getDeviceType()) {
            case Devtype_TemperatrueControl:
                    Answer = "对不起，您还没有设置温度控制类设备";
                break;
            case Devtype_HumidityControl:
                    Answer = "对不起，您还没有设置湿度控制类设备";
                break;
            case Devtype_AirqualityControl:
                    Answer = "对不起，您还没有设置净化空气的设备";
                break;
            case Devtype_LightIntensityControl:
                    Answer = "对不起，您还没有设置光线调节类设备";
                break;

            default:
                if (HasModifier("tempexceed", "control_obj")
                        || HasModifier("humexceed", "control_obj")
                        || HasModifier("airexceed", "control_obj")
                        || HasModifier("lightexceed", "control_obj")) {
                        out.AddSentence(OutputMap.PRESENT_DISPLAY, "跟我说话呗！", APP_NAME);
                } else {
                    String name = getDeviceName();
                    if (name == null || name.isEmpty())
                            out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "对不起，您还没有设置该设备！",
                                APP_NAME);
                    else
                            out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "对不起，您还没有设置"
                                    + name,
                                APP_NAME);

                }
                break;
            }
                out.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, Answer, APP_NAME);
            }
//            super.Status().SetCode(AppStatusCode.TOPIC_END);
            return false;
        }

        return true;
    }
    /**
     * 用于确定设备类型之后的输出
     * 
     * @return
     */
    private OutputMap ResultOutput() {
        // TODO Auto-generated method stub
        
        OutputMap output = new OutputMap();
        
        if (!HaveOperableDevice(output))
            return output;

        // 如果需要同时操作多个设备
        if (SelectdeviceList.size() > 1
                && commandInfo.getCmdTypeFlag() != cmdTypeFlag.cmdtype_default) {
            for (int i = 0; i < SelectdeviceList.size(); i++) {
                HomeAutodeviceObjectNew device = homeAutoInfo
                        .GetDeviceObjByDeviceID(SelectdeviceList.get(i));
                if (device != null) {
                    commandInfo.setDeviceInfo(device);
                    ResultOutputNormal(output);
                }
            }
            SaveHomeAutoCmd(output);
        } else {

            // if ((commandInfo.getDeviceID() != null &&
            // !commandInfo.getDeviceID().isEmpty())) {
            //
            // } else {
                HomeAutodeviceObjectNew device = homeAutoInfo
                        .GetDeviceObjByDeviceID(SelectdeviceList.get(0));
                if (device != null)
                    commandInfo.setDeviceInfo(device);
            // }

            int appstatus = ResultOutputNormal(output);
            SaveHomeAutoCmd(output);
           
        }

        return output;
    }

    private void ResetCommandInfo() {
        commandInfo.Reset();
    }
  private void resetDeviceAttributeStatus() {
        // TODO Auto-generated method stub
        Map<String, HomeAutodeviceObjectNew> deviceList = homeAutoInfo.GetExitingDevicesNew();
        Iterator<Entry<String, HomeAutodeviceObjectNew>> entries = deviceList.entrySet().iterator();
        while (entries.hasNext()) {
            HomeAutodeviceObjectNew devobj = entries.next().getValue();
            devobj.resetUpdatedStatus();
        }
  }
private OutputMap CapsOutput() {
        // TODO Auto-generated method stub
        return null;
    }
protected OutputMap GetResult() {
        // TODO Auto-generated method stub
        ClearAppCmd();
        SetModifier();
       
        

        boolean bCheckCaps = HasModifier("can");

        OutputMap out = new OutputMap();

        if (bCheckCaps)
        {
           out = CapsOutput();
        } else if (NeedSelectControlDevice(out))
            {
                
            } else {
                out = ResultOutput();
            }
        // reset commondinfo中moregrammar flag,这是因为 selection ,confirm grammar
        // 不会经过validate.
        commandInfo.setMoreGrammarFlag(false);
        commandInfo.setEntryGrammarFlag(false);
        commandInfo.setCurrentDevType(false);

        // reset attribute updated status
        resetDeviceAttributeStatus();
        slots.remove("sensorvalue");
        
        return out;
    }
private void SetModifier() {
    // TODO Auto-generated method stub
    
    // 仅希望调节某个设备，但没有具体的指令
    if (HasModifier("set", "control_obj") && GetModifier("control_obj").size() == 1) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
    }
    commandInfo.setCmdTypeFlag(cmdTypeFlag.cmdtype_default);
    boolean hasprimaryCmd = false;
    boolean hassecondCmd = false;
    // 一级指令
    // 如果有类似"继续"的说法
    /*
     * 1.如果上次对话中有“停止”的说法，则沿用上上次对话的状态2.如果上次对话中没有"停止"的说法，则沿用上次对话的状态
     */

    if (HasModifier("continue", "control_obj")) {
        commandInfo.setPrimaryCmd(commandInfo.getLastPrimaryCmd());
        hasprimaryCmd = true;
    } else if (HasModifier("open", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_open);
        hasprimaryCmd = true;
    } else if (HasModifier("close", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_close);
        hasprimaryCmd = true;
    } else if (HasModifier("stop", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_stop);
        hasprimaryCmd = true;
    } else if (HasModifier("setwindpower", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setwindpower);
        hasprimaryCmd = true;
    } else if (HasModifier("query", "control_obj")) {// 查询状态
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_query);
      
        hasprimaryCmd = true;
    } else if (HasModifier("settemperature", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_settemperature);
        hasprimaryCmd = true;
    } else if (HasModifier("setwinddirection", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setwinddirection);
        hasprimaryCmd = true;
    } else if (HasModifier("setairquality", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setairquality);
        commandInfo.setDeviceType(Devtype_AirqualityControl);
        hasprimaryCmd = true;
    } else if (HasModifier("sethumidity", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_sethumidity);
        commandInfo.setDeviceType(Devtype_HumidityControl);
        hasprimaryCmd = true;
    } else if (HasModifier("settiming", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_settiming);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("setlightintensity", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setlightintensity);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("identify", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_identify);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("setmod", "control_obj")) { // 调整模式
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setmod);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("changechannel", "control_obj")) { // 换台
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_changechannel);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("setvolume", "control_obj")) { // 音量调节
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setvolume);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("back", "control_obj")) { // 返回
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_getback);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    } else if (HasModifier("confirm", "control_obj")) { // 确认
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_confirm);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
        hasprimaryCmd = true;
    }
    else if (HasModifier("setcolor", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setcolor);
        hasprimaryCmd = true;
    } else if (HasModifier("setatmosphere", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setatmosphere);
        hasprimaryCmd = true;
    } else if (HasModifier("setwarm", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setwarm);
        hasprimaryCmd = true;
    } else if (HasModifier("setbright", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setbright);
        hasprimaryCmd = true;
    } else if (HasModifier("setcute", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setcute);
        hasprimaryCmd = true;
    } else if (HasModifier("setcool", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setcool);
        hasprimaryCmd = true;
    } else if (HasModifier("setsport", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setsport);
        hasprimaryCmd = true;
    } else if (HasModifier("setgrace", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setgrace);
        hasprimaryCmd = true;
    } else if (HasModifier("setcalm", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setcalm);
        hasprimaryCmd = true;
    } else if (HasModifier("setlevel", "control_obj")) {
        if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircleaner)
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setwindpower);
        else
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_setlevel);
        hasprimaryCmd = true;
    } else if (HasModifier("satuup", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_satuup);
        hasprimaryCmd = true;
    } else if (HasModifier("satudown", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_satudown);
        hasprimaryCmd = true;
    } else if (HasModifier("lightup", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_lightup);
        hasprimaryCmd = true;
    } else if (HasModifier("lightdown", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_lightdown);
        hasprimaryCmd = true;
    } else if (HasModifier("warmer", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_warmer);
        hasprimaryCmd = true;
    } else if (HasModifier("brighter", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_brighter);
        hasprimaryCmd = true;
    } else if (HasModifier("cuter", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_cuter);
        hasprimaryCmd = true;
    } else if (HasModifier("cooler", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_cooler);
        hasprimaryCmd = true;
    } else if (HasModifier("sporter", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_sporter);
        hasprimaryCmd = true;
    } else if (HasModifier("gracer", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_gracer);
        hasprimaryCmd = true;
    } else if (HasModifier("calmer", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_calmer);
        hasprimaryCmd = true;
    } else if (HasModifier("deviceamount", "control_obj")) { // 查询当前有多少设备
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_deviceamount);
        hasprimaryCmd = true;
    }
    /*
     * else if (HasModifier("altercolor", "control_obj")) {
     * commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_altercolor);
     * hasprimaryCmd = true; }
     */
    else if (HasModifier("altertone", "control_obj")) {
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_altertone);
        hasprimaryCmd = true;
    } else if (HasModifier("extralfun1", "control_obj")) { // 因为extrafun1有耳机的开关命令，因此必须在open,close的一级命令之前
        commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_extralfun1);
        hasprimaryCmd = true;
    }

    // 二级指令
    if (HasModifier("continue", "control_obj")) {
        commandInfo.setSecondCmd(commandInfo.getLastSecondCmd());
        hassecondCmd = true;
    } else if (HasModifier("weak", "control_obj")) {// 低档
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_weaklevel);
        hassecondCmd = true;
        // 如果没有一级指令，且上次对话中没有对应的一级指令，则情况一级指令。用于上下文，例如：
        // 帮我打开净化器1
        // 把净化器1调成低档
        if (hasprimaryCmd == false
                && commandInfo.getprimaryCmd() != cmd_typePrimary.cmd_setwindpower) {
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        }
    } else if (HasModifier("medium", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_mediumlevel);// 中档
        hassecondCmd = true;
        if (hasprimaryCmd == false
                && commandInfo.getprimaryCmd() != cmd_typePrimary.cmd_setwindpower) {
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        }
    } else if (HasModifier("strong", "control_obj")) { // 高档
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_stronglevel);
        hassecondCmd = true;
        if (hasprimaryCmd == false
                && commandInfo.getprimaryCmd() != cmd_typePrimary.cmd_setwindpower) {
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        }

    } else if (HasModifier("setup", "control_obj")) {// 高一点
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setup);
        hassecondCmd = true;
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open && hasprimaryCmd == false
                && commandInfo.getDeviceType() != HomeAutoProtocol.Devtype_WindowCovering) {
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        }
        // fixed bug: 打开窗帘/停止/再多一点---不能继续打开
        if (hasprimaryCmd == false && commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop
                && commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WindowCovering)
            commandInfo.setPrimaryCmd(commandInfo.getLastPrimaryCmd());
    } else if (HasModifier("setdown", "control_obj")) {// 高一点
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setdown);
        hassecondCmd = true;
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open && hasprimaryCmd == false
                && commandInfo.getDeviceType() != HomeAutoProtocol.Devtype_WindowCovering) {
            commandInfo.setPrimaryCmd(cmd_typePrimary.cmd_default);
        }
        // fixed bug: 打开窗帘/停止/再少一点---不能继续打开
        if (hasprimaryCmd == false && commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop
                && commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WindowCovering)
            commandInfo.setPrimaryCmd(commandInfo.getLastPrimaryCmd());
    } else if (HasModifier("setleft", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setleft);
        hassecondCmd = true;
    } else if (HasModifier("setright", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setright);
        hassecondCmd = true;
    } else if (HasModifier("setnext", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setnext);
        hassecondCmd = true;
    } else if (HasModifier("setlast", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_setlast);
        hassecondCmd = true;
    } else if (HasModifier("cancel", "control_obj")) {// 关闭某个功能
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_cancel);
        hassecondCmd = true;
    } else if (HasModifier("enable", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_enable);
        hassecondCmd = true;
    } else if (HasModifier("degree", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_degree);
        hassecondCmd = true;
    } else if (HasModifier("rest", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_restmod);
        hassecondCmd = true;
    } else if (HasModifier("mute", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_mutemod);
        hassecondCmd = true;
    } else if (HasModifier("romantic", "control_obj")) { // 浪漫
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_romantic);
        hassecondCmd = true;
    } else if (HasModifier("soft", "control_obj")) { // 柔和
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_soft);
        hassecondCmd = true;
    } else if (HasModifier("mystery", "control_obj")) { // 神秘
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_mystery);
        hassecondCmd = true;
    } else if (HasModifier("cold", "control_obj")) { // 制冷模式
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_coldmod);
        hassecondCmd = true;
    } else if (HasModifier("cool", "control_obj")) { // 凉爽模式
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_coolmod);
        hassecondCmd = true;
    } else if (HasModifier("airsupply", "control_obj")) { // 送风模式
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_airsupplymod);
        hassecondCmd = true;
    } else if (HasModifier("change", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_change);
        hassecondCmd = true;
    } else if (HasModifier("hot", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_hotmod);
        hassecondCmd = true;
    } else if (HasModifier("auto", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_automod);
        hassecondCmd = true;
    } else if (HasModifier("sweep", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_sweepmod);
        hassecondCmd = true;
    } else if (HasModifier("dehu", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_dehumidifymod);
        hassecondCmd = true;
    } else if (HasModifier("normal", "control_obj")) {// 适中模式
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_normalmod);
        hassecondCmd = true;
    } else if (HasModifier("attrtemperature", "control_obj")) {// 查询温度
        if (commandInfo.getDeviceType() == 0 && (commandInfo.getDeviceName() == null
                || commandInfo.getDeviceName().isEmpty()))
            commandInfo.setDeviceType(HomeAutoProtocol.Devtype_TemperatureSensor);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrtemperature);
        hassecondCmd = true;
    } else if (HasModifier("attrhumidity", "control_obj")) {
        commandInfo.setDeviceType(HomeAutoProtocol.Devtype_HumiditySensor);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrhumidity);
        hassecondCmd = true;
    } else if (HasModifier("attrairquality", "control_obj")) {
        commandInfo.setDeviceType(HomeAutoProtocol.Devtype_AQISensor);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrairquality);
        hassecondCmd = true;
    } else if (HasModifier("arrtlightintensity", "control_obj")) {
        commandInfo.setDeviceType(HomeAutoProtocol.Devtype_LightIntenSensor);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrlightintensity);
        hassecondCmd = true;
    } else if (HasModifier("attrco2", "control_obj")) {
        commandInfo.setDeviceType(HomeAutoProtocol.Devtype_Co2Sensor);
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrco2);
        hassecondCmd = true;
    } else if (HasModifier("attrmod", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrmode);
        hassecondCmd = true;
    } else if (HasModifier("attrwindpower", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrwindpower);
        hassecondCmd = true;
    } else if (HasModifier("attrwinddirection", "control_obj")) {
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_attrwinddirection);
        hassecondCmd = true;
    }

     
    // 仅有一级指令时，清除保留的二级指令信息
    if (hasprimaryCmd == true && hassecondCmd == false)
        commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);

    
//    // 为了支持，净化器的定时是关闭的情况下，用户要求缩短定时时间
//    if(super.Status().code() == AppStatusCode.WAITING_FOR_SLOT_REPLY){
//        AppSlotEntry timeslot = GetSlotByName("slot_timing");
//        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_settiming && timeslot != null)
//            commandInfo.setSecondCmd(cmd_typeSecond.cmd_default);
//    }

    // flag
    if (HasModifier("all", "control_obj"))
        commandInfo.setCmdTypeFlag(cmdTypeFlag.cmdtype_all);

    // 将当前的命令状态保存到上一个状态中
    // 但不保存"停止"命令
    if (commandInfo.getprimaryCmd() != cmd_typePrimary.cmd_stop) {
        // 如果是窗帘的停止命令，则不保存
        if(!(commandInfo.getDeviceType()==HomeAutoProtocol.Devtype_WindowCovering&&commandInfo.getprimaryCmd()==cmd_typePrimary.cmd_stop))
            commandInfo.setLastPrimaryCmd(commandInfo.getprimaryCmd());
        commandInfo.setLastSecondCmd(commandInfo.getsecondCmd());
        commandInfo.setLastCmdTypeFlad(commandInfo.getCmdTypeFlag());
    }
}

private void AddHomeAutoCmd(JSONObject subCmd) {
    DevArray.element(subCmd);

}

private void SaveHomeAutoCmd(OutputMap output) {
    AppCmd.put("devlist", DevArray);

    if (!DevArray.isEmpty())
        output.AddAppCommand("App Name", AppCmd);
}

private void ClearAppCmd() {
    DevArray.clear();
}
private String GetDeviceID() {
    // TODO Auto-generated method stub
       String DeviceID = "";
       if (commandInfo.getDeviceType() == 0)
        return DeviceID;
       if (commandInfo.getPositionName() == null || commandInfo.getPositionName().isEmpty())
           commandInfo.setPositionName("");
       if (commandInfo.getDeviceID() != null && !commandInfo.getDeviceID().isEmpty())
           return commandInfo.getDeviceID();

    
    Map<String,HomeAutodeviceObjectNew> exitingdevice=homeAutoInfo.GetExitingDevicesNew();

    for (Iterator<String> ob = exitingdevice.keySet().iterator(); ob.hasNext();) {  
         String key = ob.next();
         HomeAutodeviceObjectNew deviceOb=exitingdevice.get(key);

           if (deviceOb.description != null && !deviceOb.description.isEmpty()
                   && commandInfo.getDeviceName() != null
                   && !commandInfo.getDeviceName().isEmpty()
                   && deviceOb.description.equals(commandInfo.getDeviceName())) {

               DeviceID = key;
               break;
           } else if (deviceOb.device_type == commandInfo.getDeviceType()) {
            DeviceID=key;
            break;
        }
        
       } 
    return DeviceID;
    
}

private void CheckDeviceStatusNew() {

    // 更新属性level
    Map<String, HomeAutodeviceObjectNew> exitingdevice =homeAutoInfo.GetExitingDevicesNew();
    for (Iterator<String> ob = exitingdevice.keySet().iterator(); ob.hasNext();) {
        String key = ob.next();
        HomeAutodeviceObjectNew deviceOb = exitingdevice.get(key);
        // 1.reset command level
        // deviceOb.setControlCMDTypeDefault();
        // 2.update attribute level
        HomeAutoAttributeObject param;
        switch (deviceOb.device_type) {
        case HomeAutoProtocol.Devtype_AQISensor:
            param = deviceOb.ishaveAttribute(cluster_PM25, Attribute_id0);
            if (param != null)
                param.SetAttributeLevel(GetAirLevel(param.GetAttributeValue()));
            break;
        case HomeAutoProtocol.Devtype_HumiditySensor:
            param = deviceOb.ishaveAttribute(cluster_HumiditySensor, Attribute_id0);
            if (param != null)
                param.SetAttributeLevel(GetHumidityStatus(param.GetAttributeValue()));
            break;
        case HomeAutoProtocol.Devtype_LightIntenSensor:
            param = deviceOb.ishaveAttribute(cluster_LightInten, Attribute_id0);
            if (param != null)
                param.SetAttributeLevel(GetLightIntensityStatus(param.GetAttributeValue()));
            break;

        }
    }

    }
private int GetHumidityStatus(int statusvalue) {
    // TODO Auto-generated method stub
    int status=0;

    if (statusvalue >= 30 && statusvalue <= 55) // 舒适
        status=1;
    else if (statusvalue < 30 && statusvalue >= 20)// 比较干燥
        status=2;
    else if (statusvalue < 20)// 干燥
        status=3;
    else if (statusvalue > 55 && statusvalue < 75)// 湿润
        status=4;
    else if (statusvalue > 75)// 过于湿
        status = 5;
    return status;
}

private String GetHumidityLevelString(int statusvalue) {
    String value = "舒适";
    if (statusvalue >= 30 && statusvalue <= 55) // 舒适
        value = "舒适";
    else if (statusvalue < 30 && statusvalue >= 20)// 比较干燥
        value = "比较干燥";
    else if (statusvalue < 20)// 干燥
        value = "干燥";
    else if (statusvalue > 55 && statusvalue < 75)// 湿润
        value = "湿润";
    else if (statusvalue > 75)// 过于湿
        value = "过于潮湿";

    return value;
}
private int GetLightIntensityStatus(int AttributeValue) {
    // TODO Auto-generated method stub
    int lightstatus = 1; // 默认为正常状态

    if (AttributeValue >= 0 && AttributeValue <= 20) // 特亮
        lightstatus = attribute_level0;
    else if (AttributeValue > 20 && AttributeValue <= 55)// 亮
        lightstatus = attribute_level1;
    else if (AttributeValue > 55 && AttributeValue <= 100) // 正常
        lightstatus = attribute_level2;
    else if (AttributeValue > 100 && AttributeValue <= 150) // 较暗
        lightstatus = attribute_level3;
    else if (AttributeValue > 150) // 暗，需要开灯
        lightstatus = attribute_level4;

    return lightstatus;
}
private int GetAirLevel(int statusvalue) {
    // TODO Auto-generated method stub
    int status=0;

        if (statusvalue >= 0 && statusvalue <= 50) // 优
            status = 1;
        else if (statusvalue <= 100 && statusvalue >= 51)// 良
            status = 2;
        else if (statusvalue >= 101 && statusvalue <= 150)// 轻度污染
        status=3;
        else if (statusvalue >= 151 && statusvalue <= 200)// 中度污染
        status=4;
        else if (statusvalue >= 201 && statusvalue <= 300)// 重度污染
        status=5;
        else if (statusvalue >= 301)// 严重污染
        status=6;
    return status;
}

/**
 * 
 * @param output
 * @return app status
 */
@SuppressWarnings("incomplete-switch")
private int ResultOutputNormal(OutputMap output) {
    // TODO Auto-generated method stub
    //
    // if (!HaveOperableDevice(output))
    // return false;
    // 获取设备的唯一编号
    int appStatus = AppStatusCode.TOPIC_END;
    NormalcontrolDevIDList.clear();
    String deviceID = null;
    HomeAutodeviceObjectNew deviceobj = null;
    JSONObject command = new JSONObject();
    
    if (SelectdeviceList.size() >1
            && this.commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query
            && (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_HumiditySensor
                    || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_LightIntenSensor
                    || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_TemperatureSensor || commandInfo
                            .getDeviceType() == HomeAutoProtocol.Devtype_AQISensor
                    || commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Co2Sensor)) {

    } else {

    deviceID = GetDeviceID();
    if (deviceID == null || deviceID.isEmpty()) {
        ResetCommandInfo();
//            super.Status().SetCode(appStatus);
//            return appStatus;
    }
        // 获取当前的设备描述
    deviceobj = homeAutoInfo.GetDeviceObjByDeviceID(deviceID);
    
    command.put("dev_id", deviceID);
    command.put("dev_type", deviceobj.device_type);
    command.put("name",getDevtypeName() );
    }

   CheckDeviceStatusNew();


   
    
    String answer = "";
    String devName = getAnswerName();

    switch (commandInfo.getDeviceType()) {
    case HomeAutoProtocol.Devtype_Illuminations: {
        // 彩灯
        // TODO Auto-generated method stub
        JSONObject command0 = new JSONObject();
        command0.put("App Name", "Illuminations");
        // 获取当前颜色的值
        int RGBvalue = deviceobj.GetArributeValue(cluster_General_Time, Attribute_id3);
        int onoffstatus = deviceobj.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
       
        // 获取当前颜色的所有信息
        colourStatus currentstatus = getcurrentColorStatus(RGBvalue);
        switch (commandInfo.getprimaryCmd()) {
        case cmd_open: {
            if (onoffstatus == 1&&onoffstatus!=Integer.MAX_VALUE) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, devName + "是打开的哦",
                        APP_NAME);
            } else {

                command.put("action_id", 0x01);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_open);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                AddHomeAutoCmd(command);
                deviceobj.SetArributeValue(1, cluster_Onoff_Switch, Attribute_id0);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "马上为您打开" + devName,
                        APP_NAME);
            }
        }
            break;
        case cmd_close:
        case cmd_stop: {
            if (onoffstatus == 0&&onoffstatus!=Integer.MAX_VALUE) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, devName + "已经关掉了",
                        APP_NAME);
            } else {
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_close);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                AddHomeAutoCmd(command);
                deviceobj.SetArributeValue(0, cluster_Onoff_Switch, Attribute_id0);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "马上为您关闭彩灯", APP_NAME);
            }
        }
            break;
        // 调整颜色
        case cmd_setcolor: {
            AppSlotEntry colorslot = GetSlotByName("color");

            switch (commandInfo.getsecondCmd()) {
            case cmd_change: {
                // 按照UX提取一种颜色 colourHSB
                colourStatus newcolor = GetColor(deviceobj);
                if (newcolor != null) {
                    commandInfo.setAdjustcolor(newcolor);
                    int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                    int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                    AdjustColourLightRGB(command, rgvalue, bvalue);
                    deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                }
            }
                break;
            default: {
                // 这种情况可以单独放在questionGenerate里面
                if (colorslot == null || colorslot.getValue().isEmpty()) {

                	 // 按照UX提取一种颜色 colourHSB
                    colourStatus newcolor = GetColor(deviceobj);
                    if (newcolor != null) {
                        commandInfo.setAdjustcolor(newcolor);
                        int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                        int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                        AdjustColourLightRGB(command, rgvalue, bvalue);
                        deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                    }
                } else {
                    if (colorslot.isbValid()) {
                        // 如果灯是关着的,也直接调整颜色
                        int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue()
                                & 0xFFFF00) >> 8;
                        int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue()
                                & 0x0000FF) << 8;

                        AdjustColourLightRGB(command, rgvalue, bvalue);
                        deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY,
                                "已经调成" + colorslot.getValue() + "色",
                                APP_NAME);
                    } else {
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "对不起，暂时不支持您说的颜色哦",
                                APP_NAME);
                    }
                }

            }

                break;

            }

        }
            break;
        case cmd_satuup: {
            // 提供调整目标

            AppSlotEntry colorslot = GetSlotByName("color");
            if (colorslot != null && !colorslot.getValue().isEmpty() &&
                    !HasModifier("more", "control_obj")) {
                // 颜色调的再红一些
                // //若要调整的颜色和当前的颜色的H相同，表示要加强当前颜色的饱和度，s调大，每次调整25%，不超过1。
                if (Math.abs(commandInfo.getAdjustcolor().GetHvalue()
                        - currentstatus.GetHvalue()) <= allowdiffer) {
                    double currentS = currentstatus.GetSvalue();
              
                    if (currentS < 1) {
                        double h = currentstatus.GetHvalue();
                        double s = 0.0;
                        double b = currentstatus.GetBvalue();

                        // command0.put("on", 1);
                        // command0.put("hue", currentstatus.GetHvalue());
                        if (HasModifier("max", "control_obj")) {
                            s = 1;
                        } else {
                            double newS = 0;
                            if (currentS == 0.0)
                                newS = 0.5;
                            else
                                newS = (currentS + currentS * 0.25 >= 1) ? 1
                                        : currentS + currentS * 0.25;
                            s = newS;

                        }
                        int[] convertRGB = hsb2rgb(h, s, b);
                        AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                                convertRGB[3] << 8);
                        int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                        deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整",
                                APP_NAME);
                    } else {
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY,
                                "当前的颜色的明亮程度已经最大了哦", APP_NAME);
                    }
              
                } // 若跟当前颜色的H不相同，则表示要向新的颜色调整，调整H
              
                else {
                    if (HasModifier("max", "control_obj")) { 
                        // 直接调整为要调整的蓝色
                        // 为了演示效果，直接调整为要调整的颜色
                        
                        int rgvalue=(commandInfo.getAdjustcolor().GetRGBvalue()&0xFFFF00)>>8;
                        int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;

                        AdjustColourLightRGB(command, rgvalue, bvalue);
                    } else { // 每次向要调整的颜色调25%
                        double newH = currentstatus.GetHvalue()
                                + (commandInfo.getAdjustcolor().GetHvalue() - currentstatus.GetHvalue()) * 0.25;
                        int[] convertRGB = hsb2rgb(newH, currentstatus.GetSvalue(),
                                currentstatus.GetBvalue());
                        
                        AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                                       convertRGB[3] << 8);
                        int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                        deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                    }
                   
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
              
              }
              
            } else { // 例如：帮我把颜色调的深一点
              
                double currentS = currentstatus.GetSvalue();
                double newS = 0.0;
                if (currentS < 1) {
                    if (HasModifier("max", "control_obj")) {
                        newS = 1;
                    } else { // 在当前颜色的基础上调高饱和度S

                        newS = (currentS + currentS * 0.25 >= 1) ? 1
                                : currentS + currentS * 0.25;

                    }
                    int[] convertRGB = hsb2rgb(currentstatus.GetHvalue(), newS,
                            currentstatus.GetBvalue());
                    AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                            convertRGB[3] << 8);
                    int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                    deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                } else {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色的明亮程度已经最大了哦",
                            APP_NAME);
                }
              
              }

        }
            break;
        case cmd_satudown: {
            
            // 当前颜色的饱和度调小,每次调整25%，不小于0 // 举例：将房间的光线调浅一点
            double currentS = currentstatus.GetSvalue();
            if (currentS <= 0.01) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "您好，当前的颜色已经达到最小值了",
                        APP_NAME);
            } else {
                double newS=0.0;
                if (HasModifier("max", "control_obj")) {
                    newS=0.01;
                } else {
                    newS = (currentS - currentS * 0.25) <= 0.01 ? 0.01
                            : (currentS - currentS * 0.25);                       
                }

                int[] convertRGB = hsb2rgb(currentstatus.GetHvalue(), newS,
                        currentstatus.GetBvalue());
                int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                        convertRGB[3] << 8);
  
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
             
        }
            break;
        case cmd_lightup: {
            
            double currentB = currentstatus.GetBvalue();

            if (currentB == 1) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经达到最亮了", APP_NAME);
            } else {
                double newB = 0;
                if (HasModifier("max", "control_obj"))
                    newB = 1;
                else if (currentB == 0)
                    newB = 0.5;
                else
                    newB = (currentB + currentB * 0.25) > 1 ? 1 : (currentB + currentB * 0.25);
              
                int[] convertRGB = hsb2rgb(currentstatus.GetHvalue(), currentstatus.GetSvalue(),
                        newB);
                int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                        convertRGB[3] << 8);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
             
        }
            break;
        case cmd_lightdown: {

            double currentB = currentstatus.GetBvalue();
            if (currentB <= 0.01) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经达到最暗了", APP_NAME);
            } else {
                double newB = 0;
                if (HasModifier("max", "control_obj"))
                    newB = 0.01;
                else
                    newB = (currentB - currentB * 0.25) < 0.01 ? 0.01
                            : (currentB - currentB * 0.25);
                
                
                int[] convertRGB = hsb2rgb(currentstatus.GetHvalue(), currentstatus.GetSvalue(),
                        newB);
                
                int rgbvalue=convertRGB[0] <<16+convertRGB[1]<<8+convertRGB[3];
                deviceobj.SetArributeValue(rgbvalue, cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, (convertRGB[0] << 8) + convertRGB[1],
                        convertRGB[3] << 8);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }

        }
            break;
        case cmd_setwarm: {
            // 已经是暖色系提示
            if (isSomeColorMode(colormode_warm, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.WARM, 0)) ;
                
                int rgvalue=(commandInfo.getAdjustcolor().GetRGBvalue()&0xFFFF00)>>8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;


                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
             
            }
        }
            break;
        case cmd_setbright: {
            if (isSomeColorMode(colormode_bright, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(brightList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.BRIGHT, 0));
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;

 
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        case cmd_setcute: {
            if (isSomeColorMode(colormode_cute, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(cuteList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CUTE, 0));
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        case cmd_setcool: {
            if (isSomeColorMode(colormode_cool, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(coolList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.COOL, 0));
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        case cmd_setsport: {
            if (isSomeColorMode(colormode_sport, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(sportList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.SPORT, 0));
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        case cmd_setgrace: {
            if (isSomeColorMode(colormode_grace, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(graceList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.GRACE, 0));

                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        case cmd_setcalm: {
            if (isSomeColorMode(colormode_calm, currentstatus) != 0xFF) {
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是您选的色系了哦",
                        APP_NAME);
            } else {
                // adjustcolor = colorData.get(calmList.get(0));
                commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CALM, 0));
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
            }
        }
            break;
        
        case cmd_warmer: { // 如果当前颜色不是暖色，则调整成级别最低的暖色 // 如果是暖色，则调整成高一级别的暖色
            // 若已经是最高的暖色，则提示用户
        
          int index = isSomeColorMode(colormode_warm, currentstatus); 
          if (index == 0xFF) {                             
              commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.WARM, 0));
              int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
              int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
              AdjustColourLightRGB(command, rgvalue, bvalue);            
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
           } else { 
                 if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "现在是最暖色调哦。",
                            APP_NAME);
                } else {
                    commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.WARM, index + 1));
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);            
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整",
                  APP_NAME); 
                  }
              
              } 
          } 
          break; 
          case cmd_brighter:  { 
                            
              int index= isSomeColorMode(colormode_bright, currentstatus); 
              if (index == 0xFF) { 
                  // colourHSB objectcolor =colorData.get(brightList.get(0));
                  commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.BRIGHT, 0)); 
                  
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);                        
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
              } else { 
                  if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
                } else {
           
                      commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.BRIGHT, index + 1)); 
                      int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                      int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                      deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                      
                      AdjustColourLightRGB(command, rgvalue, bvalue);                
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                      }
              } 
          } 
          break; 
          case cmd_cuter: { 

              int index =isSomeColorMode(colormode_cute, currentstatus);
              if (index ==0xFF) { 
                  commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CUTE, 0)); 
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
              } else { 
                  if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
                    } else { 
                      commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CUTE, index + 1));
                      int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                      int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                      deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                      
                      AdjustColourLightRGB(command, rgvalue, bvalue);                                                             
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                   }
              
              } 
          } 
          break;
          
          case cmd_cooler: { 
              int index =isSomeColorMode(colormode_cool, currentstatus); 
              if (index == 0xFF) {                     
                  commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CUTE, 0)); 
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
              } else { 
              if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
                  } else {
                      commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.COOL, index + 1));
                      int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                      int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                      deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                      
                      AdjustColourLightRGB(command, rgvalue, bvalue);     
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                  } 
              } 
           } break; 
          case cmd_sporter: { 
          int index = isSomeColorMode(colormode_sport, currentstatus);
          if (index == 0xFF) {                 
              commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.SPORT, 0)); 
              int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
              int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
              deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
              
              AdjustColourLightRGB(command, rgvalue, bvalue);     
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
              } else { if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
                  } else {
                    commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.SPORT, index + 1));
                      int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                      int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                      deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                      
                      AdjustColourLightRGB(command, rgvalue, bvalue);  
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                  }               
              } 
           } 
          break; 
          case cmd_gracer: { 
              int index =isSomeColorMode(colormode_grace, currentstatus);
              if (index ==0xFF) {                  
                  commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.GRACE, 0)); 
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);                      
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                 }else { 
                     if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
                  } else {
                      commandInfo.setAdjustcolor( GetColorTone(COLOR_TONE_TYPE.GRACE, index + 1));
                      int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                      int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                      deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                      
                      AdjustColourLightRGB(command, rgvalue, bvalue); 
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                  }
          
                 } 
          } 
          break; 
          case cmd_calmer: {  
              int index = isSomeColorMode(colormode_calm, currentstatus); 
              if (index ==0xFF) {  
                  commandInfo.setAdjustcolor(GetColorTone(COLOR_TONE_TYPE.CALM, 0)); 
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
          } else { 
              if (index >= 2) {
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "当前的颜色已经是最大值喽",
                            APP_NAME);
              } else {
                  commandInfo.setAdjustcolor( GetColorTone(COLOR_TONE_TYPE.CALM, index + 1)); 
                  int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                  int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                  deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                  
                  AdjustColourLightRGB(command, rgvalue, bvalue);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
                }
              } 
          } 
            break;
        case cmd_altertone: { // 按照UX提取一种色调
              colourStatus newtone = GetTone(deviceobj); 
          if (newtone != null) {
                commandInfo.setAdjustcolor(newtone);
                int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                
                AdjustColourLightRGB(command, rgvalue, bvalue);
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整", APP_NAME);
          } 
          } break;
        case cmd_setatmosphere:
            colourStatus newatmosphere = null;

            int colorindex = isSomeAtmosphere(commandInfo.getsecondCmd(), currentstatus);

            switch (commandInfo.getsecondCmd()) {

            // 浪漫气氛,即指明了氛围
            case cmd_romantic:
                // 柔和
            case cmd_soft:
                // 神秘
            case cmd_mystery:

                // 再浪漫一些
                // 再神秘一些
            if (HasModifier("littlemore", "control_obj")) {
                if (colorindex == 0xFF) {
                    commandInfo
                            .setAdjustcolor(GetColorAtmosphere(commandInfo.getsecondCmd(), 0));
                    int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                    int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                    deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                    
                    AdjustColourLightRGB(command, rgvalue, bvalue);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整",
                                APP_NAME);
                } else {
                    if (colorindex >= 2) {
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY,
                                    "当前的颜色已经是最大值喽",
                                APP_NAME);
                    } else {
                            commandInfo.setAdjustcolor(GetColorAtmosphere(
                                    commandInfo.getsecondCmd(), colorindex + 1));
                        int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue()
                                & 0xFFFF00) >> 8;
                        int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue()
                                & 0x0000FF) << 8;
                        
                        deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                        
                        AdjustColourLightRGB(command, rgvalue, bvalue);
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整",
                                APP_NAME);
                    }
                }

            } else {
                if (colorindex != 0xFF) {
                  
                    switch (commandInfo.getsecondCmd()) {
                        // 浪漫气氛
                    case cmd_romantic:
                            answer = "现在已经是浪漫气氛了哦";
                        break;
                        // 柔和
                    case cmd_soft:
                            answer = "现在已经是柔和温馨的气氛了哦";
                        break;
                        // 神秘
                    case cmd_mystery:
                            answer = "现在已经是神秘气氛了哦";
                        break;
                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                        commandInfo.setAdjustcolor(
                                GetColorAtmosphere(commandInfo.getsecondCmd(), 0));

                    int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                    int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                    deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                    
                    AdjustColourLightRGB(command, rgvalue, bvalue);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整",
                                APP_NAME);

                }

            }
                break;
            case cmd_change: // 当没有指明氛围时，如果没有在定义的氛围内，则获取定义的氛围，如果在则循环到下一氛围
            default:
                newatmosphere = GetAtmosphere(deviceobj);
                if (newatmosphere != null) {
                    commandInfo.setAdjustcolor(newatmosphere);
                    int rgvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0xFFFF00) >> 8;
                    int bvalue = (commandInfo.getAdjustcolor().GetRGBvalue() & 0x0000FF) << 8;
                    AdjustColourLightRGB(command, rgvalue, bvalue);
                    deviceobj.SetArributeValue(commandInfo.getAdjustcolor().GetRGBvalue(), cluster_General_Time, Attribute_id3);
                    
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "正在为您调整氛围", APP_NAME);
                }
                break;
            }
            break;
         
        }
        break;
    }

    case HomeAutoProtocol.Devtype_Camera: { // 摄像头
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
            JSONObject command1 = new JSONObject();
            command1.put("App Name", "camera_control");
            command1.put("action", 1);
            if (commandInfo.getDeviceID().equals("3300AA00AA00AA00F100"))
                command1.put("id", 1);
            else if (commandInfo.getDeviceID().equals("3300AA00AA00AA00F200"))
                command1.put("id", 2);
            
            output.AddAppCommand("App Name", command1);
            answer = "正在为您打开" + devName;
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
            JSONObject command1 = new JSONObject();
            command1.put("App Name", "camera_control");
            command1.put("action", 0);
            if (commandInfo.getDeviceID().equals("3300AA00AA00AA00F100"))
                command1.put("id", 1);
            else if (commandInfo.getDeviceID().equals("3300AA00AA00AA00F200"))
                command1.put("id", 2);
            output.AddAppCommand("App Name", command1);
            answer = "正在为您关闭" + devName;
        }
        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        break;
    }
    case HomeAutoProtocol.Devtype_Light: { // 灯
        // HomeAutodeviceObjectNew lightstatus =
        // GetSensorStatusByType(Devtype_LightIntenSensor);
        int lightstatus = deviceobj.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {

            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
            // if ((deviceobj.getAttributeList() != null
            // && !deviceobj.getAttributeList().isEmpty() &&
            // deviceobj.GetArributeValue(
            // cluster_Onoff_Switch, Attribute_id0) == 0)
            // || deviceobj.controlstatus.GetStatus() == 0) { //
            // switch的状态来自stt中开关的状态数据
            if (lightstatus == 1) {
                answer = devName + "是打开的哦.";
            } else {
                deviceobj.controlstatus.SetStatus(1);
                command.put("action_id", 0x01);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_open);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                AddHomeAutoCmd(command);
                if (commandInfo.getCmdTypeFlag() != cmdTypeFlag.cmdtype_all) {
                    answer = "已经帮您打开" + devName + ".";
                } else {
                    answer = devName + "已打开.";
                }
                deviceobj.SetArributeValue(1, cluster_Onoff_Switch, Attribute_id0);  
                deviceobj.controlstatus.SetStatus(0x01);
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
            // deviceobj.controlstatus.cmd_Primary =
            // cmd_typePrimary.cmd_close;
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
            // if ((deviceobj.getAttributeList() != null
            // && !deviceobj.getAttributeList().isEmpty() &&
            // deviceobj.GetArributeValue(
            // cluster_Onoff_Switch, Attribute_id0) == 1)
            // || deviceobj.controlstatus.GetStatus() == 1) {
            if (lightstatus == 0) {
                answer = devName + "是关闭的哦.";

            } else {
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_close);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                AddHomeAutoCmd(command);
                if (commandInfo.getCmdTypeFlag() != cmdTypeFlag.cmdtype_all) {
                    answer = "已经帮您关闭" + devName + ".";
                } else {
                    answer = devName + "已关闭.";
                }
                deviceobj.controlstatus.SetStatus(0);
                deviceobj.SetArributeValue(0, cluster_Onoff_Switch, Attribute_id0);
            }

            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
            // 播报现在灯的状态
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);
            // int value = status.controlstatus.status;

            answer = commandInfo.getPositionName() + "的灯";
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);
            if (lightstatus == switch_open) {
                answer += devName + "已打开.";

            } else if (lightstatus == switch_close) {
                answer += devName + "已关闭.";
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_identify
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) { // 识别设备
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_identify);
            command.put("action_id", 0x00);
            command.put("cluster_id", cluster_Identify);
            command.put("action_frame", frame_special);

            JSONObject attr1 = new JSONObject();
            attr1.put("data_type_id", 0x21);
            attr1.put("data_value", 6);
            command.put("param1", attr1);
            AddHomeAutoCmd(command);
            if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer = "正在识别" + deviceobj.description + ".";
            else
                answer = "正在识别灯.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setlightintensity) {
            // 因为暂时没有光线调节，因此仅打开灯操作
            // 获取其他灯
            HomeAutodeviceObjectNew[] lightlist = homeAutoInfo.GetDeviceObjByDevType(HomeAutoProtocol.Devtype_Light);
            
            // 检测光线
           HomeAutodeviceObjectNew[] lightdevicelist = homeAutoInfo.GetDeviceObjByDevType(HomeAutoProtocol.Devtype_LightIntenSensor);
           if(lightdevicelist.length==0){
                // 没有光线传感器
                switch (commandInfo.getsecondCmd()) {
                case cmd_setup:
                    if (lightstatus == 0) {
                        command.put("action_id", 0x01);
                        command.put("cluster_id", cluster_Onoff_Switch);
                        command.put("action_frame", frame_special);
                        AddHomeAutoCmd(command);
                        answer = "马上为您打开" + devName;
                    } else if (lightlist.length > 1) {

                        HomeAutodeviceObjectNew anotherdevice = null;
                        for (int i = 0; i < lightlist.length; i++) {
                            if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                anotherdevice = lightlist[i];
                                break;
                            }
                        }
                        if (anotherdevice != null && anotherdevice
                                .GetArributeValue(cluster_Onoff_Switch, Attribute_id0) == 0) {
                            command.put("dev_id", anotherdevice.device_ID);
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_Onoff_Switch);
                            command.put("action_frame", frame_special);
                            AddHomeAutoCmd(command);
                            answer = "马上为您打开" + devName;
                        } else {
                            answer = "屋里确实有点暗，可是灯都打开了哦。";
                        }

                    } else {
                        answer = "屋里确实有点暗，可是灯都打开了哦。";
                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                    break;
                case cmd_setdown:
                    if (lightstatus == 1) {
                    command.put("action_id", 0x01);
                    command.put("cluster_id", cluster_Onoff_Switch);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                        answer = "马上为您关闭" + devName;
                    } else if (lightlist.length > 1) {

                        HomeAutodeviceObjectNew anotherdevice = null;
                        for (int i = 0; i < lightlist.length; i++) {
                            if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                anotherdevice = lightlist[i];
                                break;
                            }
                        }
                        if (anotherdevice != null && anotherdevice
                                .GetArributeValue(cluster_Onoff_Switch, Attribute_id0) == 1) {
                            command.put("dev_id", anotherdevice.device_ID);
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_Onoff_Switch);
                            command.put("action_frame", frame_special);
                            AddHomeAutoCmd(command);
                            answer = "马上为您关掉" + devName;
                        } else {
                            answer = "屋里确实有点暗，可是灯都打开了哦。";
                        }

                } else {
                        answer = "屋里确实有点暗，可是灯都打开了哦。";
                }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    break;
                }
            } else {
                int level = GetSensorLevel(HomeAutoProtocol.Devtype_LightIntenSensor,
                        cluster_LightInten,
                        Attribute_id0);
                
                switch (commandInfo.getsecondCmd()) {
                                
                case cmd_setup:
                    
                    if (level >= 1) {// 如果光线不是超亮
                        // 1.如果主灯是关闭的，打开主灯
                        // 2.如果主灯是打开的，壁灯是关闭的，打开壁灯
                        // 3.如果两个灯都是打开的，则聊天
                        
                        if (lightstatus == 0) {
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_Onoff_Switch);
                            command.put("action_frame", frame_special);
                            AddHomeAutoCmd(command);
                            answer = "马上为您打开" + devName;
                        } else if (lightlist.length > 1) {

                            HomeAutodeviceObjectNew anotherdevice = null;
                            for (int i = 0; i < lightlist.length; i++) {
                                if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                    anotherdevice = lightlist[i];
                                    break;
                                }
                            }
                            if (anotherdevice != null
                                    && anotherdevice.GetArributeValue(cluster_Onoff_Switch,
                                            Attribute_id0) == 0) {
                                command.put("dev_id", anotherdevice.device_ID);
                                command.put("action_id", 0x01);
                                command.put("cluster_id", cluster_Onoff_Switch);
                                command.put("action_frame", frame_special);
                                AddHomeAutoCmd(command);
                                answer = "马上为您打开" + anotherdevice.description;
                            } else {
                                answer = "屋里确实有点暗，可是灯都打开了哦。";
                            }

                        } else {
                            answer = "屋里确实有点暗，可是灯都打开了哦。";
                        }
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    } else if (level == 0) {
                        // 光线很强
                        // 1.主灯是关闭的，询问是否需要开主灯
                        // 2.壁灯是关闭的，询问是否打开壁灯
                        // 3.否则聊天
                        if (lightstatus == 0) {
                            answer = "需要帮您打开" + deviceobj.description + "吗？";
                            NormalcontrolDevIDList.add(deviceobj.device_ID);
                            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
                            deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_default);
//                            output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
//                            appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                        } else if (lightlist.length > 1) {
                            HomeAutodeviceObjectNew anotherdevice = null;
                            for (int i = 0; i < lightlist.length; i++) {
                                if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                    anotherdevice = lightlist[i];
                                    break;
                                }
                            }
                            if (anotherdevice != null
                                    && anotherdevice.GetArributeValue(cluster_Onoff_Switch,
                                            Attribute_id0) == 0) {
                                answer = "需要帮您打开" + anotherdevice.description + "吗？";
                                anotherdevice.controlstatus
                                        .SetCmdPrimary(cmd_typePrimary.cmd_open);
                                anotherdevice.controlstatus
                                        .SetCmdSecond(cmd_typeSecond.cmd_default);
                                NormalcontrolDevIDList.add(anotherdevice.device_ID);
//                                output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
//                                        APP_NAME);
//                                appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                            } else {
                                answer = "屋里的光线很强哦，是不是您心情不太好。";
                                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                        APP_NAME);
                            }

                        } else {
                            answer = "屋里的光线很强哦，是不是您心情不太好。";
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                    APP_NAME);
                        }

                    }
                    

                    break;
                case cmd_setdown:
                    // 如果光线不是最暗

                    if (level < 3) {
                        // 如果主灯开着，则关闭主灯
                        // 如果壁灯开着，则关闭壁灯
                        // 否则，聊天
                        if (lightstatus == 1) {
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_Onoff_Switch);
                            command.put("action_frame", frame_special);
                            AddHomeAutoCmd(command);
                            answer = "马上为您关闭" + deviceobj.description;
                        } else if (lightlist.length > 1) {

                            HomeAutodeviceObjectNew anotherdevice = null;
                            for (int i = 0; i < lightlist.length; i++) {
                                if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                    anotherdevice = lightlist[i];
                                    break;
                                }
                            }
                            if (anotherdevice != null
                                    && anotherdevice.GetArributeValue(cluster_Onoff_Switch,
                                            Attribute_id0) == 1) {
                                command.put("dev_id", anotherdevice.device_ID);
                                command.put("action_id", 0x01);
                                command.put("cluster_id", cluster_Onoff_Switch);
                                command.put("action_frame", frame_special);
                                AddHomeAutoCmd(command);
                                answer = "马上为您关掉" + anotherdevice.description;
                            } else {
                                answer = "屋里确实有点暗，可是灯都打开了哦。";
                            }

                        } else {
                            answer = "屋里确实有点暗，可是灯都打开了哦。";
                        }
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                    } else {// 光线最暗
                        // 如果主灯开着，询问是否要关灯
                        // 如果壁灯光着，询问是否关壁灯
                        // 否则，告诉用户实际光线很暗
                        if (lightstatus == 1) {
                            answer = "需要帮您关闭" + deviceobj.description + "吗？";
                            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
                            deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_default);
                            NormalcontrolDevIDList.add(deviceobj.device_ID);
//                            output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
//                                    APP_NAME);
//                            appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                        } else if (lightlist.length > 1) {
                            HomeAutodeviceObjectNew anotherdevice = null;
                            for (int i = 0; i < lightlist.length; i++) {
                                if (!deviceobj.device_ID.equals(lightlist[i].device_ID)) {
                                    anotherdevice = lightlist[i];
                                    break;
                                }
                            }
                            if (anotherdevice != null
                                    && anotherdevice.GetArributeValue(cluster_Onoff_Switch,
                                            Attribute_id0) == 1) {
                                answer = "需要帮您关闭" + anotherdevice.description + "吗？";
                                anotherdevice.controlstatus
                                        .SetCmdPrimary(cmd_typePrimary.cmd_close);
                                anotherdevice.controlstatus
                                        .SetCmdSecond(cmd_typeSecond.cmd_default);
                                NormalcontrolDevIDList.add(anotherdevice.device_ID);
//                                output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
//                                        APP_NAME);
//                                appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                            } else {
                                answer = "屋里的光线很暗哦主人。";
                                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                        APP_NAME);
                            }
                        }

                    }

                }



            } 
        } else {
            if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer += deviceobj.description + "不支持该功能.";
            else
                answer += "灯目前还不支持该功能.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        }
        
        
        break;
    }
    case HomeAutoProtocol.Devtype_Humidifier: {
        // 加湿器开关和档位状态
        int hStatus = deviceobj.GetArributeValue(cluster_hvacFanControl, Attribute_id0);
        // 负离子开关状态
        int extrastatus = deviceobj.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
        // if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open
        // && (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_extralfun1
        // || commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default)) {
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open
                && (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default)) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);

            if (hStatus == 0) {// 加湿器是关闭的
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_light_color_control);
                command.put("action_frame", frame_special);
                AddHomeAutoCmd(command);
                answer = devName + "已打开.";
                deviceobj.controlstatus.SetStatus(1);
                }
            else {
                // if (commandInfo.getsecondCmd() ==
                // cmd_typeSecond.cmd_extralfun1) {
                // if (extrastatus == 0x00) {
                // command.put("action_id", 0x01);
                // command.put("cluster_id", cluster_Onoff_Switch);
                // command.put("action_frame", frame_special);
                // AddHomeAutoCmd(command);
                // answer = "负离子功能已打开.";
                // } else
                // answer = "负离子功能是打开的.";
                // } else
                answer = devName + "是打开的哦.";
            }
                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);                    
        }
        // else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
        // && (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_extralfun1
        // || commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default)) {
        else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)
                && (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default)) {
            // humifitystatus.controlstatus.command=0xCC;
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
            if (hStatus == 0) {
                answer = devName + "是关闭的.";
            } else {
                // if (commandInfo.getsecondCmd() ==
                // cmd_typeSecond.cmd_extralfun1) {
                // if (extrastatus == 0x01) {
                // command.put("action_id", 0x00);
                // command.put("cluster_id", cluster_Onoff_Switch);
                // command.put("action_frame", frame_special);
                // AddHomeAutoCmd(command);
                // answer = "负离子功能已关闭.";
                // } else if (extrastatus == 0)
                // answer = "负离子功能是关闭的.";
                // } else
                {
                    deviceobj.controlstatus.SetStatus(0);
                    command.put("action_id", 0x01);
                    command.put("cluster_id", cluster_light_color_control);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = devName + "已关闭.";
                }
            }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_extralfun1) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_extralfun1);
            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_cancel) {
                if (hStatus == 0)
                    answer = devName + "是关闭的.";
                else {

                    if (extrastatus == 0x01) {
                        command.put("action_id", 0x00);
                        command.put("cluster_id", cluster_Onoff_Switch);
                        command.put("action_frame", frame_special);
                        AddHomeAutoCmd(command);
                        answer = "负离子功能已关闭.";
                    } else if (extrastatus == 0)
                        answer = "负离子功能是关闭的.";
                }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_enable) {
                if (hStatus == 0) {
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_light_color_control);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = devName + "已打开.";
                } else {
                    if (extrastatus == 0x00) {
                        command.put("action_id", 0x01);
                        command.put("cluster_id", cluster_Onoff_Switch);
                        command.put("action_frame", frame_special);
                        AddHomeAutoCmd(command);
                        answer = "负离子功能已打开.";
                    } else
                        answer = "负离子功能是打开的.";
                }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }

        }
        else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setlevel) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_setlevel);
            switch (commandInfo.getsecondCmd()) {
            case cmd_change:
                command.put("action_id", 0x02);
                command.put("cluster_id", cluster_light_color_control);
                command.put("action_frame", frame_special);
                AddHomeAutoCmd(command);
                answer = "马上为您切换档位.";
                break;
            default:
                answer = devName + "仅支持档位切换.";

                break;
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_sethumidity) {
            // 间接命令，比如：空气太干了，空气太湿了
            int level = GetSensorLevel(HomeAutoProtocol.Devtype_HumiditySensor,
                    cluster_HumiditySensor, Attribute_id0);
            switch (commandInfo.getsecondCmd()) {
            case cmd_setup:
                if (level >= 0 && level <= 3) { // 湿度正常或者干燥
                    if (hStatus == 0) {// 加湿器是关闭的
                        command.put("action_id", 0x00);
                        command.put("cluster_id", cluster_light_color_control);
                        command.put("action_frame", frame_special);
                        AddHomeAutoCmd(command);
                        answer = "已经帮您打开" + devName;
                        deviceobj.controlstatus.SetStatus(1);
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    } else {

                        deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_setlevel);
                        deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_change);
                        deviceobj.controlstatus.SetStatus(1);
                        // controlDevIDList.add(deviceobj.device_type);
                        NormalcontrolDevIDList.add(deviceobj.device_ID);
                        answer = "加湿器是打开的，需要帮您调节档位吗？";
//                        output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
//                        appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                    }
                } else {
                    if (hStatus == 0) {// 加湿器是关闭的
                        deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
                        deviceobj.controlstatus.SetStatus(1);
                        // controlDevIDList.add(deviceobj.device_type);
                        NormalcontrolDevIDList.add(deviceobj.device_ID);
                        answer = "屋里的湿度较高，您确定要打开加湿器吗？";
//                        output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
//                        appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                    } else {
                        deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_setlevel);
                        deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_change);
                        deviceobj.controlstatus.SetStatus(1);
                        // controlDevIDList.add(deviceobj.device_type);
                        NormalcontrolDevIDList.add(deviceobj.device_ID);
                        answer = "目前的空气比较湿润，需要帮您调节档位吗？";
//                        output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
//                        appStatus = AppStatusCode.WAITING_FOR_RESULT_CONFIRM;
                    }
                }

                    break;
            case cmd_setdown:
                if (level >= 4) { // 湿度高
                    if (hStatus != 0) { // 如果加湿器是打开的
                        deviceobj.controlstatus.SetStatus(0);
                        command.put("action_id", 0x01);
                        command.put("cluster_id", cluster_light_color_control);
                        command.put("action_frame", frame_special);
                        AddHomeAutoCmd(command);
                        answer = devName + "已帮您关闭加湿器.";
                    } else {
                        answer = "加湿器是关闭的.";

                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    if (hStatus != 0) {
                        deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
                        deviceobj.controlstatus.SetStatus(1);

                        NormalcontrolDevIDList.add(deviceobj.device_ID);
                        answer = "目前的空气比较干燥。您确定要关闭加湿器吗？";
                    } else {
                        answer = "目前的空气比较干燥，加湿器也是关闭的哦。";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    }
                }
                break;
            }

        } else {
            if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer += deviceobj.description + "不支持该功能.";
            else
                answer += "加湿器目前还不支持该功能.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }
            break;
    }
    case HomeAutoProtocol.Devtype_Television: {
        int tStatus = deviceobj.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
            if (tStatus == 1) {
                answer = devName + "是打开的哦.";
            } else {
                command.put("action_id", 0x01);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_open);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                
                deviceobj.SetArributeValue(1, cluster_Onoff_Switch, Attribute_id0);
                
                AddHomeAutoCmd(command);
                answer = devName + "已打开.";
                
                
                
                deviceobj.controlstatus.SetStatus(1);
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)) {

            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
            if (tStatus == 0) {
                answer = devName + "是关闭的哦.";
            } else {
                deviceobj.controlstatus.SetStatus(0);

                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_close);
                command.put("cluster_name", cluster_Onoff_Switch_name);
                AddHomeAutoCmd(command);
                
                deviceobj.SetArributeValue(1, cluster_Onoff_Switch, Attribute_id0);
                answer = devName + "已关闭.";
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        }  else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_changechannel) {// 换台

            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setnext) {// 下一个
            	command.put("action_id", 0x01);
                command.put("cluster_id", cluster_RemoteControl);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_next);
                command.put("cluster_name", cluster_RemoteControl_name);
                AddHomeAutoCmd(command);
                
                answer = "正在切换下个频道.";
               
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setlast) {// 上一个
            	command.put("action_id", 0x02);
                command.put("cluster_id", cluster_RemoteControl);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_last);
                command.put("cluster_name", cluster_RemoteControl_name);
                AddHomeAutoCmd(command);
                    answer = "正在切换上个频道";
                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else {

                int setvalue = 0;
                AppSlotEntry degreeslot = GetSlotByName("sensorvalue"); // 台号

                if (degreeslot != null) {
                    
                        setvalue = getSensorSlotValue();
                       
                        
                        answer = "正在帮您切换" + setvalue + "频道.";
                        
                        command.put("action_id", 0x00);
                        command.put("cluster_id", cluster_RemoteControl);
                        command.put("action_frame", frame_special);
                        
                        command.put("action_name", action_setchannel);
                        command.put("cluster_name",  cluster_RemoteControl_name);

                        // parameter
                        JSONObject channel = new JSONObject();
                        channel.put("data_type_id", 0x20);
                        channel.put("data_value", setvalue);
                        channel.put("data_type_name", data_type_uint8);
                        command.put("param1", channel);
                        AddHomeAutoCmd(command);
                        deviceobj.SetArributeValue(setvalue, cluster_RemoteControl, Attribute_id0);


                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                }

            }

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_confirm) { // 确认
        	command.put("action_id", 0x03);
            command.put("cluster_id", cluster_RemoteControl);
            command.put("action_frame", frame_special);
            
            command.put("action_name", action_confirm);
            command.put("cluster_name", cluster_RemoteControl_name);
            AddHomeAutoCmd(command);
                answer = "好的.";
            
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_getback) { // 返回
        	command.put("action_id", 0x04);
            command.put("cluster_id", cluster_RemoteControl);
            command.put("action_frame", frame_special);
            
            command.put("action_name", action_back);
            command.put("cluster_name", cluster_RemoteControl_name);
            AddHomeAutoCmd(command);
                answer = "好的.";           
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setvolume) { // 调整音量

            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
            	command.put("action_id", 0x05);
                command.put("cluster_id", cluster_RemoteControl);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_setupvolumn);
                command.put("cluster_name", cluster_RemoteControl_name);
                AddHomeAutoCmd(command);
                answer = "正在帮您提高电视音量.";
                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
            	command.put("action_id", 0x06);
                command.put("cluster_id", cluster_RemoteControl);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_setdownvolumn);
                command.put("cluster_name", cluster_RemoteControl_name);
                AddHomeAutoCmd(command);
                    answer = "正在帮您降低电视音量.";
                
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setmod) { // 调整音量

            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_mutemod) {
            	command.put("action_id", 0x06);
                command.put("cluster_id", cluster_RemoteControl);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_setmute);
                command.put("cluster_name", cluster_RemoteControl_name);
                AddHomeAutoCmd(command);
                answer = "正在帮您把电视静音.";
               
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }
        }
       else {
            if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer += deviceobj.description + "不支持该功能.";
            else
                answer += devName + "目前还不支持该功能.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        }

    }
        break;
    case HomeAutoProtocol.Devtype_Dehumidifier: {
        // 除湿器,使用开关1
        int dhStatus = deviceobj.GetArributeValue(cluster_Onoff_Switch, Attribute_id0);
            
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open) {
            // if(humifitystatus!=null)
            // humifitystatus.controlstatus.command=0xCC;
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
            if (dhStatus == 1)
                answer = devName + "已经打开了.";
            else {
                deviceobj.controlstatus.SetStatus(1);

                command.put("action_id", 0x01);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                answer = devName + "已打开.";
            }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);                    
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)) {
            // if(humifitystatus!=null)
            // humifitystatus.controlstatus.command=0xCC;
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);
                //if(status.controlstatus.status==1){

            if (dhStatus == 0)
                answer = devName + "已经关闭了.";
            else {
                deviceobj.controlstatus.SetStatus(0);

                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_Onoff_Switch);
                command.put("action_frame", frame_special);
                AddHomeAutoCmd(command);
                answer = devName + "已关闭.";
            }

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else {
            answer += devName + "目前还不支持该功能.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }
            break;
    }
    case HomeAutoProtocol.Devtype_Aircleaner: {// 空气净化器

        int controlStatus = deviceobj.GetArributeValue(cluster_hvacFanControl, Attribute_id0);
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);

            if (controlStatus == 1) {
                answer = devName + "已经打开了.";
            } else {
                deviceobj.controlstatus.SetStatus(1);
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_LightColorControl);
                command.put("action_frame", frame_special);

                AddHomeAutoCmd(command);
                answer = devName + "已经帮您打开.";
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)) {
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);

            // if (controlStatus != 0 || deviceobj.controlstatus.GetStatus()
            // != 0) { // 空气净化器是打开的
            if (controlStatus != 0) { // 空气净化器是打开的
                deviceobj.controlstatus.SetStatus(0);
                command.put("action_id", 0x01);
                command.put("cluster_id", cluster_LightColorControl);
                command.put("action_frame", frame_special);
                AddHomeAutoCmd(command);
                answer = devName + "已关闭.";
            } else {
                answer = devName + "已经关闭了.";
            }

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setwindpower
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_default) {// 设置风速,
                                                                                // 净化器的风速调节等同于档位调节
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_setwindpower);
            // 调高档位
            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
                if (controlStatus == 0) {
                    // 打开净化器
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);

                    AddHomeAutoCmd(command);
                    answer = devName + "已经帮您打开.并低档运行";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (controlStatus == 1) {

                    command.put("action_id", 0x03);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);

                    AddHomeAutoCmd(command);
                    answer = devName + "已经设置为中档.";
                    deviceobj.controlstatus.SetStatus(2);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                } else if (controlStatus == 2) {
                    command.put("action_id", 0x04);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);

                    AddHomeAutoCmd(command);
                    answer = devName + "已经设置为高档.";
                    deviceobj.controlstatus.SetStatus(3);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (controlStatus == 3 || controlStatus == Integer.MAX_VALUE) {
                    answer = devName + "的风力已经调到最高档了";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }

            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
                // 调低档位
                if (controlStatus == 0 || controlStatus == Integer.MAX_VALUE) {
                    // 打开净化器
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = devName + "已经打开.并低档运行";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (controlStatus == 1) {
                    answer = devName + "的风力已经调到最低档了.";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                } else if (controlStatus == 2) {
                    command.put("action_id", 0x02);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = deviceobj.description + "已经设置为低档.";
                    deviceobj.controlstatus.SetStatus(1);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (controlStatus == 3) {

                    command.put("action_id", 0x03);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = "净化器已经设置为中档.";
                    deviceobj.controlstatus.SetStatus(2);

                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }

            } else {
                switch (commandInfo.getsecondCmd()) {
                case cmd_weaklevel:
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_weaklevel);
                    // if (controlStatus == 1 ||
                    // deviceobj.controlstatus.GetStatus() == 1) {
                    if (controlStatus == 1) {
                        answer = devName + "是低档哦";

                    } else {


                        command.put("action_id", 0x02);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = devName + "已经设置为低档.";
                        deviceobj.controlstatus.SetStatus(1);

                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    break;
                case cmd_mediumlevel:
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_mediumlevel);

                    if (controlStatus == 2) {
                        answer = devName + "是中档哦";
                    } else {

                        command.put("action_id", 0x03);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = devName + "已经设置为中档.";

                        deviceobj.controlstatus.SetStatus(2);

                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    break;
                case cmd_stronglevel:
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_stronglevel);

                    if (controlStatus == 3) {
                        answer = devName + "是高档哦";
                    } else {

                        command.put("action_id", 0x04);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = devName + "已经设置为高档.";

                        deviceobj.controlstatus.SetStatus(3);

                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    break;
                case cmd_change:
                case cmd_default:
                    // 如果没有二级命令
                    answer = "请问帮您把风力调成低档，中档，还是高档？";
//                    super.Status().RecordSlotForQuestion("control_obj", "");
//                    appStatus = AppStatusCode.WAITING_FOR_SLOT_REPLY;
//                    output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    break;
                default:
                    break;

                }


            }

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_settiming) {// 设置定时时间
            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_settiming);

            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
                // 净化器关闭，打开净化器，并定时两小时
                if (controlStatus == 0) {

                    command.put("action_id", 0x05);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);

                    AddHomeAutoCmd(command);
                    answer = "2小时后帮您关闭" + devName;
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }else{
                    int timestatus = deviceobj.GetArributeValue(cluster_hvacFanControl,
                            Attribute_id1);
                    // 如果定时功能关闭,定时2小时
                    if(timestatus==0){                                                 
                        command.put("action_id", 0x05);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "已经帮您把" + devName + "定时2小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    }else if(timestatus==1){
                        command.put("action_id", 0x06);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "已经帮您把" + devName + "定时4小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    }else if(timestatus==2){
                        command.put("action_id", 0x07);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "已经帮您把" + devName + "定时8小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    }else if(timestatus==3){
                        // 再次发送定时8小时的命令
                        command.put("action_id", 0x07);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "8小时后帮您关闭" + devName;
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);                           
                    }
                    
                }
                

            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
                // 净化器关闭，打开净化器，并定时两小时
                if (controlStatus == 0) {

                    command.put("action_id", 0x05);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);
                    AddHomeAutoCmd(command);
                    answer = "已经帮您把" + devName + "定时为最短时间2小时";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }else{
                    int timestatus = deviceobj.GetArributeValue(cluster_hvacFanControl,
                            Attribute_id1);
                    // 如果定时功能关闭,定时2小时
                    if (timestatus == 0) {
//                        appStatus = AppStatusCode.WAITING_FOR_SLOT_REPLY;
//                        super.Status().RecordSlotForQuestion("slot_timing", "");
//                        answer = "现在支持设定的时间有2小时、4小时、8小时。请选择您要定时的时间？";
//                        output.AddQuestion(OutputMap.PRESENT_TTS, answer, APP_NAME);
                    } else if (timestatus == 1) {
                        answer = devName + "的定时时间已经是最小值2小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    } else if (timestatus == 2) {
                        command.put("action_id", 0x05);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "已经帮您把" + devName + "定时2小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    } else if (timestatus == 3) {
                        command.put("action_id", 0x06);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special);

                        AddHomeAutoCmd(command);
                        answer = "已经帮您把" + devName + "定时4小时";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                    }
                    
                }

            } else {

                if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_cancel) {// 关闭定时器的
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_cancel);
                    answer = "已经帮您关闭" + devName + "的定时功能";
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special);
                    command.put("action_id", 0x08);

                    AddHomeAutoCmd(command);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    AppSlotEntry timerslot = GetSlotByName("slot_timing");
                    // 1.如果没有提供定时时间，询问用户
                    if (timerslot == null) {
                    } else {
                     }

                }

            }

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setairquality) {
            // 处理聊天功能
            HomeAutodeviceObjectNew[] devicelist =homeAutoInfo .GetDeviceObjByDevType(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25, Attribute_id0);
            switch (commandInfo.getsecondCmd()) {
            // 1.空气真难闻
            case cmd_setup:
                // 1.没有传感器设备
                if(devicelist==null||devicelist.length==0){ 
                    
                    if(controlStatus==0){
                        answer = "抱歉.查不到屋内的空气指数，您可以考虑打开净化器哦.";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);  
                    }else{
                        if (controlStatus == 1 || controlStatus == 2)
                            answer = "抱歉,查不到屋内的空气指数.您可以将净化器调高一档。";
                        else if (controlStatus == 2)
                            answer = "抱歉,查不到屋内的空气指数.净化器已经工作在最高档了。";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);                        
                    }
                    
                } else {
                    int level = GetSensorLevel(HomeAutoProtocol.Devtype_AQISensor,
                            cluster_PM25, Attribute_id0);
                    // 空气质量比较好
                    if (level == 1 || level == 2) {
                        String levelstr = getAirLevelString(level);
                        answer = "现在的空气质量为"
                                + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                        cluster_PM25, Attribute_id0) + "ug/m3," + levelstr
                                + ".";
                        String voice = "现在的空气质量为"
                                + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                        cluster_PM25, Attribute_id0)
                                + "微克每立方米," + levelstr
                                + ".";
                        output.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
                        output.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);

                    } else if (level > 2) {
                        if (controlStatus == 0) {
                            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);

                            deviceobj.controlstatus.SetStatus(1);
                            command.put("action_id", 0x00);
                            command.put("cluster_id", cluster_LightColorControl);
                            command.put("action_frame", frame_special);

                            AddHomeAutoCmd(command);
                            answer = "目前的空气质量为" + getAirLevelString(level) + "," + devName
                                    + "已经帮您打开.";
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                    APP_NAME);

                        } else if (controlStatus == 1) {

                            command.put("action_id", 0x03);
                            command.put("cluster_id", cluster_LightColorControl);
                            command.put("action_frame", frame_special);

                            AddHomeAutoCmd(command);

                            answer = "目前的空气质量为" + getAirLevelString(level) + "," + devName
                                    + "已经设置为中档.";
                            deviceobj.controlstatus.SetStatus(2);
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                    APP_NAME);

                        } else if (controlStatus == 2) {
                            command.put("action_id", 0x04);
                            command.put("cluster_id", cluster_LightColorControl);
                            command.put("action_frame", frame_special);

                            AddHomeAutoCmd(command);
                            answer = "目前的空气质量为" + getAirLevelString(level) + "," + devName
                                    + "已经设置为高档.";
                            deviceobj.controlstatus.SetStatus(3);
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                    APP_NAME);
                        } else if (controlStatus == 3) {
                            answer = "目前的空气质量为" + getAirLevelString(level) + "," + devName
                                    + "净化器已经工作在最高档";
                            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
                                    APP_NAME);
                        }
                    }
                }


                break;
            case cmd_setdown:
                // 1.空气不错哦

                // 没有传感器设备
                if (devicelist == null || devicelist.length == 0) {
                    if(controlStatus!=0){
                        answer = "抱歉.目前无法获取屋内的空气指数，您可以考虑关闭净化器哦.";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);  
                    } else{
                        answer = "抱歉.目前无法获取屋内的空气指数.";
                        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);  

                    }
                } else {
                    // 有传感器设备
                    int level = GetSensorLevel(HomeAutoProtocol.Devtype_AQISensor,
                            cluster_PM25, Attribute_id0);
                    // 空气质量确实比较好
                    if (level == 1 || level == 2) {
                        // 如果净化器是打开的
                        if (controlStatus != 0) {
                            deviceobj.controlstatus.SetStatus(0);
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_LightColorControl);
                            command.put("action_frame", frame_special);
                            AddHomeAutoCmd(command);
                            answer = "目前的空气质量为" + getAirLevelString(level) + ",已经帮您关闭"
                                    + devName;
//                            output.AddQuestion(OutputMap.PRESENT_TTS_AND_DISPLAY, answer,
//                                    APP_NAME);

                        } else {
                            String levelstr = getAirLevelString(level);
                            answer = "现在的空气质量为"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                            cluster_PM25, Attribute_id0) + "ug/m3," + levelstr
                                    + ".";
                            String voice = "现在的空气质量为"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                            cluster_PM25, Attribute_id0)
                                    + "微克每立方米," + levelstr
                                    + ".";
                            output.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
                            output.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);

                        }
                    } else if (level > 2) {
                        String levelString = getAirLevelString(level);
                        if (controlStatus == 0) {

                            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);
                            deviceobj.controlstatus.SetStatus(0);
                            // controlDevIDList.add(deviceobj.device_type);
                            NormalcontrolDevIDList.add(deviceobj.device_ID);
                            answer = "看来您心情不错吆，不过空气质量是" + levelString + ",需要帮您打开空气净化器吗？";
                        }else{
                            // 设备是打开的
                            String levelstr = getAirLevelString(level);
                            answer = "现在的空气质量为"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                            cluster_PM25, Attribute_id0) + "ug/m3," + levelstr
                                    + ",建议您不要关闭净化器.";
                            String voice = "现在的空气质量为"
                                    + GetSensorValue(HomeAutoProtocol.Devtype_AQISensor,
                                            cluster_PM25, Attribute_id0)
                                    + "微克每立方米," + levelstr + ",建议您不要关闭净化器.";
                            output.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
                            output.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);
                        }

                    }
                }

                break;
            }
        } else {
            if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer += deviceobj.description + "不支持该功能.";
            else
                answer += "净化器目前还不支持该功能.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        }
        break;
    }
    case HomeAutoProtocol.Devtype_Aircondition: {
        HomeAutodeviceObjectNew statusdevObj = GetAirConditionStatusDevice();
        int modestatus = Integer.MAX_VALUE;
        int windstatus = Integer.MAX_VALUE;
        int onoffstatus = Integer.MAX_VALUE;
        int curTem = Integer.MAX_VALUE;
        if (statusdevObj != null) {
            modestatus = statusdevObj.GetArributeValue(cluster_hvacFanControl, Attribute_id0);
            windstatus = statusdevObj.GetArributeValue(cluster_hvacFanControl, Attribute_id1);
            onoffstatus = statusdevObj.GetArributeValue(cluster_hvacFanControl, Attribute_id2);
            curTem = statusdevObj.GetArributeValue(cluster_temperature_status, Attribute_id0);
        }
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {


            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);

            if (onoffstatus == 1) {
                answer = "空调是打开的哦.";
            } else {
                deviceobj.controlstatus.SetStatus(1);
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_LightColorControl);
                command.put("action_frame", frame_special_norepose);
                
                command.put("action_name", action_open);
                command.put("cluster_name", cluster_LightColorControl_name);
                statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                AddHomeAutoCmd(command);
                if (commandInfo.getCmdTypeFlag() != cmdTypeFlag.cmdtype_all) {
                    answer = "已经帮您打开空调";
                } else {
                    answer = "空调已打开.";
                }

                deviceobj.controlstatus.SetStatus(0x01);
            }
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        } else if ((commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop)
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {

            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);

            if (onoffstatus == 0) {
                answer = "空调是关闭的哦.";

            } else {
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_LightColorControl);
                command.put("action_frame", frame_special_norepose);
                
                command.put("action_name", action_close);
                command.put("cluster_name", cluster_LightColorControl_name);
                statusdevObj.SetArributeValue(0, cluster_hvacFanControl, Attribute_id2);
                
                AddHomeAutoCmd(command);
                if (commandInfo.getCmdTypeFlag() != cmdTypeFlag.cmdtype_all) {
                    answer = "已经帮您关闭空调";
                } else {
                    answer = "空调已关闭.";
                }
                deviceobj.controlstatus.SetStatus(0);
            }

            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_settemperature) {
            int setvalue = 25;
            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    
                    AddHomeAutoCmd(command);
                    
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_settemperature);
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_setup);
                    if (modestatus == 1) {
                        answer = "空调自动模式下温度是恒温调节的哦。";
                    } else if (curTem == 30)
                        answer = "空调已经达到最高温度30度。";
                    else {
                        command.put("action_id", 0x03);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special_norepose);
                        
                        command.put("action_name", action_setuptemp);
                        command.put("cluster_name", cluster_LightColorControl_name);
                        command.put("cur_temp", curTem+1);
                        statusdevObj.SetArributeValue(curTem+1, cluster_temperature_status, Attribute_id0);
                        
                        AddHomeAutoCmd(command);
                        answer = "空调温度已升高";
                    }
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }

            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    
                    AddHomeAutoCmd(command);
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_settemperature);
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_setdown);
                    if (modestatus == 3 && curTem == 12) { // 如果是除湿模式
                        answer = "空调已经达到最低温度";
                    } else if (modestatus == 1) {
                        answer = "空调自动模式下温度是恒温调节的哦。";
                    } else if (modestatus != 3 && curTem == 16)
                        answer = "空调已经达到最低温度16度。";
                    else {
                        command.put("action_id", 0x04);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special_norepose);
                        
                        command.put("action_name", action_setdowntemp);
                        command.put("cluster_name", cluster_LightColorControl_name);
                        statusdevObj.SetArributeValue(curTem-1, cluster_temperature_status, Attribute_id0);
                        command.put("cur_temp", curTem-1);
                        AddHomeAutoCmd(command);
                        answer = "空调温度已降低";
                    }

                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }
            } else {
                /*
                 * setvalue = 0; AppSlotEntry degreeslot =
                 * GetSlotByName("sensorvalue"); // 温度值
                 * 
                 * if (degreeslot != null) {
                 * 
                 * setvalue = getSensorSlotValue(); answer = "正在把空调设置到" +
                 * setvalue + "度";
                 * 
                 * } else { answer = "您设置的温度是无效输入。"; }
                 */
                answer = "空调支持温度升高和降低，暂不支持温度值设置。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

            }
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setwindpower
                || commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_default) {// 设置风速

            deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_setwindpower);
            // 调高档位
            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setup) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    
                    AddHomeAutoCmd(command);
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    answer = "空调暂不支持风力值设置,可以切换风力";
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_setup);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }

            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_setdown) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);

                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    
                    AddHomeAutoCmd(command);
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    deviceobj.controlstatus.SetCmdSecond(cmd_typeSecond.cmd_setdown);
                    answer = "空调暂不支持风力值设置,可以切换风力";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }
            } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_change) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
 
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);

                    AddHomeAutoCmd(command);
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    // 如果是除湿模式，则无法切换风力
                    if (modestatus == 3) {
                        answer = "空调除湿模式下风力自动调节哦。";
                    } else {
                        command.put("action_id", 0x02);
                        command.put("cluster_id", cluster_LightColorControl);
                        command.put("action_frame", frame_special_norepose);
                        
                        command.put("action_name", action_changewind);
                        command.put("cluster_name", cluster_LightColorControl_name);
                        command.put("cur_wind",getNextAirConditionWindPowerName(windstatus));
                        AddHomeAutoCmd(command);
                        
                        statusdevObj.SetArributeValue(getNextAirConditionWindPowerValue(windstatus), cluster_hvacFanControl, Attribute_id1);
                        
                        answer = devName + "风力已切换为"+getNextAirConditionWindPowerName(windstatus);
                    }

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }
            } else {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);

                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    
                    AddHomeAutoCmd(command);
                    answer = "空调是关闭的，已经帮您打开。";
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                    answer = "空调暂不支持风力值设置,可以切换风力";
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }
                
            }

        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setwinddirection) { // 设置风向


        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_setmod) { // 设置模式
         
            if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_change) {
                if (onoffstatus == 0) {// 空调关着
                    deviceobj.controlstatus.SetStatus(1);
                    command.put("action_id", 0x00);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    
                    command.put("action_name", action_open);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    statusdevObj.SetArributeValue(1, cluster_hvacFanControl, Attribute_id2);
                    AddHomeAutoCmd(command);
                    answer = "空调是关闭的，已经帮您打开。";

                    deviceobj.controlstatus.SetStatus(0x01);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else {
                	String mode = getNextAirConditionMode(modestatus);
                    answer = "空调模式已切换到" + mode;
                    
                    command.put("action_id", 0x01);
                    command.put("cluster_id", cluster_LightColorControl);
                    command.put("action_frame", frame_special_norepose);
                    
                    command.put("action_name", action_changemode);
                    command.put("cluster_name", cluster_LightColorControl_name);
                    command.put("cur_mode",mode);                
                    
                    AddHomeAutoCmd(command);
                    
                    statusdevObj.SetArributeValue(getNextAirConditionModeValue(modestatus), cluster_hvacFanControl, Attribute_id0);
                    output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                }

            } else {

                if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_automod) { // 自动模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调暂时不支持模式设置。";
                // command.put("action_id", 0x05);
                // command.put("cluster_id", cluster_LightColorControl);
                // command.put("action_frame", frame_special);
                //
                // AddHomeAutoCmd(command);
                //
                // if (name != null && !name.isEmpty())
                    // answer = name + "已经设置自动模式.";

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_dehumidifymod) { // 除湿模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已设置除湿模式.";
                // command.put("action_id", 0x04);
                // command.put("cluster_id", cluster_LightColorControl);
                // command.put("action_frame", frame_special);
                //
                // AddHomeAutoCmd(command);
                //
                // if (name != null && !name.isEmpty())
                    // answer = name + "已经设置除湿模式.";

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_hotmod) { // 制热模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已设置制热模式";

                // AddVIAHomeAutoCmd(command);
                //
                // if (commandInfo.getCmdTypeFlag() !=
                // cmdTypeFlag.cmdtype_all) {
                    // answer = name + "已经帮您设置制热模式";
                // } else {
                    // answer = name + "已经设置制热模式";
                // }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_coldmod) { // 制冷模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已设置制冷模式.";
                // AddVIAHomeAutoCmd(command);
                //
                // if (commandInfo.getCmdTypeFlag() !=
                // cmdTypeFlag.cmdtype_all) {
                    // answer = name + "已经帮您设置制冷模式.";
                // } else {
                    // answer = name + "已经设置制冷模式.";
                // }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_airsupplymod) { // 送风模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已设置送风模式.";

                // AddVIAHomeAutoCmd(command);
                //
                // if (commandInfo.getCmdTypeFlag() !=
                // cmdTypeFlag.cmdtype_all) {
                    // answer = name + "已经帮您设置送风模式.";
                // } else {
                    // answer = name + "已经设置送风模式.";
                // }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_coolmod) { // 凉爽模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已设置凉爽模式.";
                // AddVIAHomeAutoCmd(command);
                //
                // if (commandInfo.getCmdTypeFlag() !=
                // cmdTypeFlag.cmdtype_all) {
                    // answer = name + "已经帮您设置凉爽模式.";
                // } else {
                    // answer = name + "已经设置凉爽模式.";
                // }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_normalmod) { // 适中模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已经设置适中模式.";

                // AddVIAHomeAutoCmd(command);
                //
                // if (commandInfo.getCmdTypeFlag() !=
                // cmdTypeFlag.cmdtype_all) {
                    // answer = name + "已经帮您设置适中模式.";
                // } else {
                    // answer = name + "已经设置适中模式.";
                // }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_sweepmod) { // 扫风模式
                    answer = "空调仅支持模式切换。";
                    // answer = "空调已经设置扫风模式.";
                // command.put("action_id", 0x13);
                // command.put("cluster_id", cluster_LightColorControl);
                // command.put("action_frame", frame_special);
                //
                // AddHomeAutoCmd(command);
                //
                // if (deviceobj.description != null &&
                // !deviceobj.description.isEmpty())
                    // answer = deviceobj.description + "已经设置扫风模式.";
                // else
                    // answer = "空调已经设置扫风模式.";

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                } else if (commandInfo.getsecondCmd() == cmd_typeSecond.cmd_restmod) {// 睡眠模式
                    // answer = "空调已经设置睡眠模式.";
                    answer = "空调仅支持模式切换。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else {
                    answer = "空调仅支持模式切换。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }

            }
        } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {
            if (statusdevObj == null || onoffstatus == Integer.MAX_VALUE) {
                answer = "无法查询空调的状态，请检查设备。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

            } else if (onoffstatus == 0) {// 空调关着
                answer = "空调现在是关着的。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else {

                switch (commandInfo.getsecondCmd()) {
                case cmd_attrtemperature: // 查询温度
                    if (modestatus == 1) {
                        answer = "空调自动模式下温度是恒温调节的哦。";
                    } else
                        answer = "空调目前的温度是" + curTem + "度.";
                    break;
                case cmd_attrmode:
                    String mode = getAirConditionMode(modestatus);
                    answer = "空调的模式是" + mode;
                    break;
                case cmd_attrwindpower:
                    if (modestatus == 3) {
                        answer = "空调除湿模式下风力自动调节哦。";
                    }else{
                        String wind = getAirConditionWindPower(windstatus);
                        answer = "空调的风力是" + wind;
                    }
                    break;
                case cmd_attronoffstatus:
                    String onoff = getAirConditionOnOffStatus(windstatus);
                    answer = "空调是" + onoff;
                    break;

                }
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }
        }

        break;
        }
    case HomeAutoProtocol.Devtype_HumiditySensor: {
            
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {

            if (deviceobj != null)
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);
            // value = deviceobj.GetArributeValue(cluster_HumiditySensor,
            // Attribute_id0);
            int value = GetSensorValue(HomeAutoProtocol.Devtype_HumiditySensor,
                    cluster_HumiditySensor,
                    Attribute_id0);
            answer = commandInfo.getPositionName() + "目前的相对湿度是" + value + "%."
                    + GetHumidityLevelString(value);
            String answer1 = commandInfo.getPositionName() + "目前的相对湿度是百分之" + value + ","
                    + GetHumidityLevelString(value);
            output.AddSentence(OutputMap.PRESENT_TTS, answer1, APP_NAME);
        }
        
            break;
    }
    case HomeAutoProtocol.Devtype_LightIntenSensor: {
        // if(HasModifier("query", "control_obj")){
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {
            if (deviceobj != null)
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);

            if (commandInfo.getPositionName() == null
                    || commandInfo.getPositionName().isEmpty())
                answer = commandInfo.getPositionName() + "房间的光线";
            else
                answer = commandInfo.getPositionName() + "的光线";

            
            int level = GetSensorLevel(HomeAutoProtocol.Devtype_LightIntenSensor,
                    cluster_LightInten,
                    Attribute_id0);
            switch (level) {

            case attribute_level0:
                answer += "很强，您可以适当调节一下哦.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                break;
            case attribute_level1:

                answer += "比较明亮.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                break;
            case attribute_level2:
                answer += "比较舒适.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                break;
            case attribute_level3:
                answer += "较暗，不适合工作学习哦.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                break;
            case attribute_level4:
                answer += "很暗，您可以适当调节一下哦.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                break;

            }
        }
        

            break;
    }
    case HomeAutoProtocol.Devtype_AQISensor: {
        // if(HasModifier("query", "control_obj")){
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {
            if (deviceobj != null)
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);
            // int value=GetStatusValueByDeviceID(deviceID,1);
            // int value = deviceobj.GetArributeValue(cluster_PM25, 0x0000);
            int value = GetSensorValue(HomeAutoProtocol.Devtype_AQISensor, cluster_PM25,
                    Attribute_id0);

            answer = "室内的空气污染值是" + value + "ug/m3." + GetAirLevelString(value);
            String voice = "室内的空气污染值是" + value + "微克每立方米." + GetAirLevelString(value);
            output.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
            output.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);
        }
        
            break;
    }
    case HomeAutoProtocol.Devtype_TemperatureSensor: {
        // if(HasModifier("query", "control_obj")){
        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {
            if (deviceobj != null)
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);

            int value = GetSensorValue(HomeAutoProtocol.Devtype_TemperatureSensor,
                    cluster_TemperatureSensor,
                    Attribute_id0);
            answer = commandInfo.getPositionName() + "目前的温度是" + value + "度.";
            output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
        }
        
        break;
    }
    case HomeAutoProtocol.Devtype_Co2Sensor: {

        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_query) {
            if (deviceobj != null)
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_query);

            int value = GetSensorValue(HomeAutoProtocol.Devtype_Co2Sensor,
                    cluster_Co2Sensor, Attribute_id0);
            answer = commandInfo.getPositionName() + "目前的二氧化碳浓度是" + value + "PPM.";
            String voice = commandInfo.getPositionName() + "目前的二氧化碳浓度是"+ Number.StrWithDigital2StrWithChsNumber(Integer.toString(value)) + "PPM.";
            output.AddSentence(OutputMap.PRESENT_DISPLAY, answer, APP_NAME);
            output.AddSentence(OutputMap.PRESENT_TTS, voice, APP_NAME);
        }
       
    }

        break;
    case HomeAutoProtocol.Devtype_WindowCovering: {// 窗帘
      
        int currPosition = deviceobj.GetArributeValue(cluster_ClosuresWindowcoving,
                Attribute_id8);
        AppSlotEntry degreeslot = GetSlotByName("sensorvalue");

        if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_open) { // 打开

                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_open);

                deviceobj.controlstatus.SetStatus(1);

                int objPosition = 0;
                JSONObject percentage;
                cmd_typeSecond secCmd = commandInfo.getsecondCmd();
                if (currPosition == Integer.MAX_VALUE)
                    secCmd = cmd_typeSecond.cmd_default;
                switch (secCmd) {
                case cmd_setup: {
                // e.g. 再多开一点
                // e.g. 打开窗帘--再多一点
                    if (currPosition == 100 && deviceobj.controlstatus
                            .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                    answer = devName + "已经完全打开了.";
                    } else {
//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_open) {
//                            if (currPosition == 100)
//                            answer = devName + "已经完全打开了.";
//                            else
//                            answer = devName + "正在打开，请稍后.";
//                        } else {

                            objPosition = ((currPosition + 10) > 100) ? 100
                                    : (currPosition + 10);
                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            
                            command.put("action_name", action_changesite);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);

                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);
                            
                            
                            deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);
                            command.put("param1", percentage);
                        AddHomeAutoCmd(command);
                        answer = "正在按您的要求操作" + devName + ".";

                        //}

                    }
                }
                    break;
                case cmd_setdown: {
                // e.g.再少开一点
                // e.g.打开窗帘--少一点
                    if (currPosition == 0 && deviceobj.controlstatus
                            .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                    answer = devName + "已经完全关闭了.";
                    } else {
//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_open)
//                            if (currPosition == 100)
//                            answer = devName + "已经完全打开了.";
//                            else
//                            answer = devName + "正在打开，请稍后。";
//                        else {
                            objPosition = ((currPosition - 10) < 0) ? 0 : (currPosition - 10);

                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);

                            command.put("action_name", action_changesite);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);
                            
                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);

                            command.put("param1", percentage);
                        AddHomeAutoCmd(command);
                        
                        deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);

                        answer = "正在按您的要求操作" + devName + ".";

                        //}
                    }
                }
                    break;
                case cmd_degree:
                // 提供了打开的程度
                    if (degreeslot == null) {
                    answer = "对不起，您没有提供操作窗帘的程度.";
                    } else {
                        objPosition = getSensorSlotValue();

                    // 若目标位置和当前位置不同，则运行到目标位置
                        if (objPosition != currPosition) {

                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);

                            command.put("action_name", action_changesite);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);
                            
                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);

                            command.put("param1", percentage);
                            AddHomeAutoCmd(command);
                            
                            deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);

                            
                        answer = "正在按您的要求操作" + devName + ".";
                            deviceobj.controlstatus.SetStatus(0x05);
                        } else {
                            if (deviceobj.description != null
                                    && !deviceobj.description.isEmpty())
                            answer = deviceobj.description + "已经在您要求的位置了.";
                            else
                            answer = devName + "已经在您要求的位置了.";
                        }

                    }
                    break;
                case cmd_default:
                // 1. 用户输入没有要求打开到某种程度
                // e.g. 打开窗帘
                    if (currPosition == 100 && deviceobj.controlstatus
                            .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                        if (deviceobj.description != null && !deviceobj.description.isEmpty())
                        answer = deviceobj.description + "已经完全打开了.";
                        else
                        answer = devName + "已经完全打开了.";
                    } else {
//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_open) {
//                            if (currPosition == 100)
//                            answer = devName + "已经完全打开了.";
//                            else
//                            answer = devName + "正在打开，请稍后.";
//                        } else {
                            command.put("action_id", 0x00);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            
                            command.put("action_name", action_open);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);
                            
                            AddHomeAutoCmd(command);
                            
                            deviceobj.SetArributeValue(100, cluster_ClosuresWindowcoving, Attribute_id8);

                        answer = "正在帮您打开" + devName + ".";
                        //}
                    }

                        
                    break;
                default:
                answer = devName + "还不支持该功能.";
                    break;
                    }
                deviceobj.controlstatus.SetStatus(0x01);


                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);

                deviceobj.controlstatus.SetLastCmdPrimary(cmd_typePrimary.cmd_open);

            } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_close) {

                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_close);


            // 用户没有提供关闭的程度
                    int objPosition = 0;
                    JSONObject percentage = null;
                cmd_typeSecond secCmd = commandInfo.getsecondCmd();
                if (currPosition == Integer.MAX_VALUE)
                    secCmd = cmd_typeSecond.cmd_default;
                switch (secCmd) {
                    case cmd_setup:
                // e.g.关闭窗帘--再多一点
                // e.g.再多关闭一点
                    if (currPosition == 0 && deviceobj.controlstatus
                            .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                        if (deviceobj.description != null && !deviceobj.description.isEmpty())
                        answer = deviceobj.description + "已经完全关闭了，您可以检查一下设备.";
                        else
                        answer = devName + "已经完全关闭了.";
                    } else {
//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_close) {
//                            if (currPosition == 0)
//                            answer = devName + "已经完全关闭了.";
//                            else
//                            answer = devName + "正在关闭，请稍后.";
//
//                        } else {
                            objPosition = ((currPosition - 10) < 0) ? 0 : (currPosition - 10);

                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            
                            command.put("action_name", action_changesite);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);

                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);
                            
                            deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);

                            
                            command.put("param1", percentage);
                            AddHomeAutoCmd(command);
                        answer = "正在按您的要求操作" + devName + ".";
                            deviceobj.controlstatus.SetStatus(0x05);
                        //}
                        }

                        break;
                    case cmd_setdown:
                // 再少关一点
                // e.g.关闭窗帘--少一点

                    if (currPosition == 0 && deviceobj.controlstatus
                            .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                        if (deviceobj.description != null && !deviceobj.description.isEmpty())
                        answer = deviceobj.description + "已经完全关闭了，您可以检查一下设备.";
                        else
                        answer = devName + "已经完全关闭了.";
                    } else {

//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_close) {
//                            if (currPosition == 0)
//                            answer = devName + "已经完全关闭了.";
//                            else
//                            answer = devName + "正在关闭，请稍后.";
//                        } else {
                            objPosition = ((currPosition + 10) > 100) ? 100
                                    : (currPosition + 10);
                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            command.put("action_name", action_changesite);
                            command.put("cluster_name",cluster_ClosuresWindowcoving_name);

                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);
                            command.put("param1", percentage);
                            AddHomeAutoCmd(command);
                            
                            deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);

                        answer = "正在按您的要求操作" + devName + ".";
                            deviceobj.controlstatus.SetStatus(0x05);
                        //}
                    }
                        break;
                case cmd_degree:
                    if (degreeslot == null) {
                    answer = "对不起，您没有提供操作窗帘的程度.";
                    } else {

                    objPosition = 100-getSensorSlotValue();
                        if (objPosition != currPosition) {                                

                            command.put("action_id", 0x05);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            
                            command.put("action_name", action_changesite);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);

                            // parameter
                            percentage = new JSONObject();
                            percentage.put("data_type_id", 0x20);
                            percentage.put("data_value", objPosition);
                            percentage.put("data_type_name", data_type_uint8);
                            command.put("param1", percentage);
                        AddHomeAutoCmd(command);
                        deviceobj.SetArributeValue(objPosition, cluster_ClosuresWindowcoving, Attribute_id8);

                        answer = "正在按您的要求操作" + devName + ".";
                            deviceobj.controlstatus.SetStatus(0x01);

                        } else {
                        answer = devName + "已经在您要求的位置了.";
                        }

                    }
                    break;
                    case cmd_default:

                // 关闭窗帘
                    if (currPosition == 0 && deviceobj.controlstatus
                        .GetLastCmdPrimary() == cmd_typePrimary.cmd_default) {
                    answer = devName + "已经完全关闭了，您可以检查一下设备.";

                    } else {
//                        if (deviceobj.controlstatus
//                                .GetLastCmdPrimary() == cmd_typePrimary.cmd_close) {
//                            if (currPosition == 0)
//                            answer = devName + "已经完全关闭了.";
//                            else
//                            answer = devName + "正在关闭，请稍后.";
//                        } else {
                            command.put("action_id", 0x01);
                            command.put("cluster_id", cluster_ClosuresWindowcoving);
                            command.put("action_frame", frame_special);
                            
                            command.put("action_name", action_close);
                            command.put("cluster_name", cluster_ClosuresWindowcoving_name);
                        AddHomeAutoCmd(command);
                        deviceobj.SetArributeValue(0, cluster_ClosuresWindowcoving, Attribute_id8);

                        answer = "正在帮您关闭" + devName + ".";
                            deviceobj.controlstatus.SetStatus(1);
                        //}
                    }


                    break;
                default:
                answer = devName + "还不支持该功能.";
                    break;

                    }

                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
                deviceobj.controlstatus.SetLastCmdPrimary(cmd_typePrimary.cmd_close);

            } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_stop
                    && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) {
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_stop);

                command.put("action_id", 0x02);
                command.put("cluster_id", cluster_ClosuresWindowcoving);
                command.put("action_frame", frame_special);
                
                command.put("action_name", action_stop);
                command.put("cluster_name", cluster_ClosuresWindowcoving_name);
                
                AddHomeAutoCmd(command);
                
                deviceobj.SetArributeValue(50, cluster_ClosuresWindowcoving, Attribute_id8);

                
            answer = "好的。";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else if (commandInfo.getprimaryCmd() == cmd_typePrimary.cmd_identify
                && commandInfo.getsecondCmd() == cmd_typeSecond.cmd_default) { // 识别设备
                deviceobj.controlstatus.SetCmdPrimary(cmd_typePrimary.cmd_identify);
                command.put("action_id", 0x00);
                command.put("cluster_id", cluster_Identify);
                command.put("action_frame", frame_special);

                JSONObject attr1 = new JSONObject();
                attr1.put("data_type_id", 0x21);
                attr1.put("data_value", 6);
                command.put("param1", attr1);
                AddHomeAutoCmd(command);
                if (deviceobj.description != null && !deviceobj.description.isEmpty())
                answer = "正在识别" + deviceobj.description + ".";
                else
                answer = "正在识别窗帘.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            } else {
            answer += devName + "不支持该功能.";
                output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, answer, APP_NAME);
            }


        break;
    }
    default:
        output.AddSentence(OutputMap.PRESENT_TTS_AND_DISPLAY, "hello Auto ", APP_NAME);
        break;
    }
    // set APP status
    //super.Status().SetCode(appStatus);

    String savename = "";

    if (devName != null && !devName.isEmpty())
        savename = devName;
    // 保存设备slot
   // SaveToHistory("物名", "设备名称", savename);
    
    //if (appStatus == AppStatusCode.TOPIC_END)
        ResetCommandInfo();

    return appStatus;
}

private String getAirConditionWindPower(int modestatus) {
    // TODO Auto-generated method stub
    String mode = "";
    switch (modestatus) {
    case 1:
        mode = "自动";
        break;
    case 2:
        mode = "低速";
        break;
    case 3:
        mode = "中低速";
        break;
    case 4:
        mode = "中速";
        break;
    case 5:
        mode = "中高速";
        break;
    case 6:
        mode = "高速";
        break;
    case 7:
        mode = "超强";
        break;

    }

    return mode;
}
private int getNextAirConditionWindPowerValue(int modestatus) {
    // TODO Auto-generated method stub
    int mode = 1;
    switch (modestatus) {
    case 7:
        mode = 1;
        break;
    case 1:
        mode = 2;
        break;
    case 2:
        mode = 3;
        break;
    case 3:
        mode = 4;
        break;
    case 4:
        mode = 5;
        break;
    case 5:
        mode = 6;
        break;
    case 6:
        mode = 7;
        break;

    }

    return mode;
}

private String getNextAirConditionWindPowerName(int modestatus) {
    // TODO Auto-generated method stub
    String mode = "";
    switch (modestatus) {
    case 7:
        mode = "自动";
        break;
    case 1:
        mode = "低速";
        break;
    case 2:
        mode = "中低速";
        break;
    case 3:
        mode = "中速";
        break;
    case 4:
        mode = "中高速";
        break;
    case 5:
        mode = "高速";
        break;
    case 6:
        mode = "超强";
        break;

    }

    return mode;
}

private String getAirConditionMode(int value) {
    // TODO Auto-generated method stub
    String mode = "";
    switch (value) {
    case 1:
        mode = "自动";
        break;
    case 2:
        mode = "制冷";
        break;
    case 3:
        mode = "除湿";
        break;
    case 4:
        mode = "送风";
        break;
    case 5:
        mode = "加热";
        break;
    }
    return mode;
}

private String getNextAirConditionMode(int value) {
    // TODO Auto-generated method stub
    String mode = "";
    switch (value) {
    case 1:
        mode = "制冷";
        break;
    case 2:
        mode = "除湿";
        break;
    case 3:
        mode = "送风";
        break;
    case 4:
        mode = "加热";
        break;
    case 5:
        mode = "自动";
        break;
    }
    return mode;
}

private int getNextAirConditionModeValue(int value) {
    // TODO Auto-generated method stub
    int mode = 1;
    switch (value) {
    case 1:
        mode = 2;
        break;
    case 2:
        mode = 3;
        break;
    case 3:
        mode = 4;
        break;
    case 4:
        mode = 5;
        break;
    case 5:
        mode = 1;
        break;
    }
    return mode;
}

private String getAirConditionOnOffStatus(int value) {
    // TODO Auto-generated method stub
    String mode = "";
    switch (value) {
    case 1:
        mode = "开着的";
        break;
    case 0:
        mode = "关着的";
        break;
    }
    return mode;
}
private HomeAutodeviceObjectNew GetAirConditionStatusDevice() {

    HomeAutodeviceObjectNew[] airCList =homeAutoInfo .GetDeviceObjByDevType(HomeAutoProtocol.Devtype_Aircondition);
    HomeAutodeviceObjectNew statusdevice = null;
    for (HomeAutodeviceObjectNew device : airCList) {
        String id = device.device_ID;
        if (id.substring(id.length() - 4, id.length()).equalsIgnoreCase("1000")) {
            statusdevice = device;
            break;
        }

    }

    return statusdevice;
}

private HomeAutodeviceObjectNew GetAirConditionControlDevice() {

    HomeAutodeviceObjectNew[] airCList =homeAutoInfo.GetDeviceObjByDevType(HomeAutoProtocol.Devtype_Aircondition);
    HomeAutodeviceObjectNew controldevice = null;
    for (HomeAutodeviceObjectNew device : airCList) {
        String id = device.device_ID;
        if (id.substring(id.length() - 4, id.length()).equalsIgnoreCase("0F00")) {
            controldevice = device;
            break;
        }

    }

    return controldevice;
}

/**
 * 获取answer中需要的设备名称,可能包括楼层和区域
 * 
 * @return
 */
private String getAnswerName() {
    // int floorsum = super.GetUser().getHomeAutoInfo().getFloorTypeSum();
    // int locationsum =
    // super.GetUser().getHomeAutoInfo().getLocationTypeSum();

    String name = getDeviceAnswerName();
    if (!name.isEmpty()) {
        // if (floorsum > 1) {
        // String floorname = commandInfo.getFloorName();
        // if (floorname.isEmpty())
        // floorname = getFloorNameByFloorNum(commandInfo.getFloorNum());
        //
        // name += floorname;
        // }
        // if (locationsum > 1) {
            String positonname = commandInfo.getPositionName();
        if (!positonname.isEmpty())
            // positonname =
            // getPostionNameByPositionNum(commandInfo.getPositionNum());
            name = positonname + "的" + name;
        // }

    }

    return name;

}

private String getDevtypeName(){
	String name="设备类型";
	switch (commandInfo.getDeviceType()) {
    case HomeAutoProtocol.Devtype_Aircleaner:
        name = "净化器";
        break;
    case HomeAutoProtocol.Devtype_Aircondition:
        name = "空调";
        break;
    case HomeAutoProtocol.Devtype_Light:
        name = "灯";
        break;
    case HomeAutoProtocol.Devtype_Illuminations:
        name = "彩灯";
        break;
    case HomeAutoProtocol.Devtype_Projector:
        name = "投影机";
        break;
    case HomeAutoProtocol.Devtype_Projectorbackdrop:
        name = "投影布幕";
        break;
    case HomeAutoProtocol.Devtype_Television:
        name = "电视";
        break;
    case HomeAutoProtocol.Devtype_WindowCovering:
        name = "窗帘";
        break;
    case HomeAutoProtocol.Devtype_Humidifier:
        name = "加湿器";
        break;
    default:
        name = "设备";
        break;

    }
	
	return name;
}
/**
 * 获取设备的名称，不包括楼层和区域
 * 
 * @return
 */
private String getDeviceAnswerName() {
    String name = "";
    // 以用户的说法优先回答

    if (!commandInfo.getDeviceName().isEmpty())
        name = commandInfo.getDeviceName();
    else if (!commandInfo.getsplitName().isEmpty())
        name = commandInfo.getsplitName();
    // get general name
    if (name.isEmpty()) {
        switch (commandInfo.getDeviceType()) {
        case HomeAutoProtocol.Devtype_Aircleaner:
            name = "净化器";
            break;
        case HomeAutoProtocol.Devtype_Aircondition:
            name = "空调";
            break;
        case HomeAutoProtocol.Devtype_Light:
            name = "灯";
            break;
        case HomeAutoProtocol.Devtype_Illuminations:
            name = "彩灯";
            break;
        case HomeAutoProtocol.Devtype_Projector:
            name = "投影机";
            break;
        case HomeAutoProtocol.Devtype_Projectorbackdrop:
            name = "投影布幕";
            break;
        case HomeAutoProtocol.Devtype_Television:
            name = "电视";
            break;
        case HomeAutoProtocol.Devtype_WindowCovering:
            name = "窗帘";
            break;
        case HomeAutoProtocol.Devtype_Humidifier:
            name = "加湿器";
            break;
        default:
            name = "设备";
            break;

        }

    }

    return name;
}

private colourStatus GetAtmosphere(HomeAutodeviceObjectNew deviceobj) {
    // TODO Auto-generated method stub
    int RGBvalue = deviceobj.GetArributeValue(cluster_General_Time, Attribute_id3);
    colourStatus currentstatus = getcurrentColorStatus(RGBvalue);

    String colorname = currentstatus.GetName();
    colourStatus color = null;
    
    if (colorData.containsKey(colorname)) {
       
       if(isSomeAtmosphere(cmd_typeSecond.cmd_romantic, currentstatus)!=0xFF)
           color=GetColorAtmosphere(cmd_typeSecond.cmd_soft, 0);
       else if(isSomeAtmosphere(cmd_typeSecond.cmd_soft, currentstatus)!=0xFF)
           color=GetColorAtmosphere(cmd_typeSecond.cmd_mystery, 0);
        else if (isSomeAtmosphere(cmd_typeSecond.cmd_mystery, currentstatus) != 0xFF)
            color = GetColorAtmosphere(cmd_typeSecond.cmd_romantic, 0);
        else
            color = GetColorAtmosphere(cmd_typeSecond.cmd_romantic, 0);
    }
    return color;
}

private colourStatus GetColorAtmosphere(cmd_typeSecond type, int index) {
    // TODO Auto-generated method stub
    String colorname = "";
    switch (type) {
    case cmd_romantic:
        colorname = romanticList.get(index);
        break;
    case cmd_soft:
        colorname = softList.get(index);
        break;
    case cmd_mystery:
        colorname = mysteryList.get(index);
        break;

    default:
        break;
    }

    if (colorData.containsKey(colorname))
        try {
            return (colourStatus) colorData.get(colorname).clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    return null;
}

@SuppressWarnings("incomplete-switch")
private int isSomeAtmosphere(cmd_typeSecond colormode, colourStatus objectcolor) {

    // TODO Auto-generated method stub
    List<String> templist = null;
    int index = 0xFF;
    if (objectcolor == null)
        return index;
    switch (colormode) {
    case cmd_romantic:
        templist = romanticList;
        break;
    case cmd_soft:
        templist = softList;
        break;
    case cmd_mystery:
        templist = mysteryList;
        break;

    }
    if (templist == null || templist.size() == 0)
        return index;

    for (int i = 0; i < templist.size(); i++) {
        String key = templist.get(i);
        colourStatus tempcolor = colorData.get(key);
        if (tempcolor != null && tempcolor.GetRGBvalue() == objectcolor.GetRGBvalue()) {
            index = i;
            break;
        }
    }

    return index;

}

private int getSensorSlotValue() {
    // TODO Auto-generated method stub
    AppSlotEntry degreeslot = GetSlotByName("sensorvalue");
    int result = 0;
    NumDetail numberdetail = degreeslot.getNumDetail();
   if(numberdetail.getType().equals(NumDetail.TYPE_NUMBER)&&numberdetail.hasRecommendValue()){// 整数
	   result=Integer.parseInt(numberdetail.getRecommendValue());
   }else if(numberdetail.getType().equals(NumDetail.TYPE_FLOAT)&&numberdetail.hasRecommendValue()){//浮点数
	   float floatva = Float.parseFloat(numberdetail.getRecommendValue());
   if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WindowCovering) {
       if (floatva > 0 && floatva < 1)
           result = (int) (floatva * 100);
       else
           result = (int) floatva;
   } else
       result = (int) floatva;
   }
	
   
    return result;
}


private colourStatus GetColorTone(COLOR_TONE_TYPE type, int index) {
    // TODO Auto-generated method stub
    String colorname = "";
    switch (type) {
    case WARM:
        colorname = warmList.get(index);
        break;
    case BRIGHT:
        colorname = brightList.get(index);
        break;
    case CALM:
        colorname = calmList.get(index);
        break;
    case COOL:
        colorname = coolList.get(index);
        break;
    case CUTE:
        colorname = cuteList.get(index);
        break;
    case GRACE:
        colorname = graceList.get(index);
        break;
    case SPORT:
        colorname = sportList.get(index);
        break;
    default:
        break;
    }

    if (colorData.containsKey(colorname))
        try {
            return (colourStatus) colorData.get(colorname).clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    return null;
}

private colourStatus getcurrentColorStatus(int rGBvalue) {
    // TODO Auto-generated method stub
    colourStatus current = null;

    Iterator<Entry<String, colourStatus>> entries = colorData.entrySet().iterator();
    while (entries.hasNext()) {
        Entry<String, colourStatus> tempobj = entries.next();
        colourStatus tmpcolor = tempobj.getValue();
        if (tmpcolor.GetRGBvalue() == rGBvalue) {

            current = tmpcolor;
            break;

        }

    }
    return current;
}

private void AdjustColourLightRGB(JSONObject command, int rgvalue, int bvalue) {
    // TODO Auto-generated method stub
    command.put("action_id", 0x08);
    command.put("cluster_id", cluster_light_color_control);
    command.put("action_frame", frame_special);
    
    command.put("action_name", action_setcolor);
    command.put("cluster_name", cluster_light_color_control_name);

    JSONObject param1 = new JSONObject();
    param1.put("data_type_id", 0x29);
    param1.put("data_value", rgvalue);
    param1.put("data_type_name", data_type_int16);
    command.put("param1", param1);   
   

    JSONObject param2 = new JSONObject();
    param2.put("data_type_id", 0x29);
    param2.put("data_value", bvalue);
    param2.put("data_type_name", data_type_int16);
    command.put("param2", param2);

    AddHomeAutoCmd(command);
}

private int isSomeColorMode(int colormode, colourStatus objectcolor) {
    // TODO Auto-generated method stub
    List<String> templist = null;
    int index = 0xFF;
    if (objectcolor == null)
        return index;
    switch (colormode) {
    case colormode_warm:
        templist = warmList;
        break;
    case colormode_bright:
        templist = brightList;
        break;
    case colormode_cute:
        templist = cuteList;
        break;
    case colormode_cool:
        templist = coolList;
        break;
    case colormode_grace:
        templist = graceList;
        break;
    case colormode_sport:
        templist = sportList;
        break;
    case colormode_calm:
        templist = calmList;
        break;
    }
    if (templist == null || templist.size() == 0)
        return index;

    for (int i = 0; i < templist.size(); i++) {
        String key = templist.get(i);
        colourStatus tempcolor = colorData.get(key);
        if (tempcolor != null && tempcolor.GetRGBvalue() == objectcolor.GetRGBvalue()) {
            index = i;
            break;
        }
    }
    return index;
}

private colourStatus GetColor(HomeAutodeviceObjectNew deviceobj) {
    /*
     * 按照UX需求，换颜色时，不指定颜色的时候，按照基准色“白-红-橙-黄-绿-青-蓝-紫”的顺序循环调换。
     */


    int RGBvalue = deviceobj.GetArributeValue(cluster_General_Time, Attribute_id3);
    colourStatus currentstatus = getcurrentColorStatus(RGBvalue);

    // 检测换颜色的列表里是否有这个颜色
    boolean hasfound = false;
    Iterator<Entry<String, colourStatus>> entries = colorData.entrySet().iterator();
    while (entries.hasNext()) {
        Entry<String, colourStatus> entry = entries.next();
        colourStatus objectcolor = entry.getValue();
        if (objectcolor.GetRGBvalue() == RGBvalue) {
            hasfound = true;
            break;
        }

    }
    String colorname = "";
    if (currentstatus != null)
        colorname = currentstatus.GetName();
    if (!hasfound || hasfound && (colorname == null || colorname.isEmpty()))
        try {
            return (colourStatus) colorData.get("紫").clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    colourStatus color = null;
    try {
        if (colorData.containsKey(colorname)) {// 获取其下一个颜色
            if (colorname.equals("白"))
                color = (colourStatus) colorData.get("红").clone();
            else if (colorname.equals("红"))
                color = (colourStatus) colorData.get("橙").clone();
            else if (colorname.equals("橙"))
                color = (colourStatus) colorData.get("黄").clone();
            else if (colorname.equals("黄"))
                color = (colourStatus) colorData.get("绿").clone();
            else if (colorname.equals("绿"))
                color = (colourStatus) colorData.get("青").clone();
            else if (colorname.equals("青"))
                color = (colourStatus) colorData.get("蓝").clone();
            else if (colorname.equals("蓝"))
                color = (colourStatus) colorData.get("紫").clone();
            else if (colorname.equals("紫"))
                color = (colourStatus) colorData.get("白").clone();

        }
    } catch (CloneNotSupportedException e) {
        e.printStackTrace();
    }

    if (color != null)
        return color;
    // // TODO Auto-generated method stub
    String[] keys = colorData.keySet().toArray(new String[0]);

    Random random = new Random();
    String key = keys[random.nextInt(keys.length)];
    try {
        color = (colourStatus) colorData.get(key).clone();
    } catch (CloneNotSupportedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    return color;
}

private colourStatus GetTone(HomeAutodeviceObjectNew deviceobj) {
    /*
     * 按照UX需求，换色调时，不指定颜色的时候，按照基准色“可爱-暖色-运动-明亮-优雅-沉稳-冷色”的顺序循环调换。
     */
    int RGBvalue = deviceobj.GetArributeValue(cluster_General_Time, Attribute_id3);
    colourStatus currentstatus = getcurrentColorStatus(RGBvalue);

    String colorname = "";
    if (currentstatus != null)
        colorname = currentstatus.GetName();
    colourStatus color = null;
    try {
        if (colorData.containsKey(colorname)) {// 获取其下一个色系
            if (colorname.equals(cuteList.get(0)) || colorname.equals(cuteList.get(1))
                    || colorname.equals(cuteList.get(2)))
                color = (colourStatus) colorData.get(warmList.get(0)).clone();
            else if (colorname.equals(warmList.get(0)) || colorname.equals(warmList.get(1))
                    || colorname.equals(warmList.get(2)))
                color = (colourStatus) colorData.get(sportList.get(0)).clone();
            else if (colorname.equals(sportList.get(0)) || colorname.equals(sportList.get(1))
                    || colorname.equals(sportList.get(2)))
                color = (colourStatus) colorData.get(brightList.get(0)).clone();
            else if (colorname.equals(brightList.get(0)) || colorname.equals(brightList.get(1))
                    || colorname.equals(brightList.get(2)))
                color = (colourStatus) colorData.get(graceList.get(0)).clone();
            else if (colorname.equals(graceList.get(0)) || colorname.equals(graceList.get(1))
                    || colorname.equals(graceList.get(2)))
                color = (colourStatus) colorData.get(calmList.get(0)).clone();
            else if (colorname.equals(calmList.get(0)) || colorname.equals(calmList.get(1))
                    || colorname.equals(calmList.get(2)))
                color = (colourStatus) colorData.get(coolList.get(0)).clone();
            else if (colorname.equals(coolList.get(0)) || colorname.equals(coolList.get(1))
                    || colorname.equals(coolList.get(2)))
                color = (colourStatus) colorData.get(cuteList.get(0)).clone();
            else
                color = (colourStatus) colorData.get(cuteList.get(0)).clone();
    }
    // // TODO Auto-generated method stub
//    String[] keys = colorData.keySet().toArray(new String[0]);
//
//    Random random = new Random();
//    String key = keys[random.nextInt(keys.length)];
//        color = (colourStatus) colorData.get(key).clone();
    } catch (CloneNotSupportedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    return color;
}
public static int[] hsb2rgb(double h, double s, double v) {

    int[] result = { 0, 0, 0 };

    if (h < 0.0 || h > 360.0 || s < 0.0 || s > 1.0 || v < 0.0 || v > 1.0)
        return result;

    double r = 0, g = 0, b = 0;
    int i = (int) ((h / 60) % 6);
    double f = (h / 60) - i;
    double p = v * (1 - s);
    double q = v * (1 - f * s);
    double t = v * (1 - (1 - f) * s);
    switch (i) {
    case 0:
        r = v;
        g = t;
        b = p;
        break;
    case 1:
        r = q;
        g = v;
        b = p;
        break;
    case 2:
        r = p;
        g = v;
        b = t;
        break;
    case 3:
        r = p;
        g = q;
        b = v;
        break;
    case 4:
        r = t;
        g = p;
        b = v;
        break;
    case 5:
        r = v;
        g = p;
        b = q;
        break;
    default:
        break;
    }
    return new int[] { (int) (r * 255.0), (int) (g * 255.0), (int) (b * 255.0) };
}
private final Collection<AppSlotEntry> GetSlotList(){
	return slots.values();
}
private void DoPrepareExit(int code) {
    Status().SetCode(code);

    Collection<AppSlotEntry> slotList = GetSlotList();
    for (AppSlotEntry slot : slotList) {
        if (slot.isbUpdated()) {
            slot.setbUpdated(false);
        }
    }

}

/**
 * 
 * @param devType
 * @param clusterID
 * @param AttributeID
 * @return 暂时取所有的湿度传感器的平均值，showroom 建立起来之后，将室内和室外的处理方法分开
 */
private int GetSensorValue(int devType, int clusterID, int AttributeID) {

    int value = 0;
    HomeAutodeviceObjectNew[] devicelist = homeAutoInfo.GetDeviceObjByDevType(devType, clusterID, AttributeID);

    if (devicelist.length == 1)
        value = devicelist[0].GetArributeValue(clusterID, AttributeID);
    else if (devicelist.length == 2)
        // 取平均值
        value = (devicelist[0].GetArributeValue(clusterID, AttributeID) + devicelist[1]
                .GetArributeValue(clusterID, AttributeID)) / 2;
    else if (devicelist.length > 2) {
        // 去掉最大值，最小值，剩下的取平均值
        int sum = 0;
        for (int i = 1; i < devicelist.length - 1; i++) {
            sum = sum + devicelist[i].GetArributeValue(clusterID, AttributeID);
            // System.out.println(devicelist[i].GetArributeValue(clusterID,
            // AttributeID));
        }
        value = sum / (devicelist.length - 2);
    }
    return value;
}

private int GetSensorLevel(int devType, int clusterID, int AttributeID) {

    int value = 0;

    HomeAutodeviceObjectNew[] devicelist = homeAutoInfo.GetDeviceObjByDevType(devType, clusterID, AttributeID);
    if (devicelist.length == 1)
        value = devicelist[0].GetArributeValue(clusterID, AttributeID);
    else if (devicelist.length == 2)
        // 取平均值
        value = (devicelist[0].GetArributeValue(clusterID, AttributeID) + devicelist[1]
                .GetArributeValue(clusterID, AttributeID)) / 2;
    else if (devicelist.length > 2) {
        // 去掉最大值，最小值，剩下的取平均值
        int sum = 0;
        for (int i = 1; i < devicelist.length - 1; i++)
            sum = sum + devicelist[i].GetArributeValue(clusterID, AttributeID);
        value = sum / (devicelist.length - 2);
    }
    int level = 0;
    switch (devType) {
    case HomeAutoProtocol.Devtype_AQISensor:
        level = this.GetAirLevel(value);
        break;
    case HomeAutoProtocol.Devtype_LightIntenSensor:
        level = GetLightIntensityStatus(value);
        break;
    case HomeAutoProtocol.Devtype_HumiditySensor:
        level = GetHumidityStatus(value);
        break;
    }
    return level;
}

private String getDeviceName() {
    // TODO Auto-generated method stub
    String name = null;
    if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircondition)
        name = "空调";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Aircleaner)
        name = "空气净化器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Dehumidifier)
        name = "除湿器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Humidifier)
        name = "加湿器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Illuminations)
        name = "彩灯";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_Light)
        name = commandInfo.getslotName();
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_TemperatureSensor)
        name = "温度传感器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_LightIntenSensor)
        name = "光线传感器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_HumiditySensor)
        name = "湿度传感器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_AQISensor)
        name = "空气质量传感器";
    else if (commandInfo.getDeviceType() == HomeAutoProtocol.Devtype_WindowCovering)
        name = "窗帘";
    return name;
}

public int GetSlotCount() {
	// TODO Auto-generated method stub
	return this.slots.size();
}


//cluster id
static final int cluster_Identify = 0x0003;
static final int cluster_General_Time = 0x000A;
static final int cluster_light_color_control = 0x0300;
static final int cluster_PM25=0x0405;
static final int cluster_LightInten=0x0400;
static final int cluster_TemperatureSensor=0x0402;
static final int cluster_Co2Sensor = 0x0404;
static final int cluster_HumiditySensor=0x0405;
static final int cluster_Onoff_Switch=0x0006;
static final int cluster_RemoteControl=0x0008;
static final int cluster_LightColorControl = 0x0300;
static final int cluster_hvacFanControl = 0x0202;
static final int cluster_temperature_status = 0x0201;
static final int cluster_ClosuresWindowcoving = 0x0102;

//cluster name
static final String cluster_Identify_name = "ZCL_CLUSTER_ID_GEN_IDENTIFY";
static final String cluster_General_Time_name =  "ZCL_CLUSTER_ID_GEN_TIME";
static final String cluster_light_color_control_name =  "ZCL_CLUSTER_ID_LIGHTING_COLOR_CONTROL";
static final String cluster_PM25_name= "ZCL_CLUSTER_ID_MS_RELATIVE_HUMIDITY";
static final String cluster_LightInten_name= "ZCL_CLUSTER_ID_MS_ILLUMINANCE_MEASUREMENT";
static final String cluster_TemperatureSensor_name= "ZCL_CLUSTER_ID_MS_TEMPERATURE_MEASUREMENT";
static final String cluster_Co2Sensor_name =  "ZCL_CLUSTER_ID_MS_FLOW_MEASUREMENT";
static final String cluster_HumiditySensor_name= "ZCL_CLUSTER_ID_MS_RELATIVE_HUMIDITY";
static final String cluster_Onoff_Switch_name= "ZCL_CLUSTER_ID_GEN_ON_OFF";
static final String cluster_RemoteControl_name= "ZCL_CLUSTER_ID_GEN_LEVEL_CONTROL";
static final String cluster_LightColorControl_name =  "ZCL_CLUSTER_ID_LIGHTING_COLOR_CONTROL";
static final String cluster_hvacFanControl_name =  "ZCL_CLUSTER_ID_HVAC_FAN_CONTROL";
static final String cluster_temperature_status_name =  "ZCL_CLUSTER_ID_HVAC_THERMOSTAT";
static final String cluster_ClosuresWindowcoving_name=  "ZCL_CLUSTER_ID_CLOSURES_WINDOW_COVERING";


//action name
static final String  action_open="打开";
static final String  action_close="关闭";
static final String  action_stop="停止";
static final String  action_next="下一个";
static final String  action_last="上一个";
static final String  action_confirm="确认";
static final String  action_back="返回";
static final String  action_setchannel="切换频道";
static final String  action_setcolor="设置颜色";
static final String  action_setuptemp="升高温度";
static final String  action_setdowntemp="降低温度";
static final String  action_setupvolumn="提高音量";
static final String  action_setdownvolumn="降低音量";
static final String  action_setmute="静音";
static final String  action_changewind="切换风力";
static final String  action_changemode="切换模式";
static final String  action_changesite="更换位置";
//datatype name
static final String data_type_int16="int16";
static final String data_type_uint8="uint8";
static final String data_type_enum8="enum8";
static final String data_type_boolean="boolean";
static final String data_type_uint16="uint16";


//action frame
static final int frame_special=0x01;
static final int frame_special_norepose = 0x11;
static final int frame_general=0x00;
//attribute ID    
static final int Attribute_id0 = 0x0000;
static final int Attribute_id1 = 0x0001;
static final int Attribute_id2 = 0x0002;
static final int Attribute_id3 = 0x0003;
static final int Attribute_id4 = 0x0004;
static final int Attribute_id8 = 0x0008;


/**
 * general device type：具有某个属性处理功能的设备集合。 TI HomeAuto1.2协议中 deviceID
 * 的编号最大为0x0403，因此general 可以有如下的自定义
 */
static final int  Devtype_TemperatrueControl=0xFFFF;
static final int  Devtype_HumidityControl=0xFFFE;
static final int  Devtype_AirqualityControl=0xFFFD;
static final int  Devtype_LightIntensityControl=0xFFFC;

//light level    
static final int attribute_level0 = 0; // particularly bright
static final int attribute_level1 = 1;// normal,
static final int attribute_level2 = 2; // darker,but can see something
static final int attribute_level3 = 3;// particularly dark,Affect the visual
static final int attribute_level4 = 4;// particularly dark,Affect the visual

//for switch
static final int switch_open=0xFF;
static final int switch_close=0;


//for contorl device,DeviceID
// 因为目前这几个设备共用一个switch,才需要区分endPoint.之后设备分开或者有变动需要修改
static final int Devtype_Aircondition_id = 0x01;
static final int light_id=0x02;
static final int humidifier_id=0x04;
static final int Devtype_Dehumidifier_id=0x08;
static final int Devtype_Aircleaner_id=0x10;

private final static int colormode_warm = 0x01;
private final static int colormode_bright = 0x02;
private final static int colormode_cute = 0x03;
private final static int colormode_cool = 0x04;
private final static int colormode_sport = 0x05;
private final static int colormode_grace = 0x06;
private final static int colormode_calm = 0x07;
public static void main(String[] args) {
	String data = "{\"data_type\":\"simu_stt\",\"data\":{}}";
	  JSONObject js_top=JSONObject.fromObject(data);
	 String testHomeauto1 = "{\"devices_changed_v2\":[{\"id\":\"1A054903004B12000A00\",\"type_id\":0x0306,\"position\":\"客厅\",\"description1\":\"二氧化碳1\",\"attributes\":[{\"cluster_id\":0x0404,\"attribute_id\":0,\"attribute_value\":60000,\"attribute_status\":5}]},{\"id\":\"2A054903004B12000A00\",\"type_id\":0x0306,\"position\":\"客厅\",\"description1\":\"\",\"attributes\":[{\"cluster_id\":0x0404,\"attribute_id\":0,\"attribute_value\":40000,\"attribute_status\":5}]},{\"id\":\"1A054903004B12000500\",\"type_id\":0x0302,\"position\":\"客厅\",\"description1\":\"温度1\",\"attributes\":[{\"cluster_id\":0x0402,\"attribute_id\":0,\"attribute_value\":3000,\"attribute_status\": 5}]},{\"id\":\"1A054903004B12000200\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":6000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000300\",\"type_id\":0x0106,\"position\":\"客厅\",\"description1\":\"光强\",\"attributes\":[{\"cluster_id\":0x0400,\"attribute_id\":0,\"attribute_value\":151,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000400\",\"type_id\":0x0309,\"position\":\"客厅\",\"description1\":\"空气\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":12500,\"attribute_status\": 1}]},{\"id\":\"19192407004b12000D00\",\"type_id\":0x0503,\"position\":\"客厅\",\"description1\":\"电视\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5}]},{\"id\":\"19192407004b12000100\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"开关1\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\":5}]},{\"id\":\"f4286b07004b12000100\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"开关2\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12000B00\",\"type_id\":0x0501,\"position\":\"客厅\",\"description1\":\"加湿器\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5},{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\":5}]},{\"id\":\"1A054903004B12000F00\",\"type_id\":0x0300,\"position\":\"客厅\",\"description1\":\"空调\"},{\"id\":\"1A054903004B12001000\",\"type_id\":0x0300,\"position\":\"客厅\",\"description1\":\"空调\",\"attributes\":[{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":1,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":2,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0201,\"attribute_id\":0,\"attribute_value\":25,\"attribute_status\": 0x30}]},{\"id\":\"1A054903004B12000800\",\"type_id\":0x0500,\"position\":\"客厅\",\"description11\":\"净化器1\",\"attributes\":[{\"cluster_id\":0x0202,\"attribute_id\":0,\"attribute_value\":1,\"attribute_status\": 0x30},{\"cluster_id\":0x0202,\"attribute_id\":1,\"attribute_value\":0,\"attribute_status\": 0x30}]},{\"id\":\"1A054903004B12000900\",\"type_id\":0x0302,\"position\":\"客厅\",\"description1\":\"温度2\",\"attributes\":[{\"cluster_id\":0x0402,\"attribute_id\":0,\"attribute_value\":2600,\"attribute_status\": 5}]},{\"id\":\"1A054903004B12000700\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度2\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":3000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12001100\",\"type_id\":0x0308,\"position\":\"客厅\",\"description11\":\"湿度3\",\"attributes\":[{\"cluster_id\":0x0405,\"attribute_id\":0,\"attribute_value\":8000,\"attribute_status\": 1}]},{\"id\":\"1A054903004B12001300\",\"type_id\":0x0100,\"position\":\"客厅\",\"description1\":\"灯2\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5}]},{\"id\":\"1A054903004B12001300\",\"type_id\":0x0202,\"position\":\"客厅\",\"description\":\"窗帘1\",\"attributes\":[{\"cluster_id\":0x0102,\"attribute_id\":0x0008,\"attribute_value\":30,\"attribute_status\":0x20},{\"cluster_id\":0x0102,\"attribute_id\":0x0014,\"attribute_value\":0x0101,\"attribute_status\":0x21}]},{\"id\":\"1A054903004B12001400\",\"type_id\":0x0102,\"position\":\"客厅\",\"description1\":\"彩灯\",\"attributes\":[{\"cluster_id\":0x0006,\"attribute_id\":0,\"attribute_value\":0,\"attribute_status\":5},{\"cluster_id\":0x000a,\"attribute_id\":0x0003,\"attribute_value\":0xFF00FF,\"attribute_status\":5}]}],\"device_removed\":[\"9FF74803004B120003\",\"9FF74803004B120004\"]}";
      js_top.getJSONObject("data").put("home_automation",
           JSONObject.fromObject(testHomeauto1));
	JSONObject js_data = js_top.getJSONObject("data"); 
	JSONObject js_homeAuto_info=js_data.getJSONObject("home_automation");
	System.out.println(js_homeAuto_info);
	
}
}

class control_cmd{
    String device_id="";
    byte action_id=0;
}
class cmd_info{
    // device info
    private String name = ""; // 用户自定义的设备名称
    private String splitname = "";// 用户拆分之后的名称
    private int device_type = 0;
    private String deviceID = ""; // 设备的唯一编号
    // private String device_position = "";

    private String floor_num = ""; // 楼层编号
    private String floor_name = "";// 楼层命名

    private String original_floor_num = "";// 语义中指明的楼层编号
    private String original_floor_name = "";// 语义中指明的楼层名称

    private String position_num = "";
    private String position_name = "";

    private String original_position_num = "";// 语义中指明的位置编号
    private String original_position_name = "";// 语义中指明的位置名称

    private String slotname = "";// slot name
    // cmd info
    private cmd_typePrimary primaryCmd;// 一级命令
    private cmd_typeSecond secondCmd; // 二级命令
    private cmdTypeFlag cmdTypeFlag;
    private cmdNonsenseFlag cmdNonsenseFlag; // nonsense
                                             // 语句flag

    // last state
    private cmd_typePrimary lastPrimaryCmd; // 记录前一次对话的一级命令
    private cmd_typeSecond lastSecondCmd; // 记录前一次对话的二级命令
    private cmdTypeFlag lastCmdTypeFlag;
    // color lamp status
    private colourStatus adjustcolor = new colourStatus();

    private boolean iscurrentDevType = false;
    // 是否为more grammar
    private boolean ismoregrammar = false;
    private boolean isentrygrammar = false;

    public boolean isMoreGrammar() {
        return ismoregrammar;
    }

    public boolean isEntryGrammar() {
        return isentrygrammar;
    }

    public boolean isCurrentDevType() {
        return iscurrentDevType;
    }
    public void setAdjustcolor(colourStatus value) {
        adjustcolor=value;
    }

    public void setCurrentDevType(boolean flag) {
        // TODO Auto-generated method stub
        iscurrentDevType = flag;
    }

    public void setEntryGrammarFlag(boolean flag) {
        // TODO Auto-generated method stub
        isentrygrammar = flag;
    }

    public void setMoreGrammarFlag(boolean flag) {
        // TODO Auto-generated method stub
        ismoregrammar = flag;
    }
    public colourStatus getAdjustcolor() {
        return adjustcolor;
    }
    public String getDeviceName() {
        return name;
    }

    public int getDeviceType() {
        return device_type;
    }

    public String getDeviceID() {
        return deviceID;
    }

    // public String getDevicePosition() {
    // return position_name;
    // }
    public String getPositionName() {
        return position_name;
    }
    public String getsplitName() {
        return splitname;
    }
    public String getslotName() {
        return slotname;
    }

    public String getFloorNum() {
        return floor_num;
    }
    public cmd_typePrimary getprimaryCmd() {
        return primaryCmd;
    }

    public String getOriginalFloorNum() {
        return original_floor_num;
    }

    public String getFloorName() {
        return floor_name;
    }

    public String getOriginalFloorName() {
        return original_floor_name;
    }

    public String getPositionNum() {
        return position_num;
    }

    public String getOriginalPositionNum() {
        return this.original_position_num;
    }
    public cmd_typeSecond getsecondCmd() {
        return secondCmd;
    }
    public cmd_typePrimary getLastPrimaryCmd() {
        return lastPrimaryCmd;
    }

    public String getOriginalPositionName() {
        return original_position_name;
    }
    public cmd_typeSecond getLastSecondCmd() {
        return lastSecondCmd;
    }

    public cmdTypeFlag getCmdTypeFlag() {
        return cmdTypeFlag;
    }

    public cmdNonsenseFlag getNonsenseFlag() {
        return cmdNonsenseFlag;
    }
    public void setDeviceName(String name) {
        this.name = name;
    }


    public void setDeviceType(int value) {
        this.device_type = value;
    }

    public void setDeviceID(String value) {
        this.deviceID = value;
    }

    // public void setDevicePosition(String value) {
    // position_name = value;
    // }

    public void setSlotname(String value) {
        slotname = value;
    }

    public void setPrimaryCmd(cmd_typePrimary value) {
        primaryCmd = value;
    }

    public void setSecondCmd(cmd_typeSecond value) {
        secondCmd = value;
    }

    public void setCmdTypeFlag(cmdTypeFlag value) {
        cmdTypeFlag = value;
    }
    public void setLastPrimaryCmd(cmd_typePrimary value) {
        lastPrimaryCmd = value;
    }

    public void setLastSecondCmd(cmd_typeSecond value) {
        lastSecondCmd = value;
    }

    public void setLastCmdTypeFlad(cmdTypeFlag value) {
        lastCmdTypeFlag = value;
    }

    public void setsplitName(String name) {
        splitname = name;
    }

    public void setCmdNonsenseFlag(smarthome.definition.cmdNonsenseFlag value) {
        cmdNonsenseFlag = value;
    }

    public void setFloorNum(String value) {
        floor_num = value;
    }

    public void setOriginalFloorNum(String value) {
        original_floor_num = value;
    }

    public void setFloorName(String value) {
        floor_name = value;
    }

    public void setOriginalFloorName(String value) {
        original_floor_name = value;
    }

    public void setPositionNum(String value) {
        position_num = value;
    }

    public void setOriginalPositionNum(String value) {
        original_position_num = value;
    }

    public void setPositionName(String value) {
        position_name = value;
    }

    public void setOriginalPositionName(String value) {
        original_position_name = value;
    }
    public void Reset() {
        name = "";
        slotname = "";
        splitname = "";

        original_floor_name = "";
        original_floor_num = "";
        original_position_name = "";
        original_position_num = "";

        position_name = "";
        deviceID = "";

        ismoregrammar = false;
        isentrygrammar = false;
    }

    public void ResetLocationInfo() {

        position_name = "";
        position_num = "";
        floor_name = "";
        floor_num = "";
    }
    public void setDeviceInfo(HomeAutodeviceObjectNew device) {
        if (name == null || name.isEmpty())
            name = device.description;
        device_type = device.device_type;
        deviceID = device.device_ID;
        position_name = device.position;
    }

    public void ResetDeviceName() {

        name = "";
        splitname = "";
    }

}

class cmd_control_info {
    private cmd_typePrimary primaryCmd;// 一级命令
    private cmd_typeSecond secondCmd; // 二级命令

    public void setPrimaryCmd(cmd_typePrimary value) {
        primaryCmd = value;
    }

    public void setSecondCmd(cmd_typeSecond value) {
        secondCmd = value;
    }

    public cmd_typePrimary getPrimaryCmd() {
        return primaryCmd;
    }

    public cmd_typeSecond getSecondCmd() {
        return secondCmd;
    }
}


class sensor_param{
    int value=0;
    int level = 0xCC;// 参数对应的等级
}

/**
 * 彩灯属性描述
 *
 */
class colourStatus implements Cloneable {
    private String name = null; // 颜色名称
    private String aliasname = ""; // 名称的别名, 正则表达式
    private int rgbvalue = 0xC25208; // RGB颜色值
    private int onoffStatus;

    // 颜色的HSB值
    private double Hvalue;
    private double Svalue;
    private double Bvalue;

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public void SetName(String value) {
        name = value;
    }

    public void SetAlias(String value) {
        if (value == null)
            aliasname = "";
        if (value != null && !value.isEmpty()) {

            String[] aliasArray = value.split("[,，]");
            for (int i = 0; i < aliasArray.length; i++) {
                if (aliasArray[i].isEmpty())
                    continue;
                aliasname += aliasArray[i] + "|";
            }
            aliasname = aliasname.substring(0, aliasname.length() - 1);
        }
    }

    public void SetRGBvalue(int value) {
        rgbvalue = value;

    }

    public void SetHvalue(double value) {
        Hvalue = value;
    }

    public void SetSvalue(double value) {
        Svalue = value;
    }

    public void SetBvalue(double value) {
        Bvalue = value;
    }


    public void SetOnoffStatus(int value) {
        onoffStatus = value;
    }

    public String GetName() {
        return name;
    }

    public double GetHvalue() {
        return Hvalue;
    }

    public double GetSvalue() {
        return Svalue;
    }

    public double GetBvalue() {
        return Bvalue;
    }
    public boolean HasName(String value) {
        if (value == null || value.isEmpty())
            return false;
        boolean ret = false;
        if (value.equals(name))
            ret = true;
        return ret;
    }

    public String GetAliasname() {
        return aliasname;
    }

    public boolean HasAlias(String value) {
        boolean ret = false;
        if (aliasname.isEmpty() && value != null && !value.isEmpty())
            return ret;

        Pattern pattern = Pattern.compile(aliasname);
        Matcher matcher = pattern.matcher(value);

        if (matcher.matches())
            ret = true;

        return ret;

    }

    public int GetRGBvalue() {
        return rgbvalue;
    }


    public double GetOnOffStatus() {
        return onoffStatus;
    }
}

enum COLOR_TONE_TYPE {
    WARM, BRIGHT, CUTE, COOL, SPORT, GRACE, CALM
}

