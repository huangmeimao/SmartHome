package smarthome;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JPanel;

import javax.swing.border.BevelBorder;

import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import java.awt.Color;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;


import javax.swing.border.LineBorder;

public class window {

	private JFrame frame;
	
	
	private final JComboBox<String> box_device = new JComboBox();
	private final JComboBox<String> box_corpus = new JComboBox();

	private String input_corpus="";
	private boolean isRecording=false; 
	private boolean isred=false;
	
	private static final String[] light_corpus={"打开灯", "帮我开灯", "关灯", "把灯关上", "打开主灯","打开壁灯"};
	private static final String[] colorlight_corpus={"开一下彩灯","彩灯调成冷色调","彩灯调成暖色调","彩灯调成红色","把彩灯换个颜色","换换气氛","帮我关闭彩灯"};
	private static final String[] watchTV_corpus={"打开电视","电视的声音低点","把电视换到50台","我要看25台","帮我把电视切换到下个频道","把电视静音","电视的声音高一点","电视换到上个台"};
	private static final String[] aircondition_corpus={"打开空调","关空调","空调调成制冷模式","空调的温度高一点","空调的温度低一点","房间里太冷了","空调的风力调高一点","空调的风力调低一点","切换模式","切换风力","空调的温度是多少","空调的模式是什么","空调的风力怎么样"};
	private static final String[] curtain_corpus={"拉开窗帘","把窗帘拉开一半","暂停","把窗帘再拉开一些","把窗帘全部打开","把窗帘再关上一点","窗帘全部关闭","窗帘打开百分之三十"};
	private static final String[] door_corpus={"打开门","关门"};
	private static final String[] air_corpus={"屋里的空气怎么样","现在的空气质量是多少"};
	private static final String[] temper_corpus={"当前的温度是多少","屋里的温度高不高"};
	private static final String[] humidity_corpus={"播报当前的湿度","房间里的湿度高不高"};
	
	// Semantics handle
	private NLIProcess nliprocess=new NLIProcess();
	private JTextField voice_text = new JTextField();
	private JTextField color_text = new JTextField();
	private JTextArea answer_Text = new JTextArea();
	private JTextField tempe_text = new JTextField();
	private JTextField mode_text = new JTextField();
	private JTextField wind_text = new JTextField();
	private JTable 	cmd_table = new JTable();
	
	private windowVariable nliwindowdata=new windowVariable();
	
	
	private void GetAnswerForInputText(){
		if(box_corpus.getSelectedItem()!=null)
		    input_corpus = box_corpus.getSelectedItem().toString();

		nliprocess.setInputtype(0);
		nliprocess.setInputText(input_corpus);
		Thread t1 = new Thread(nliprocess);
		t1.start();
	
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window window = new window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public window() {
		initialize();
	}
	private void setDeviceCorpus() {
		// TODO Auto-generated method stub
		int index = box_device.getSelectedIndex();
		String[] tmpcorpus=null;
		switch(index){
		case 0:
			tmpcorpus=light_corpus;
			break;
		case 1:
			tmpcorpus=colorlight_corpus;
			break;
		case 2:
			tmpcorpus=watchTV_corpus;
			break;
		case 3:
			tmpcorpus=aircondition_corpus;
			break;
		case 4:
			tmpcorpus=curtain_corpus;
			break;
		case 5:
			tmpcorpus=door_corpus;
			break;
		case 6:
			tmpcorpus=air_corpus;
			break;
		case 7:
			tmpcorpus=temper_corpus;
			break;
		case 8:
			tmpcorpus=humidity_corpus;
			break;
		default:
			tmpcorpus=light_corpus;
			break;
		}
		box_corpus.removeAllItems();
		box_corpus.setModel(new DefaultComboBoxModel(tmpcorpus));
		input_corpus = tmpcorpus[0];
		GetAnswerForInputText();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		nliwindowdata.setCmdTable(cmd_table);
		nliwindowdata.setcolortext(color_text);
		nliwindowdata.setAnswerText(answer_Text);
		nliwindowdata.setModetext(mode_text);
		nliwindowdata.setTempetext(tempe_text);
		nliwindowdata.setVoicetext(voice_text);
		nliwindowdata.setWindtext(wind_text);
		nliwindowdata.setisRed(isred);
		nliprocess.SetAnswerConfigCom(nliwindowdata);
		
		
		
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 597, 679);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));
		input_corpus=light_corpus[0];
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		frame.getContentPane().add(panel_4);
		panel_4.setLayout(new GridLayout(0, 1, 0, 0));
		nliwindowdata.setAnswerText(answer_Text);
		nliwindowdata.setVoicetext(voice_text);
		
		JPanel panel_1 = new JPanel();
		panel_4.add(panel_1);
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setToolTipText("dsaggh ");
		panel_1.setForeground(new Color(0, 0, 0));
		panel_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 6, 572, 168);
		panel_2.setBorder(new TitledBorder(null, "\u5BF9\u8BDD\u8F93\u5165\uFF1A", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(148, 0, 211)));
		box_device.setMaximumRowCount(10);
		
		
		box_device.setFont(new Font("宋体", Font.PLAIN, 14));
		box_device.setBackground(new Color(255, 255, 255));
		
		box_device.setForeground(new Color(205, 92, 92));
		box_device.setModel(new DefaultComboBoxModel(new String[] {"灯", "彩灯", "电视", "空调", "窗帘", "门", "空气质量查询", "温度查询", "湿度查询"}));
		box_corpus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(arg0.getActionCommand().equals("comboBoxEdited")){
			//System.out.println("语料");
					GetAnswerForInputText();
		}
			}
		});
		
		box_corpus.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GetAnswerForInputText();
				}
			}
		});
		
	
		box_corpus.setFont(new Font("宋体", Font.PLAIN, 14));
		box_corpus.setForeground(new Color(0, 0, 255));
		box_corpus.setBackground(new Color(255, 255, 255));
		box_corpus.setEditable(true);
		box_corpus.setModel(new DefaultComboBoxModel(light_corpus));
		
		box_device.addItemListener(new ItemListener() {
			@SuppressWarnings("rawtypes")
			public void itemStateChanged(ItemEvent arg0) {
				if (arg0.getStateChange() == ItemEvent.SELECTED) {
					setDeviceCorpus();
					
				}
			}

			
		});
		final JLabel label_speech = new JLabel("语音输入:");
		label_speech.setFont(new Font("宋体", Font.BOLD, 14));
		label_speech.setForeground(new Color(0, 100, 0));
		
				
				final JButton button_1 = new JButton("开始录音");
				button_1.setForeground(new Color(0, 0, 0));
				button_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {

						if(isRecording){
							System.out.println("正在录音");
							
						}else{
						
							isRecording=true;
							//String answer=nliprocess.getSemanticBySpeech();
							nliprocess.setInputtype(1);
							Thread t1 = new Thread(nliprocess);
							t1.start();
							//answer_Text.setText(answer);
							isRecording=false;
						}
											
					
					}
				});
				//		button_1.addMouseListener(new MouseAdapter() {
				//			@Override
				//			public void mouseClicked(MouseEvent arg0) {
				//				if(isRecording){
				//					System.out.println("正在录音");
				//					
				//				}else{
				//				
				//					try {
				//						isRecording=true;
				//						String answer=nliprocess.getSemanticBySpeech();
				//						answer_Text.setText(answer);
				//						isRecording=false;
				//	
				//					} catch (IOException e) {
				//						// TODO Auto-generated catch block
				//						e.printStackTrace();
				//					}
				//				}
				//									
				//			}
				//		});
						button_1.setBackground(new Color(240, 240, 240));
						
						JLabel label = new JLabel("文字输入：");
						label.setFont(new Font("宋体", Font.BOLD, 14));
						label.setForeground(new Color(46, 139, 87));
						
						JButton button_2 = new JButton("停止录音");
						button_2.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								nliprocess.StopRecording();
							}
						});
						
						
						voice_text.setEditable(false);
						voice_text.setColumns(10);
						
						
						GroupLayout gl_panel_2 = new GroupLayout(panel_2);
						gl_panel_2.setHorizontalGroup(
							gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addGap(16)
									.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
										.addComponent(label)
										.addComponent(label_speech))
									.addGap(18)
									.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel_2.createSequentialGroup()
											.addGap(10)
											.addComponent(button_1)
											.addGap(37)
											.addComponent(button_2)
											.addContainerGap())
										.addGroup(gl_panel_2.createSequentialGroup()
											.addComponent(box_device, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(box_corpus, 0, 358, Short.MAX_VALUE))
										.addGroup(gl_panel_2.createSequentialGroup()
											.addComponent(voice_text, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE)
											.addContainerGap())))
						);
						gl_panel_2.setVerticalGroup(
							gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addContainerGap()
									.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
										.addComponent(box_device, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
										.addComponent(label)
										.addComponent(box_corpus, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
									.addGap(28)
									.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel_2.createSequentialGroup()
											.addComponent(voice_text, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
												.addComponent(button_2, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
												.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)))
										.addComponent(label_speech))
									.addContainerGap())
						);
						panel_2.setLayout(gl_panel_2);
						
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 184, 572, 62);
		panel_3.setBorder(new TitledBorder(null, "\u7B54\u6848\u8F93\u51FA\uFF1A", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(148, 0, 211)));
		panel_3.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		answer_Text.setFont(new Font("宋体", Font.PLAIN, 14));
		answer_Text.setRows(5);
		answer_Text.setForeground(new Color(0, 0, 0));
		answer_Text.setEditable(false);
		panel_3.add(answer_Text);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(0, 256, 572, 52);
		panel_5.setBorder(new TitledBorder(null, "\u8BBE\u5907\u6A21\u62DF:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(148, 0, 211)));
		panel_5.setLayout(null);
		
		JLabel label_1 = new JLabel("彩灯:");
		label_1.setBounds(29, 25, 36, 15);
		panel_5.add(label_1);
		label_1.setForeground(new Color(0, 100, 0));
		nliwindowdata.setcolortext(color_text);
		color_text.setBounds(75, 22, 36, 21);
		color_text.setEditable(false);
		panel_5.add(color_text);
		
		
		color_text.setBackground(Color.DARK_GRAY);
		color_text.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("空调：");
		lblNewLabel.setBounds(139, 25, 36, 15);
		panel_5.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(0, 100, 0));
		
		JLabel lblNewLabel_1 = new JLabel("温度");
		lblNewLabel_1.setBounds(192, 25, 24, 15);
		panel_5.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("宋体", Font.PLAIN, 12));
		nliwindowdata.setTempetext(tempe_text);
		tempe_text.setBounds(226, 22, 29, 21);
		panel_5.add(tempe_text);
		
		
		tempe_text.setText("25");
		tempe_text.setColumns(10);
		
		JLabel label_2 = new JLabel("模式");
		label_2.setBounds(279, 25, 24, 15);
		panel_5.add(label_2);
		label_2.setFont(new Font("宋体", Font.PLAIN, 12));
		nliwindowdata.setModetext(mode_text);
		mode_text.setBounds(313, 22, 41, 21);
		panel_5.add(mode_text);
		
		mode_text.setText("制冷");
		mode_text.setColumns(10);
		
		JLabel label_3 = new JLabel("风力");
		label_3.setBounds(379, 25, 24, 15);
		panel_5.add(label_3);
		label_3.setFont(new Font("宋体", Font.PLAIN, 12));
		nliwindowdata.setWindtext(wind_text);
		wind_text.setBounds(413, 22, 36, 21);
		panel_5.add(wind_text);
		
		wind_text.setText("自动");
		wind_text.setColumns(10);
		panel_1.setLayout(null);
		panel_1.add(panel_2);
		panel_1.add(panel_3);
		panel_1.add(panel_5);
		
		JPanel panel = new JPanel();
		panel_4.add(panel);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u547D\u4EE4\u8F93\u51FA\uFF1A", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(148, 0, 211)));
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		

		cmd_table.setToolTipText("");
		cmd_table.setBorder(new LineBorder(new Color(255, 240, 245)));
		cmd_table.setFont(new Font("宋体", Font.PLAIN, 14));
		cmd_table.setRowSelectionAllowed(false);
		cmd_table.setRowHeight(26);
	
		cmd_table.setModel(new DefaultTableModel(
			new Object[][] {
				{"\u540D\u79F0", "\u503C", "\u542B\u4E49"},
				{"Device ID ", null, null},
				{"Device Type", null, null},
				{"Cluster ID", null, null},
				{"Action ID", null, null},
				{"", null, null},
				{"Attribute1 Type", null, null},
				{"Attribute1 Value", null, null},
				{"", null, null},
				{"Attribute2 Type", null, null},
				{"Attribute2 Value", null, null},
			},
			new String[] {
				"device ID", "New column", "New column"
			}
		));
		cmd_table.getColumnModel().getColumn(1).setPreferredWidth(122);
		cmd_table.getColumnModel().getColumn(2).setPreferredWidth(131);
		panel.add(cmd_table);
	}
}

enum speech_type{
  defaultvalue,
  recording,
  end
	
}
