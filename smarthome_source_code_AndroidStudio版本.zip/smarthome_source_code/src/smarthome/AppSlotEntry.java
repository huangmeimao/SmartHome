package smarthome;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import ai.olami.nli.slot.DateTime;
import ai.olami.nli.slot.NumDetail;
import ai.olami.nli.slot.Slot;

public class AppSlotEntry extends Slot{
	 boolean bUpdated;
	 boolean bValidated;
	 boolean bValid;
	 private String mName = null;
	 private String mValue = null;
	 private String[] mModifiers = null;
	 private DateTime mDateTime = null;
	 private NumDetail mNumDetail = null;
	 
	 List<String> mods = new LinkedList<String>();
 public AppSlotEntry(Slot slot){
	 if(slot.getModifiers()!=null)
	     mods= Arrays.asList(slot.getModifiers());
	 mName=slot.getName();
	 mValue=slot.getValue();
	 mModifiers=slot.getModifiers();
	 mDateTime=slot.getDateTime();
	 mNumDetail=slot.getNumDetail();
	 
 }
 
 public boolean isbValidated() {
	 
     return bValidated;
 }
 public void setbValidated(boolean bValidated) {
     this.bValidated = bValidated;
 }
 public void setbValid(boolean bValid) {
     this.bValid = bValid;
 }
 public boolean isbValid() {
     return bValid;
 }
 public boolean isbUpdated() {
     return bUpdated;
 }
 
 public void setbUpdated(boolean bUpdated) {
     this.bUpdated = bUpdated;
 }
 public String getName() {
		return mName;
	}
 public boolean hasName() {
		return (mName != null);
	}
 public String getValue() {
		return mValue;
	}
 public String[] getModifiers() {
		return mModifiers;
	}
 public DateTime getDateTime() {
		return mDateTime;
	}
 public NumDetail getNumDetail() {
		return mNumDetail;
	}
 public boolean hasNumDetail() {
		return (mNumDetail != null);
	}
}
