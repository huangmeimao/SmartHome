package smarthome.definition;

public class HomeAutoAttributeObject implements Cloneable {
    private int  cluster_id=0;
    private int  attribute_id=0;
    private int  attribute_value=0;
    private int  attribute_status=0;
    private int attribute_level = 0xCC;// 属性等级，笔记空气质量的污染程度
    private boolean isUpdated = false; // 是否是最新的数据
 
    public boolean isUpdated() {
        return isUpdated;
    }
    public int GetAttributeID(){
        return attribute_id;
    }
    public int GetAttributeValue(){
        return attribute_value;
    }
    public int GetAtrributeStatus()
    {
        return attribute_status;
    }
    public int GetClusterID(){
        return cluster_id;
    }

    public int GetAttributelevel() {
        return attribute_level;
    }

    public void SetUpdatedStatus(boolean status) {
        isUpdated = status;
    }
    public void SetClusterID(int value)
    {
        cluster_id=value;
    }
    public void SetAttributeID(int value){
        attribute_id=value;
    }
    public void SetAttributeValue(int value){
        attribute_value=value;
    }
    public void SetAttributeStatus(int value){
        attribute_status=value;
    }

    public void SetAttributeLevel(int value) {
        attribute_level = value;
    }

    @Override
    public HomeAutoAttributeObject clone() {
        HomeAutoAttributeObject clone = null;

        try {
            clone = (HomeAutoAttributeObject) super.clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return clone;

    }

}
