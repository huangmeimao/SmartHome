package smarthome.definition;

public enum cmd_typeSecond {
    cmd_default, cmd_weaklevel, cmd_mediumlevel, cmd_stronglevel, cmd_timerlevel1, cmd_timerlevel2, cmd_timerlevel3, cmd_setup, cmd_setdown, cmd_cancel, cmd_enable, cmd_continue, cmd_degree, cmd_setleft, cmd_setright, cmd_automod, cmd_hotmod, cmd_sweepmod, cmd_dehumidifymod, cmd_coldmod, cmd_coolmod, cmd_normalmod, cmd_airsupplymod, cmd_setnext, cmd_setlast, cmd_attrtemperature, cmd_attrhumidity, cmd_attrairquality, cmd_attrlightintensity, cmd_attrmode, cmd_attrwindpower, cmd_attrwinddirection, cmd_attronoffstatus, cmd_attrco2, cmd_mutemod, cmd_restmod, cmd_change, cmd_romantic, cmd_soft, cmd_mystery
}
