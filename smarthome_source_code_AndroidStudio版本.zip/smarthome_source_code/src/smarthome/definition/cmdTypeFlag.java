package smarthome.definition;

public enum cmdTypeFlag {
    cmdtype_default, cmdtype_all
}
