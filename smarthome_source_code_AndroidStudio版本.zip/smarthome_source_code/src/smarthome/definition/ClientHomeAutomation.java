package smarthome.definition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



public class ClientHomeAutomation {

    List<String> removedDeviceList = Collections.synchronizedList(new ArrayList<String>());
    
    //key is deviceID
    Map<String,HomeAutodeviceObjectNew> addedDeviceMapNew=new ConcurrentHashMap<String,HomeAutodeviceObjectNew>();
    // key is device_type,记录用户自定义阀值
    Map<Integer, HomeAutoThresholdObject> customerThresholdMap = new HashMap<Integer, HomeAutoThresholdObject>();

    // showroom:保存不同类型的设备个数,用于showroom设备命名; key is devtype
    Map<Integer, Integer> deviceNumForTypeMap = new HashMap<Integer, Integer>();
    
    private void parsedeviceStatusChange(JSONArray js_devchanged) {

        // JSONArray js_devchanged = info.getJSONArray("devices_changed_v2");
        for (int i = 0; i < js_devchanged.size(); i++) {
            JSONObject temp = js_devchanged.getJSONObject(i);
            String deviceid = temp.getString("id");
            if (deviceid == null || deviceid.isEmpty())
                continue;
            // 在已经存在的设备列表里查询该设备是否存在
            if (addedDeviceMapNew.containsKey(deviceid) && !removedDeviceList.contains(deviceid)) {
                // device is added,detect the status whether change

                // if the removedDeviceList has it, ignore the info.but this
                // should not happen
                if (removedDeviceList.contains(deviceid))
                    continue;
                try {
                    HomeAutodeviceObjectNew device = addedDeviceMapNew.get(deviceid);
                    // 设备类型
                    if (temp.containsKey("type_id"))
                        device.device_type = temp.getInt("type_id");
                    if (temp.containsKey("position"))
                        device.position = temp.getString("position");
                    // 每个设备都必须有名称，优先使用客户端传过来的名称。如果客户端没有设置名称，则使用默认命名。以便测试。

                    if (temp.containsKey("description"))
                        device.description = temp.getString("description");
                    else {
                        SetDevDescription(device);
                    }

                    if (temp.containsKey("attributes")) {
                        JSONArray attrArray = temp.getJSONArray("attributes");
                        if (attrArray == null || attrArray.isEmpty())
                            continue;

                        for (int num = 0; num < attrArray.size(); num++) {
                            JSONObject attrObj = attrArray.getJSONObject(num);
                            if (!attrObj.containsKey("cluster_id")
                                    || !attrObj.containsKey("attribute_id"))
                                continue;
                            // 情况窗帘上次的命令状态
                            if (device.device_type == HomeAutoProtocol.Devtype_WindowCovering)
                                device.controlstatus.ResetLastPrimaryCMD();

                            HomeAutoAttributeObject tempAttr = device.ishaveAttribute(
                                    attrObj.getInt("cluster_id"), attrObj.getInt("attribute_id"));

                            if (tempAttr == null) {
                                HomeAutoAttributeObject tp = new HomeAutoAttributeObject();
                                tp.SetClusterID(attrObj.getInt("cluster_id"));
                                tp.SetAttributeID(attrObj.getInt("attribute_id"));
                                if (attrObj.containsKey("attribute_value")) {
                                    // tp.SetAttributeValue(attrObj.getInt("attribute_value"));
                                    tp.SetAttributeValue(PreHandleAttributeValue(device.device_type,
                                            attrObj.getInt("cluster_id"),
                                            attrObj.getInt("attribute_id"),
                                            attrObj.getInt("attribute_value")));
                                    tp.SetUpdatedStatus(true);
                                }
                                if (attrObj.containsKey("attribute_status"))
                                    tp.SetAttributeStatus(attrObj.getInt("attribute_status"));

                                device.AddAttribute(tp);
                            } else
                            // 如果属性列表中已包含该属性
                            {
                                if (attrObj.containsKey("attribute_value")) {
                                    // tempAttr.SetAttributeValue(attrObj.getInt("attribute_value"));
                                    tempAttr.SetAttributeValue(PreHandleAttributeValue(
                                            device.device_type, attrObj.getInt("cluster_id"),
                                            attrObj.getInt("attribute_id"),
                                            attrObj.getInt("attribute_value")));
                                    tempAttr.SetUpdatedStatus(true);
                                }
                                if (attrObj.containsKey("attribute_status"))
                                    tempAttr.SetAttributeStatus(attrObj.getInt("attribute_status"));
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (!removedDeviceList.contains(deviceid)) {// new device
                // if it has been removed before, delete it from the removeList
                if (removedDeviceList != null && removedDeviceList.contains(deviceid))
                    removedDeviceList.remove(deviceid);
                HomeAutodeviceObjectNew device = new HomeAutodeviceObjectNew();
                device.device_ID = deviceid;

                if (temp.containsKey("type_id"))
                    device.device_type = temp.getInt("type_id");
                if (temp.containsKey("position"))
                    device.position = temp.getString("position");
                if (temp.containsKey("description"))
                    device.description = temp.getString("description");
                else
                    SetDevDescription(device);

                if (temp.containsKey("attributes")) {
                    try {
                        JSONArray attrArray = temp.getJSONArray("attributes");
                        for (int num = 0; num < attrArray.size(); num++) {
                            JSONObject attrfrom = attrArray.getJSONObject(num);
                            if (!attrfrom.containsKey("attribute_id")
                                    || !attrfrom.containsKey("cluster_id"))
                                continue;
                            if (device.device_type == HomeAutoProtocol.Devtype_WindowCovering)
                                device.controlstatus.ResetLastPrimaryCMD();

                            HomeAutoAttributeObject attr = new HomeAutoAttributeObject();

                            attr.SetAttributeID(attrfrom.getInt("attribute_id"));
                            attr.SetClusterID(attrfrom.getInt("cluster_id"));
                            if (attrfrom.containsKey("attribute_value")) {
                                // attr.SetAttributeValue(attrfrom.getInt("attribute_value"));
                                attr.SetAttributeValue(PreHandleAttributeValue(device.device_type,
                                        attrfrom.getInt("cluster_id"),
                                        attrfrom.getInt("attribute_id"),
                                        attrfrom.getInt("attribute_value")));
                                attr.SetUpdatedStatus(true);
                            }
                            if (attrfrom.containsKey("attribute_status"))
                                attr.SetAttributeStatus(attrfrom.getInt("attribute_status"));
                            device.AddAttribute(attr);

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

                addedDeviceMapNew.put(deviceid, device);
            }

        }
        // 获取彩灯设备，如果颜色是最新值，且不是黑色，则更新器onoff状态为打开
        // HomeAutodeviceObjectNew[] colorlights =
        // GetDeviceObjByDevType(HomeAutoProtocol.Devtype_Illuminations);
        // for(int i=0;i<colorlights.length;i++){
        // HomeAutodeviceObjectNew devobj = colorlights[i];
        // if (devobj.isUpdateTheAttributeValue(0x000A, 3)
        // && devobj.GetArributeValue(0x0006, 0) == 0) {
        // HomeAutoAttributeObject attr = devobj.ishaveAttribute(0x0006, 0);
        // attr.SetAttributeValue(1);
        // }
        //
        // }
        
        
    }

    private void addCustomDevices() {
        // 添加摄像头
        if (!addedDeviceMapNew.containsKey("3300AA00AA00AA00F100")) {
            HomeAutodeviceObjectNew device = new HomeAutodeviceObjectNew();
            device.device_ID = "3300AA00AA00AA00F100";
            device.description = "室内摄像头";
            device.device_type = 0x0502;
            device.position = "";
            addedDeviceMapNew.put(device.device_ID, device);
        }
        if (!addedDeviceMapNew.containsKey("3300AA00AA00AA00F200")) {
            HomeAutodeviceObjectNew device = new HomeAutodeviceObjectNew();
            device.device_ID = "3300AA00AA00AA00F200";
            device.description = "室外摄像头";
            device.device_type = 0x0502;
            device.position = "";
            addedDeviceMapNew.put(device.device_ID, device);
        }
        // if (!addedDeviceMapNew.containsKey("3300AA00AA00AA00F300")) {
        // HomeAutodeviceObjectNew device = new HomeAutodeviceObjectNew();
        // device.device_ID = "3300AA00AA00AA00F300";
        // device.description = "空调";
        // device.device_type = 0x0300;
        // device.position = "";
        // addedDeviceMapNew.put(device.device_ID, device);
        // }
    }

    /**
     * 解析stt中home_automation中的devices_changed_v2和device_removed，即使用homeAuto1.2
     * 协议.
     * 
     * @param stt中的home_automation
     * @return
     */
    public boolean ParseClientAppInfoNew(JSONObject info){
        if(info==null){
            return false; 
        }
        if(info.containsKey("device_removed")){
            JSONArray removeList = info.getJSONArray("device_removed");
            for (int i = 0; i < removeList.size(); i++ ){
                String tempID = removeList.getString(i);
                if(removedDeviceList!=null&&!removedDeviceList.contains(tempID)){// has the removed device's info
                    removedDeviceList.add(tempID);   
                    //remove it from the addedDeviceMap
                    if(addedDeviceMapNew.containsKey(tempID)){
                        ResetDevDescription(tempID);
                        addedDeviceMapNew.remove(tempID);
                    }
                        
                }               
            }           
        }

        if (info.containsKey("device_refresh")) {
            removedDeviceList.clear();
            addedDeviceMapNew.clear();
            JSONArray js_devchanged = info.getJSONArray("device_refresh");
            if (!js_devchanged.isEmpty())
                parsedeviceStatusChange(js_devchanged);
        }
        if (info.containsKey("devices_changed_v2")) {
            JSONArray js_devchanged = info.getJSONArray("devices_changed_v2");
            if (!js_devchanged.isEmpty())
                parsedeviceStatusChange(js_devchanged);
        }
        removedDeviceList.clear();
        addCustomDevices();
        return true;
        

    }

    public void cleardevicelist() {
        addedDeviceMapNew.clear();
        removedDeviceList.clear();
    }
    
    /***
     * 将需要去掉的设备名之后的名称重新设置，即按照顺序去掉这个尾标
     * 
     * @param tempID
     */
    private void ResetDevDescription(String devID) {
        // TODO Auto-generated method stub
        HomeAutodeviceObjectNew removedevice = addedDeviceMapNew.get(devID);
        if (removedevice == null)
            return;

        if (removedevice.description == null || removedevice.description.isEmpty())
            return;
        if (removedevice.GetPredefinedname() == 0)
            return;

        int index = removedevice.GetPredefinedname();// 获取设备名称的编号
        HomeAutodeviceObjectNew[] resetlist = GetDeviceObjByDevType(removedevice.device_type);
        
        for (int i = 0; i < resetlist.length; i++) {
            HomeAutodeviceObjectNew tempobj = resetlist[i];
                int tempindex = tempobj.GetPredefinedname();
            int newtail = tempindex - 1;
            if (tempindex > index && tempobj.description.contains(Integer.toString(tempindex))) {

                if (newtail == 1) {
                    tempobj.description = tempobj.description.substring(0,
                            tempobj.description.length() - Integer.toString(tempindex).length());
                } else
                    tempobj.description = tempobj.description.substring(0,
                            tempobj.description.length() - Integer.toString(tempindex).length())
                            + Integer.toString(newtail);
                tempobj.SetPredefinedname(newtail);
            }
        }
        deviceNumForTypeMap.put(removedevice.device_type,
                deviceNumForTypeMap.get(removedevice.device_type) - 1);
    }

    private void SetDevDescription(HomeAutodeviceObjectNew device) {

        String oriName = device.description;
        if (oriName != null && !oriName.isEmpty()) {
            if (device.GetPredefinedname() > 0)
                return;
        }

        if (deviceNumForTypeMap.containsKey(device.device_type)) {

        } else {
            deviceNumForTypeMap.put(device.device_type, 1);
        }
        Integer DeviceNum = deviceNumForTypeMap.get(device.device_type);
        // 第一个设备不标数字
        String sdevNum = "";
        if (DeviceNum != 1)
            sdevNum = Integer.toString(DeviceNum);

        switch (device.device_type) {
        case HomeAutoProtocol.Devtype_Aircleaner:
            device.description = "净化器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_Light:
            device.description = "灯" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_Humidifier:
            device.description = "加湿器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_Dehumidifier:
            device.description = "除湿器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_Aircondition:
            device.description = "空调" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_TemperatureSensor:
            device.description = "温度计" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_AQISensor:
            device.description = "空气质量传感器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_HumiditySensor:
            device.description = "湿度传感器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_LightIntenSensor:
            device.description = "光线传感器" + sdevNum;
            break;
        case HomeAutoProtocol.Devtype_WindowCovering:
            device.description = "窗帘" + sdevNum;
            break;
        }
        deviceNumForTypeMap.put(device.device_type, DeviceNum + 1);
        device.SetPredefinedname(DeviceNum);

        // for demo room
        if (device.device_ID.equals("19192407004b12000100"))
            device.description = "主灯";
        else if (device.device_ID.equals("f4286b07004b12000100"))
            device.description = "壁灯";

    }


    /**
     * 根据协议预处理传感器的值
     * 
     * @param deviceType
     * @param clusterID
     * @param AttrID
     * @return
     */
    private int PreHandleAttributeValue(int deviceType, int clusterID, int AttrID, int originalValue) {
        int value = 0;
        switch (deviceType) {
        case 0x0309: // 空气净化器
            if (clusterID == 0x0405 && AttrID == 0)
                value = originalValue / 100;
            break;
        case 0x0308:// 湿度传感器
            if (clusterID == 0x0405 && AttrID == 0)
                value = originalValue / 100;
            break;
        case 0x0302:// 温度传感器
            if (clusterID == 0x0402 && AttrID == 0)
                value = originalValue / 100;
            break;
        case 0x0106:// 光强传感器
            // if (clusterID == 0x0400 && AttrID == 0)
            value = originalValue;
            break;
        case 0x0306:// 二氧化碳传感器
            if (clusterID == 0x0404 && AttrID == 0)
                value = originalValue / 100;
            break;
        default:
            value = originalValue;
            break;
        }
        return value;
    }


    public Map<String,HomeAutodeviceObjectNew> GetExitingDevicesNew(){
        return addedDeviceMapNew;
    }

    public HomeAutodeviceObjectNew GetDeviceObjByDeviceID(String deviceID) {
        return addedDeviceMapNew.get(deviceID);
    }

    /**
     * 
     * @param devType
     *            ,设备的类型
     * @param clusterID
     * @param AttributeID
     * @return,按照clusterID和AttributeID指定的属性值进行排序的结果
     */
    public HomeAutodeviceObjectNew[] GetDeviceObjByDevType(int devType, int clusterID,
            int AttributeID) {
        // List<HomeAutodeviceObjectNew> result = new
        // ArrayList<HomeAutodeviceObjectNew>();

        Set<HomeAutodeviceObjectNew> resultSet = new TreeSet<HomeAutodeviceObjectNew>(
                new AttributeValueComparator1());

        Iterator<Entry<String, HomeAutodeviceObjectNew>> devlist = addedDeviceMapNew.entrySet()
                .iterator();
        while (devlist.hasNext()) {
            Entry<String, HomeAutodeviceObjectNew> entry = devlist.next();
            HomeAutodeviceObjectNew device = entry.getValue();
            if (device.device_type == devType) {
                device.SetSortclusterID(clusterID);
                device.SetSortAttrID(AttributeID);
                resultSet.add(device);
            }
        }

        return resultSet.toArray(new HomeAutodeviceObjectNew[resultSet.size()]);
    }

    public HomeAutodeviceObjectNew[] GetDeviceObjByDevType(int devType) {
        // List<HomeAutodeviceObjectNew> result = new
        // ArrayList<HomeAutodeviceObjectNew>();

        Set<HomeAutodeviceObjectNew> resultSet = new TreeSet<HomeAutodeviceObjectNew>(
                new AttributeValueComparator1());

        Iterator<Entry<String, HomeAutodeviceObjectNew>> devlist = addedDeviceMapNew.entrySet()
                .iterator();
        while (devlist.hasNext()) {
            Entry<String, HomeAutodeviceObjectNew> entry = devlist.next();
            HomeAutodeviceObjectNew device = entry.getValue();
            if (device.device_type == devType) {
                resultSet.add(device);
            }
        }
        return resultSet.toArray(new HomeAutodeviceObjectNew[resultSet.size()]);
    }
    public Map<Integer, HomeAutoThresholdObject> GetcustomerThresholds() {
        return customerThresholdMap;
    }
    public class ThresholdValue {
        public int maxValue = 0;
        public int minValue = 0;
        
        public ThresholdValue(int maxValue, int minValue) {
            this.maxValue = maxValue;
            this.minValue = minValue;
        }
    }
    
    private HashMap<String, ThresholdValue> thresholdValues = new HashMap<String, ThresholdValue>();
    
    public ThresholdValue updateThreshold(String key, int max, int min) {
        ThresholdValue newValue = new ThresholdValue(max, min);
        return thresholdValues.put(key, newValue);
    }
    
    public ThresholdValue getThreshold(String key) {
        return thresholdValues.get(key);
    }
    
//    public boolean initThresholds(JSONObject obj) {
//        for (Object keyobj : obj.keySet()) {
//            String key = keyobj.toString();
//            ThresholdValue value = new ThresholdValue(obj.getJSONObject(key).("max"), obj.getJSONObject(key).optInt("min"));
//            thresholdValues.put(key, value);
//        }
//        return true;
//    }
//    
    /**
     * @return a JSONObject like 
     * {"key1" : {"max" : maxValue, "min" : minValue}, "key2" : {"max" : maxValue, "min" : minValue}}
     * or null
     */
    public JSONObject thresholdsToJSON() {
        JSONObject ret = new JSONObject();
        for (Entry<String, ThresholdValue> entry : thresholdValues.entrySet()) {
            JSONObject value = new JSONObject();
            value.put("max", entry.getValue().maxValue);
            value.put("min", entry.getValue().minValue);
            ret.put(entry.getKey(), value);
        }
        if (ret.isEmpty()) {
            return null;
        }
        else {
            return ret;
        }
    }

    public static void main(String[] args) {
        String name = "电视12";
        String tail = "12";
        String a = name.substring(name.length() - tail.length());
        if (a.matches("^[0-9]+$")) {
            System.out.println(a);
        }
    }

}
class AttributeValueComparator1 implements Comparator<HomeAutodeviceObjectNew> {

    @Override
    // 按照String长度从大到小排列
    public int compare(HomeAutodeviceObjectNew arg0, HomeAutodeviceObjectNew arg1) {

        int ret = 0;
        if ((arg0.GetArributeValue(arg0.GetSortClusterID(), arg0.GetSortAttrID()) - arg1
                .GetArributeValue(arg1.GetSortClusterID(), arg1.GetSortAttrID())) >= 0)
            ret = 1;
        else
            ret = -1;
        
        return ret;
            
    }
}


