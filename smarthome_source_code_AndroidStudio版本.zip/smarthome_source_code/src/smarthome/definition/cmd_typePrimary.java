package smarthome.definition;

public enum cmd_typePrimary {
    cmd_default, cmd_open, cmd_close, cmd_stop, cmd_query, cmd_identify, cmd_setwindpower, cmd_settemperature, cmd_settiming, cmd_setairquality, cmd_sethumidity, cmd_up, cmd_down, cmd_windup, cmd_winddown, cmd_setcolor, cmd_setwarm, cmd_setbright, cmd_setcute, cmd_setcool, cmd_setsport, cmd_setgrace, cmd_setcalm, cmd_satuup, cmd_satudown, cmd_lightup, cmd_lightdown, cmd_warmer, cmd_brighter, cmd_cuter, cmd_cooler, cmd_sporter, cmd_altercolor, cmd_calmer, cmd_gracer, cmd_altertone, cmd_setwinddirection, cmd_setmod, cmd_setlightintensity, cmd_setatmosphere, cmd_deviceamount, cmd_setlevel, cmd_extralfun1, cmd_changechannel, cmd_setvolume, cmd_getback, cmd_confirm
}