package smarthome.definition;

/**
 * 用于记录用户定义的阀值信息，暂时按照设备类型仅设置一个阀值信息 如果以后UX有定义，需要重新修改
 * 
 * @author
 * 
 */
public class HomeAutoThresholdObject {
    private int customer_max_value = 0; // 客户自定义阀值最大值
    private int customer_min_value = 0; // 客户自定义阀值最小值

    public int GetCustomerMaxValue() {
        return customer_max_value;
    }

    public int GetCustomerMinValue() {
        return customer_min_value;
    }

    public void SetCustomerMaxValue(int value) {
        customer_max_value = value;
    }

    public void SetCustomerMinValue(int value) {
        customer_min_value = value;
    }
}
