package smarthome.definition;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 
 * 协议中参数的定义
 * 
 */
public class HomeAutoProtocol {
    /**
     * device type definition
     */

    public static final int Devtype_Unknow = 0;
    /////////// 传感类设备
    // AQI sensor
    public static final int Devtype_AQISensor = 0x0309;
    // humidity sensor
    public static final int Devtype_HumiditySensor = 0x0308;
    // light intensity sensor=0x0006;
    public static final int Devtype_LightIntenSensor = 0x0106;
    // temperature sensor
    public static final int Devtype_TemperatureSensor = 0x0302;
    // co2 sensor
    public static final int Devtype_Co2Sensor = 0x0306;
    // humidifier
    public static final int Devtype_Humidifier = 0x0501;

    //////////////// 控制类设备
    // 彩灯
    public static final int Devtype_Illuminations = 0x0102;
    // light,only support on/off
    public static final int Devtype_Light = 0x0100;
    public static final int Devtype_CeilingLight = 0x0100D1; // 吸顶灯
    public static final int Devtype_WallLight = 0x0100D2; // 壁灯
    // 除湿器
    public static final int Devtype_Dehumidifier = 0x03;
    // 空气净化器
    public static final int Devtype_Aircleaner = 0x0500;

    // air condition,using remote control
    public static final int Devtype_Aircondition = 0x0300;
    // 窗帘
    public static final int Devtype_WindowCovering = 0x0202;

    // 摄像头
    public static final int Devtype_Camera = 0x0502;
    public static final int Devtype_Television = 0x0503;
    // 门
    public static final int Devtype_Door = 0x0504;
    // 投影仪
    public static final int Devtype_Projector = 0x0505;
    // 投影布
    public static final int Devtype_Projectorbackdrop = 0x0506;

    // location

    public static final String DevLocationType_livingroom = "R0001"; // 客厅
    public static final String DevLocationType_bedroom = "R0002";// 卧室
    public static final String DevLocationType_diningroom = "R0003";// 饭厅
    public static final String DevLocationType_kitchen = "R0004";// 厨房
    public static final String DevLocationType_toilet = "R0005";// 卫生间
    public static final String DevLocationType_yangtai = "R0006";// 阳台
    public static final String DevLocationType_yard = "R0007";// 院子
    public static final String DevLocationType_carport = "R0008";// 车库
    public static final String DevLocationType_doorway = "R0009";// 大门口

    // key 指device type, key值可重复
    private static Map<Integer, String> generalDeviceName = new LinkedHashMap<Integer, String>();
    private static Map<Integer, String> generalDeviceNamePinxin = new HashMap<Integer, String>();
    // key指的是区域标号
    private static Map<String, String> locationame = new HashMap<String, String>();
    
    static {
        generalDeviceName.put(Devtype_Illuminations, "七彩灯|多彩灯|变色灯|情景灯|彩灯|彩色灯|彩色的灯|台灯"); // 必须在"灯"之前
        generalDeviceName.put(Devtype_WallLight, "壁灯|小灯");
        generalDeviceName.put(Devtype_CeilingLight, "主灯|吊灯|大灯");// 吸顶灯
        generalDeviceName.put(Devtype_Light, "电灯|灯|灯泡|白炽灯"); // 灯的通用说法
        generalDeviceName.put(Devtype_WindowCovering, "窗帘");
        generalDeviceName.put(Devtype_Aircondition, "空调|冷气|暖气");
        generalDeviceName.put(Devtype_Humidifier, "加湿器");
        generalDeviceName.put(Devtype_Aircleaner, "(空气)?(净化器|清净机|净化器|净化机|清净机|清净器|滤净机|滤净器|滤清器)");
        generalDeviceName.put(Devtype_Dehumidifier, "除湿器|干燥器|除湿机|干燥机");
        generalDeviceName.put(Devtype_Projector, "(投影仪|投影机)器{0,1}");
        generalDeviceName.put(Devtype_Projectorbackdrop, "投影布(幕){0,1}|投影幕布{0,1}");
        generalDeviceName.put(Devtype_Television, "电视机{0,1}|电视节目|节目");
        generalDeviceName.put(Devtype_Camera, "摄像头{0,1}|录像头{0,1}|监控(摄像头){0,1}");
        generalDeviceName.put(Devtype_Door, "大{0,1}门");

        // generalName Pinyin
        generalDeviceNamePinxin.put(Devtype_Light, "diandeng|deng|dengpao|baichideng");

        // location name
        locationame.put("R0001", "客厅");
        locationame.put("R0002", "房间|卧室|卧房|室内");
        locationame.put("R0003", "饭厅|餐厅");
        locationame.put("R0004", "厨房|餐厅");
        locationame.put("R0005", "卫生间|厕所|盥洗室|洗手间|浴室");
        locationame.put("R0006", "阳台|露台");
        locationame.put("R0007", "院子里{0,1}|室外|屋外面{0,1}");
        locationame.put("R0008", "车库");
        locationame.put("R0009", "大{0,1}门口|门前");
    }

    public static Map<Integer, String> getGeneralDeviceName() {
        return generalDeviceName;
    }

    public static Map<Integer, String> getGeneralDeviceNamePinyin() {
        return generalDeviceNamePinxin;
    }
    public static Map<String, String> getLocationName() {
        return locationame;
    }
}
