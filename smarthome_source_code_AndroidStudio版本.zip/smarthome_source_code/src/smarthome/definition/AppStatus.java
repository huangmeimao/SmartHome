package smarthome.definition;

public class AppStatus {
	private int code = AppStatusCode.TOPIC_NULL;
	
	public int code(){
		return code;
	}
	private String appName = "";
	public void SetCode(int code){
		this.code = code;
	}
	public AppStatus(int code, String appName) {
		this.code = code;
		this.appName = appName;
	}
}

