package smarthome.definition;

import java.util.ArrayList;

import java.util.List;

//import com.olavoice.server.app.homeautomation.RecommendCmd;
//import com.olavoice.server.app.homeautomation.cmd_typePrimary;
//import com.olavoice.server.app.homeautomation.cmd_typeSecond;


/*
 * class sensor_value{ sensor_status light_intensity=new sensor_status();//光强
 * sensor_status temperature=new sensor_status();//温度 sensor_status
 * air_quality=new sensor_status();//空气质量 sensor_status humidity=new
 * sensor_status();//相对湿度 }
 */
//class sensor_status implements Cloneable {
//    String device_ID = "";
//    String position = "";
//    String description = "";
//    int max_value = 0;
//    int min_value = 0;
//    int device_type = 0;
//    // Map<Integer, sensor_param> paramMap = new HashMap<Integer,
//    // sensor_param>(); // 参数列表
//    private List<HomeAutoAttributeObject> Attributelist = new ArrayList<HomeAutoAttributeObject>(); // 参数列表
//
//    ControlValues controlstatus = new ControlValues();
//
//    public void setControlCMDTypeDefault() {
//        controlstatus.cmd_Primary = cmd_typePrimary.cmd_default;
//    }
//
//    public void setComtorlCMDDefault() {
//        controlstatus.command = 0xCC;
//    }
//
//    @Override
//    public sensor_status clone() {
//        sensor_status clone = null;
//
//        try {
//            clone = (sensor_status) super.clone();
//        } catch (CloneNotSupportedException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//        return clone;
//
//    }
//
//    public sensor_status copytoAnother() {
//        sensor_status tempSensor = new sensor_status();
//        tempSensor.description = description;
//        tempSensor.position = position;
//        tempSensor.device_ID = device_ID;
//        tempSensor.device_type = device_type;
//        Map<Integer, sensor_param> tempparamMap = new HashMap<Integer, sensor_param>();
//
//        for (Iterator<Integer> ob = paramMap.keySet().iterator(); ob.hasNext();) {
//            int key = ob.next();
//            sensor_param temp = new sensor_param();
//            sensor_param object = paramMap.get(key);
//            temp.level = object.level;
//            temp.value = object.value;
//            tempparamMap.put(key, temp);
//
//        }
//        tempSensor.paramMap = tempparamMap;
//
//        return tempSensor;
//
//    }
//}

public class HomeAutodeviceObjectNew implements Cloneable {
    

    public String device_ID = "";
    public int device_type = 0; // 设备类型
    public String position = "";
    public String description = "";
    private List<HomeAutoAttributeObject> Attributelist = new ArrayList<HomeAutoAttributeObject>();

    public ControlValues controlstatus = new ControlValues(); // 有些设备无法通过客户端获取其状态，通过记录其控制状态来决定其当前状态

    private int sort_cluster_ID; // 用于按照某个参数的值进行排序
    private int sort_attribute_ID;

    // 查不到属性时的默认值，即表示无法获取设备的属性
    private static final int ATTR_DEFAULT_VALUE = Integer.MAX_VALUE;
    // 若是服务器自定义名称，初始值为0
    // 命名的尾部数字
    private int predefinedname = 0;

    public void resetUpdatedStatus() {
        for (int i = 0; i < Attributelist.size(); i++) {
            HomeAutoAttributeObject attr = Attributelist.get(i);
            attr.SetUpdatedStatus(false);
        }
    }
    public void SetSortclusterID(int value) {
        sort_cluster_ID = value;
    }

    public void SetSortAttrID(int value) {
        sort_attribute_ID = value;
    }

    public void SetPredefinedname(int value) {
        predefinedname = value;
    }

    public int GetPredefinedname() {
        return predefinedname;
    }
    public int GetSortClusterID() {
        return sort_cluster_ID;
    }

    public int GetSortAttrID() {
        return sort_attribute_ID;
    }
    @Override
    public HomeAutodeviceObjectNew clone() {
        HomeAutodeviceObjectNew clone = null;
        try {
            clone = (HomeAutodeviceObjectNew) super.clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return clone;
    }

    /**
     * 本函数的功能和clone的功能应该是重复的，如果验证clone的功能是可用的话，可以去掉此功能
     * 
     * @return
     */
    // public HomeAutodeviceObjectNew copytoAnother() {
    // HomeAutodeviceObjectNew tempSensor = new HomeAutodeviceObjectNew();
    // tempSensor.description = description;
    // tempSensor.position = position;
    // tempSensor.device_ID = device_ID;
    // tempSensor.device_type = device_type;
    // tempSensor.customer_min_value = customer_min_value;
    // tempSensor.customer_max_value = customer_max_value;
    //
    // // 属性
    // List<HomeAutoAttributeObject> newAttributelist = new
    // ArrayList<HomeAutoAttributeObject>();
    //
    // for (int i = 0; i < Attributelist.size(); i++) {
    // HomeAutoAttributeObject temp = Attributelist.get(i).clone();
    //
    // }
    //
    // return tempSensor;
    //
    // }
    /**
     * 如果之后需要记录命令，则应该修改成跟cluster相关
     */
    public void setControlCMDTypeDefault() {// 命令类别
        controlstatus.cmd_Primary = cmd_typePrimary.cmd_default;
    }

    // public void setComtorlCMDDefault() {// action ID
    // controlstatus.command = 0xCC;
    // }
        
    /**
     * 检查设备中是否有某个属性
     * 
     * @param clusterID
     * @param attributeID
     * @return
     */
    public HomeAutoAttributeObject ishaveAttribute(int clusterID, int attributeID) {

        for (int i = 0; i < Attributelist.size(); i++) {
            HomeAutoAttributeObject attrObject = Attributelist.get(i);
            if (attrObject.GetClusterID() == clusterID
                    && attrObject.GetAttributeID() == attributeID)
                return attrObject;
        }
        return null;
    }

    public int GetArributeValue(int clusterID, int attributeID) {
        HomeAutoAttributeObject deviceObj = ishaveAttribute(clusterID, attributeID);
        if (deviceObj != null) {
            return deviceObj.GetAttributeValue();
        }
        return ATTR_DEFAULT_VALUE;
    }
public void SetArributeValue(int value,int clusterID, int attributeID){
	 HomeAutoAttributeObject deviceObj = ishaveAttribute(clusterID, attributeID);
	 if (deviceObj != null) {
		 deviceObj.SetAttributeValue(value);
	 }
}
    public boolean isUpdateTheAttributeValue(int clusterID, int attributeID) {
        HomeAutoAttributeObject AttributeObj = ishaveAttribute(clusterID, attributeID);
        if (AttributeObj != null) {
            return AttributeObj.isUpdated();
        }
        return false;
    }
    public int GetArributeLevel(int clusterID, int attributeID) {
        HomeAutoAttributeObject deviceObj = ishaveAttribute(clusterID, attributeID);
        if (deviceObj != null) {
            return deviceObj.GetAttributelevel();
        }
        return 0;
    }

    public void SetArributeLevel(int clusterID, int attributeID, int level) {
        HomeAutoAttributeObject deviceObj = ishaveAttribute(clusterID, attributeID);
        if (deviceObj != null) {
            deviceObj.SetAttributeLevel(level);
        }

    }
    public void AddAttribute(HomeAutoAttributeObject attr) {
        if (attr == null)
            return;
        Attributelist.add(attr);

    }

    public List<HomeAutoAttributeObject> getAttributeList() {
        return Attributelist;
    }

    public static void main(String[] arg) {
        HomeAutodeviceObjectNew test1 = new HomeAutodeviceObjectNew();
        test1.description = "desc1";
        test1.position = "po1";
        test1.device_ID = "id1";
        test1.device_type = 1;
        HomeAutoAttributeObject attr1 = new HomeAutoAttributeObject();
        attr1.SetAttributeID(1);
        test1.Attributelist.add(attr1);

        System.out.println("Before:");
        System.out.println("des:" + test1.description);
        System.out.println("devID:" + test1.device_ID);
        System.out.println("devtype:" + test1.device_type);
        System.out.println("attr1ID:" + test1.Attributelist.get(0).GetAttributeID());

        HomeAutodeviceObjectNew test2 = test1.clone();

        test2.description = "desc2";
        test2.position = "po2";
        test2.device_ID = "id2";
        test2.device_type = 2;

        test2.Attributelist.get(0).SetAttributeID(2);
        System.out.println("After:");
        System.out.println("des:" + test2.description);
        System.out.println("devID:" + test2.device_ID);
        System.out.println("devtype:" + test2.device_type);
        System.out.println("attr1ID:" + test2.Attributelist.get(0).GetAttributeID());
    }

}

class Controlstatus {
    int light_status = 0;// 0表示关闭，1表示打开
    int humiditier_status = 0;// 0表示关闭，1表示打开
    int Devtype_Aircondition_stauts = 0;// 0表示关闭，1表示打开

    int light_cmd = 0xCC; // default value=0xCC,0表示关闭，1表示打开
    int humiditier_cmd = 0xCC;// 0表示关闭，1表示打开
    int Devtype_Aircondition_cmd = 0xCC;// 0表示关闭，1表示打开,2,表示提高温度，3表示降低温度

    cmd_typePrimary lightcmd_type = cmd_typePrimary.cmd_default;
    cmd_typePrimary humcmd_type = cmd_typePrimary.cmd_default;
    cmd_typePrimary aircmd_type = cmd_typePrimary.cmd_default;
}

/**
 * Devtype_Aircondition command ://0表示关闭，1表示打开,2,表示提高温度，3表示降低温度，4.调高风力，5.降低风力
 * light command :// default value=0xCC,0表示关闭，1表示打开 humidifier
 * command://0表示关闭，1表示打开 status://0表示关闭，1表示打开
 * 
 * @author hp
 * 
 */





