package smarthome.definition;

/**
 * 聊天类语料的的标志。 用于做特殊的处理。
 * 
 */
public enum cmdNonsenseFlag {
    cmdnondefault, playmusic, leavehome, veryhot, verydry, zigbeechangedata
}
