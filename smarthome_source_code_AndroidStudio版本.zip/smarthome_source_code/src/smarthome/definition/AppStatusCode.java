package smarthome.definition;

public class AppStatusCode {
	public static final int TOPIC_NULL = 0;
	public static final int TOPIC_START = 1;
	public static final int TOPIC_END = 2;
}
