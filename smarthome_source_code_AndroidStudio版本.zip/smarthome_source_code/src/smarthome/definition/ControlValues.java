package smarthome.definition;

public class ControlValues {
    int status = 0;

    cmd_typePrimary cmd_Primary = cmd_typePrimary.cmd_default;// 记录询问用户操作的设备一级命令，用于向用户体温
    cmd_typeSecond cmd_Second = cmd_typeSecond.cmd_default;// 记录询问用户操作的设备二级命令
    // 记录设备上次操作的一级命令
    cmd_typePrimary cmd_LastPrimary = cmd_typePrimary.cmd_default;
    // 记录设备上次操作的二级命令
    cmd_typeSecond cmd_LastSecond = cmd_typeSecond.cmd_default;// 记录询问用户操作的二级命令

    public void ResetLastPrimaryCMD() {
        cmd_LastPrimary = cmd_typePrimary.cmd_default;
    }
    public cmd_typePrimary GetLastCmdPrimary() {
        return cmd_LastPrimary;
    }

    public cmd_typeSecond GetLastCmdSecond() {
        return cmd_LastSecond;
    }
    public cmd_typePrimary GetCmdPrimary() {
        return cmd_Primary;
    }

    public cmd_typeSecond GetCmdSecond() {
        return cmd_Second;
    }

    public int GetStatus() {
        return status;
    }

    public void SetLastCmdPrimary(cmd_typePrimary value) {
        cmd_LastPrimary = value;
    }

    public void SetLastCmdSecond(cmd_typeSecond value) {
        cmd_LastSecond = value;
    }

    public void SetCmdPrimary(cmd_typePrimary value) {
        cmd_Primary = value;
    }

    public void SetCmdSecond(cmd_typeSecond value) {
        cmd_Second = value;
    }

    public void SetStatus(int value) {
        status = value;
    }

}

class RecommendCmd {
    public cmd_typePrimary cmd_primary;
    public cmd_typeSecond cmd_second;
}