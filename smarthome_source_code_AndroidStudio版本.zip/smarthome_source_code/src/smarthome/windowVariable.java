package smarthome;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class windowVariable {
	private JTextField voice_text = null;
	private JTextField color_text = null;
	private JTable 	cmd_table =null;
	private JTextArea answer_Text=null;
	private boolean isred=false;
	private JTextField tempe_text = null;
	private JTextField mode_text = null;
	private JTextField wind_text = null;
	public void setTempetext(JTextField value){
		tempe_text=value;
	}
	public void setModetext(JTextField value){
		mode_text=value;
	}
	public void setWindtext(JTextField value){
		wind_text=value;
	}
	public void setVoicetext(JTextField value){
		voice_text=value;
	}
	
	public void setcolortext(JTextField value){
		color_text=value;
	}
	public void setCmdTable(JTable value){
		cmd_table=value;
	}
	public void setAnswerText(JTextArea value){
		answer_Text=value;
	}
	public void setisRed(boolean value){
		isred=value;
	}
	public JTextField getTempertext(){
		return tempe_text;
	}
	public JTextField getModetext(){
		return mode_text;
	}
	public JTextField getWindtext(){
		return wind_text;
	}
	public JTextField getVoicetext(){
		return voice_text;
	}
	public JTextField getcolortext(){
		return color_text;
	}
	public JTable getCmdTable(){
		return cmd_table;
	}
	public JTextArea getAnswerText(){
		return answer_Text;
	}
	
	public boolean getisRed(){
		return isred;
	}

}
