package smarthome.util.number;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Number {
	static Map<String, String> StrChstoStrNum = new HashMap<String, String>();
    static Map<String, String> StrNumtoStrChs = new HashMap<String, String>();
    static Map<String, String> StrNumtoStrChsUnit = new HashMap<String, String>();

    static {
        StrChstoStrNum.put("零", "0");
        StrChstoStrNum.put("0", "0");
        StrChstoStrNum.put("一", "1");
        StrChstoStrNum.put("1", "1");
        StrChstoStrNum.put("壹", "1");
        StrChstoStrNum.put("幺", "1");
        StrChstoStrNum.put("二", "2");
        StrChstoStrNum.put("贰", "2");
        StrChstoStrNum.put("两", "2");
        StrChstoStrNum.put("2", "2");
        StrChstoStrNum.put("三", "3");
        StrChstoStrNum.put("3", "3");
        StrChstoStrNum.put("叁", "3");
        StrChstoStrNum.put("四", "4");
        StrChstoStrNum.put("4", "4");
        StrChstoStrNum.put("肆", "4");
        StrChstoStrNum.put("五", "5");
        StrChstoStrNum.put("5", "5");
        StrChstoStrNum.put("伍", "5");
        StrChstoStrNum.put("六", "6");
        StrChstoStrNum.put("6", "6");
        StrChstoStrNum.put("陆", "6");
        StrChstoStrNum.put("七", "7");
        StrChstoStrNum.put("7", "7");
        StrChstoStrNum.put("柒", "7");
        StrChstoStrNum.put("拐", "7");
        StrChstoStrNum.put("八", "8");
        StrChstoStrNum.put("8", "8");
        StrChstoStrNum.put("捌", "8");
        StrChstoStrNum.put("九", "9");
        StrChstoStrNum.put("9", "9");
        StrChstoStrNum.put("玖", "9");

        StrNumtoStrChs.put("0", "零");
        StrNumtoStrChs.put("1", "一");
        StrNumtoStrChs.put("2", "二");
        StrNumtoStrChs.put("3", "三");
        StrNumtoStrChs.put("4", "四");
        StrNumtoStrChs.put("5", "五");
        StrNumtoStrChs.put("6", "六");
        StrNumtoStrChs.put("7", "七");
        StrNumtoStrChs.put("8", "八");
        StrNumtoStrChs.put("9", "九");

        StrNumtoStrChsUnit.put("9", "亿");
        StrNumtoStrChsUnit.put("8", "千万");
        StrNumtoStrChsUnit.put("7", "百万");
        StrNumtoStrChsUnit.put("6", "十万");
        StrNumtoStrChsUnit.put("5", "万");
        StrNumtoStrChsUnit.put("4", "千");
        StrNumtoStrChsUnit.put("3", "百");
        StrNumtoStrChsUnit.put("2", "十");
        StrNumtoStrChsUnit.put("1", "");

    }
	
public static final long DEFAULT_DEF_VALUE = 0xdeadbeef;
	// 一千零一个愿望 ——> 1001个愿望
    public static String StrWithChsInteger2StrWithDigital(String chsStr) {
        String result = chsStr;
        Pattern pattern = Pattern.compile("[零一二两三四五六七八九十百千万亿]+");
        Matcher matcher = pattern.matcher(chsStr);
        while (matcher.find()) {
            String str = matcher.group();
            long digi = ChineseToI(str);
            result = result.replace(str, String.format("%d", digi));
        }

        return result;
    }
    // "1001个愿望 ——> 一千零一个愿望"
    public static String StrWithDigital2StrWithChsNumber(String wszNumber) {
        String Temp = "";
        String returnStr = wszNumber;
        String[] wszNumberS = wszNumber.split("[\u4e00-\u9fa5]+");
        int numberIndexStar = 0;
        int numberIndexEnd = 0;

        String numberStr = "";
        for (String str : wszNumberS) {
            if (!str.equals("")) {
                numberStr = str;
            }

        }

        if (!numberStr.equals("")) {

            numberIndexStar = wszNumber.indexOf(numberStr);
            numberIndexEnd = numberIndexStar + numberStr.length();

            int j = numberStr.length();
            for (int i = 0; i < numberStr.length(); i++) {
                String unit = numberStr.substring(i, i + 1);

                if (Temp.endsWith("零") && unit.equals("0")) { // 1001 !——> 一零零一
                    j--;
                    continue;
                }

                if (StrNumtoStrChs.get(unit) != null) {
                    Temp += StrNumtoStrChs.get(unit);
                } else {
                    Temp += unit;
                }
                if (!Temp.endsWith("零")) {
                    Temp += StrNumtoStrChsUnit.get(Integer.toString(j));
                }

                j--;
            }
        }

        if (Temp.equals("")) {
            Temp = wszNumber;
        } else {
            if (Temp.length() == 3 && Temp.startsWith("一十")) { // 15的月亮 !——>
                                                               // 一十五的月亮
                Temp = Temp.replace("一十", "十");
            }
            boolean isEnd = true;
            while (isEnd) {
                if (Temp.endsWith("零")) {
                    Temp = Temp.substring(0, Temp.length() - 1);
                } else {
                    isEnd = false;
                }
            }
            // Temp += wszNumber.replaceAll("[0-9]", "");
            returnStr = wszNumber.substring(0, numberIndexStar) + Temp
                    + wszNumber.substring(numberIndexEnd);
        }
        return returnStr;
    }
public static long ChineseToI(final String content_original) {
    String content = content_original;

    // 一两is not a number
    if (content.length() > 1 && content.charAt(1) == '两')
        return DEFAULT_DEF_VALUE;

    content = content.replaceAll("两", "贰");
    String NumberString = "零一二三四五六七八九";
    String CNumberString = "零壹贰叁肆伍陆柒捌玖";
    String ANumberString = "0123456789";
    String ExpString = "十百千";
    String RangeExpString = "万亿";

    int ExpValue[] = { 10, 100, 1000 };
    int RangeExpValue[] = { 10000, 100000000 };

    long Result = 0;
    int lastExp = -1;
    int lastRangeExp = -1;
    long temp = 0;

    int StartPos = 0;

    int contentsize = (int) content.length();
    int sign = 1;
    if (contentsize > 1
            && (content.charAt(0) == '负' || content.charAt(0) == '-')) {
        sign = -1;
        StartPos++;
    }

    while (StartPos < contentsize) {
        int Number = (int) NumberString.indexOf(content.charAt(StartPos));
        if (Number < 0) {
            Number = (int) ANumberString.indexOf(content.charAt(StartPos));
        }

        if (Number < 0) {
            Number = (int) CNumberString.indexOf(content.charAt(StartPos));
        }
        StartPos += (Number >= 0) ? 1 : 0;

        if (StartPos == 0 && content.charAt(StartPos) == '十') {
            Number = 1;
        }

        if (Number < 0)
            return DEFAULT_DEF_VALUE;

        int Exp = -1, RangeExp = -1;

        if (StartPos < contentsize) {
            Exp = (int) ExpString.indexOf(content.charAt(StartPos));
            StartPos += (Exp >= 0) ? 1 : 0;

            if (StartPos < contentsize) {
                RangeExp = (int) RangeExpString
                        .indexOf(content.charAt(StartPos));
                StartPos += (RangeExp >= 0) ? 1 : 0;
            }
        }

        if (Exp >= 0 || RangeExp >= 0) {
            if (Exp >= 0) {
                if (Result != 0) {
                    if (Result < ExpValue[Exp] * 10)
                        return DEFAULT_DEF_VALUE;
                }
                Result += Number * ExpValue[Exp];
                lastExp = ExpValue[Exp];
            }

            if (RangeExp >= 0) {
                if (Exp < 0) {
                    Result = Result + Number;
                }

                if (lastRangeExp >= 0) {
                    if (lastRangeExp != RangeExp) {
                        Result = Result * RangeExpValue[RangeExp];
                        Result = Result + temp;
                        temp = Result;
                        Result = 0;
                    } else {
                        Result = Result + temp;
                        Result = Result * RangeExpValue[RangeExp];
                        temp = Result;
                        Result = 0;
                    }
                } else {
                    Result = Result * RangeExpValue[RangeExp];
                    temp = Result;
                    Result = 0;
                }

                lastRangeExp = RangeExp;
                lastExp = RangeExpValue[RangeExp];
            }
        } else if (lastExp > 1) {
            Result += Number;
        } else {
            Result = Result * 10 + Number;
        }
    }

    if (temp != 0) {
        Result += temp;
    }

    return Result * sign;
}

}
