package smarthome.util;

public class DataBuffer {
	
	private static final int BUFF_SIZE = 16000 * 30 * 2;
	private byte[] buffer = null;
	private int headpos = 0;
	private int tailpos = 0;
	private Object datalock = new Object();
	
	public DataBuffer()
	{
		//buffer = new short[BUFF_SIZE];
		buffer = new byte[BUFF_SIZE];
	}
	
	public boolean isFull()
	{
		synchronized(this)
		{
			if ((tailpos + 1) % BUFF_SIZE == headpos)
				return true;
			else
				return false;
		}
	}
	
	public boolean isEmpty()
	{
		synchronized(this)
		{
			if (tailpos == headpos)
				return true;
			else
				return false;
		}
	}
	
	
	public int getSize()
	{
		
		return ((tailpos - headpos) + BUFF_SIZE) % BUFF_SIZE;
	}
	
	public int write(byte[] newdata,boolean isbigedian)
	{

		//System.out.println("write start");
		synchronized(this)
		{
			if (BUFF_SIZE-1-getSize() < newdata.length)
			{
				System.out.println("Data Buffer is full!!!!");
				return -1;
			}
		}
		if (isbigedian)
		{
			for(int i=0; i<newdata.length;i+=2)
			{
				synchronized(this)
				{
					buffer[tailpos] = newdata[i+1];
					buffer[tailpos+1] = newdata[i];
					tailpos = (tailpos + 2) % BUFF_SIZE;
				}
			}
		}
		else
		{
			synchronized(this)
			{
				if (tailpos + newdata.length < BUFF_SIZE)
				{
					System.arraycopy(newdata, 0, buffer, tailpos, newdata.length);
				}
				else
				{
					int tmplen = BUFF_SIZE - tailpos;
					System.arraycopy(newdata, 0, buffer, tailpos, tmplen);
					System.arraycopy(newdata, tmplen, buffer, 0, newdata.length - tmplen);
				}
				tailpos = (tailpos + newdata.length) % BUFF_SIZE;
			}
			
		}
		//System.out.println("write end");
		synchronized(datalock)
		{
			datalock.notify();
		}
		
		return 0;
	}
	
	public int read(byte[] recvbuff, int start , int len)
	{
		//System.out.println("read start");
		int readcount = 0;
		boolean bReady = true;
		
		do
		{
			synchronized(this)
			{
				if (getSize() < len)
				{
					readcount = getSize();
				}
				else
				{
					readcount = len;
				}
			}
			
			if (readcount == 0)
			{
				bReady = false;
				synchronized(datalock)
				{
					try {
						datalock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
			else
				bReady = true;
		}while(!bReady);
		
		synchronized(this)
		{
			if (headpos + readcount < BUFF_SIZE)
			{
				System.arraycopy(buffer, headpos, recvbuff, start, readcount);
			}
			else
			{
				int tmplen = BUFF_SIZE - headpos;
				System.arraycopy(buffer, headpos, recvbuff, 0,tmplen);
				System.arraycopy(buffer, 0,recvbuff, tmplen, readcount - tmplen);
			}
			headpos = (headpos + readcount) % BUFF_SIZE;
		}
		//System.out.println("read end");
		return readcount;
	}
	
	public void restoreData(int len) {
		synchronized (this) {
			headpos -= len;
			//mCurCount += count;
			if(headpos < 0)
				headpos += BUFF_SIZE;
		}

	}
}
