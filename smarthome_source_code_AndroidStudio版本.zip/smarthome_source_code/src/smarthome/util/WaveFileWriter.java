package smarthome.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

//import android.os.Environment;

public class WaveFileWriter {
	RandomAccessFile mFile;
	int mAudioLen = 0;
	int MAX_LENGTH = (int) (1.5*1024 * 1024 * 1024);
	int mBPS = 16;
	int mChannel = 2;
	String mFileName;
	protected String getFolder()
	{
//		String outPath = Environment.getExternalStorageDirectory()
//				.getAbsolutePath();
//		if (!outPath.endsWith("/"))
//			outPath += "/";
//		outPath += ".waves/";
		String outPath="D:\\audio_own\\test.waves";
		return outPath;
	}

	public String createWavFile(String name, int bitsPerSample, int channels) {
		String ret = null;
		mBPS = bitsPerSample;
		mChannel = channels;
		if(mChannel == 2)
			MAX_LENGTH *= 2;

		mFileName = getFolder();
		File dir = new File(mFileName);
		dir.mkdirs();

		mFileName += name;
		File flRec = new File(mFileName);
		flRec.delete();
		flRec = null;
		mFile = null;
		try {
			mFile = new RandomAccessFile(mFileName, "rw");
			byte[] header = new byte[44];
			try {
				mFile.write(header);
				ret = mFileName;
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
			mFile = null;
		}
		return ret;
	}

	public boolean write(byte[] data)
	{
		boolean ret = false;
		if(mFile != null)
		{
			try {
				if(mAudioLen > MAX_LENGTH)
				{
					mFile.seek(44);
					mAudioLen = 0;
				}
	
				mFile.write(data);
				ret = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
			mAudioLen += data.length;
		}

		return ret;
	}
	
	
	public boolean write(short[] data)
	{
		boolean ret = false;
		
		if(mFile != null)
		{
			try {
				if(mAudioLen > MAX_LENGTH)
				{
					mFile.seek(44);
					mAudioLen = 0;
				}
				for(int i = 0; i < data.length; i++)
				{
					//mFile.writeShort(data[i]);
					byte low = (byte) (data[i] & 0x0ff);
                    byte high = (byte) ((data[i] >> 8) & 0x0ff);
                    mFile.writeByte(low);
                    mFile.writeByte(high);

				}
				ret = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
			mAudioLen += data.length * 2;
		}

		return ret;
	}

	public boolean write(byte[] data, int len)
	{
		boolean ret = false;
		if(mFile != null)
		{
			try {
				if(mAudioLen > MAX_LENGTH)
				{
					mFile.seek(44);
					mAudioLen = 0;
				}
	
				mFile.write(data, 0, len);
				ret = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
			mAudioLen += len;
		}

		return ret;
	}

	public void refreshWavHeader() {
		if(mFile != null)
		{
			byte[] header = new byte[44];
			int totalDataLen = mAudioLen + 36;
			long longSampleRate = 16000;
			long byteRate = mBPS * longSampleRate * mChannel / 8;
			int blockAlign = 2 * mChannel;
	
			header[0] = 'R'; // RIFF/WAVE header
			header[1] = 'I';
			header[2] = 'F';
			header[3] = 'F';
			header[4] = (byte) (totalDataLen & 0xff);
			header[5] = (byte) ((totalDataLen >> 8) & 0xff);
			header[6] = (byte) ((totalDataLen >> 16) & 0xff);
			header[7] = (byte) ((totalDataLen >> 24) & 0xff);
			header[8] = 'W';
			header[9] = 'A';
			header[10] = 'V';
			header[11] = 'E';
			header[12] = 'f'; // 'fmt ' chunk
			header[13] = 'm';
			header[14] = 't';
			header[15] = ' ';
			header[16] = 16; // 4 bytes: size of 'fmt ' chunk
			header[17] = 0;
			header[18] = 0;
			header[19] = 0;
			header[20] = 1; // format = 1
			header[21] = 0;
			header[22] = (byte) mChannel;
			header[23] = 0;
			header[24] = (byte) (longSampleRate & 0xff);
			header[25] = (byte) ((longSampleRate >> 8) & 0xff);
			header[26] = (byte) ((longSampleRate >> 16) & 0xff);
			header[27] = (byte) ((longSampleRate >> 24) & 0xff);
			header[28] = (byte) (byteRate & 0xff);
			header[29] = (byte) ((byteRate >> 8) & 0xff);
			header[30] = (byte) ((byteRate >> 16) & 0xff);
			header[31] = (byte) ((byteRate >> 24) & 0xff);
			header[32] = (byte) (blockAlign); // block align
			header[33] = 0;
			header[34] = (byte) mBPS; // bits per sample
			header[35] = 0;
			header[36] = 'd';
			header[37] = 'a';
			header[38] = 't';
			header[39] = 'a';
			header[40] = (byte) (mAudioLen & 0xff);
			header[41] = (byte) ((mAudioLen >> 8) & 0xff);
			header[42] = (byte) ((mAudioLen >> 16) & 0xff);
			header[43] = (byte) ((mAudioLen >> 24) & 0xff);
			try {
				mFile.seek(0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				mFile.write(header);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			try {
				mFile.setLength(mAudioLen + 44);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			try {
				mFile.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public String rename(String name)
	{
		String ret = mFileName;
		if(mFile != null)
		{		
			File file = new File(mFileName);
			ret = mFileName + name + ".wav";
			file.renameTo(new File(ret));
		}
		return ret;
	}
}
