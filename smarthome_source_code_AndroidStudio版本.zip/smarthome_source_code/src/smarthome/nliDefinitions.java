package smarthome;

public class nliDefinitions {
	public static String smarthome_app="smarthome";

}
